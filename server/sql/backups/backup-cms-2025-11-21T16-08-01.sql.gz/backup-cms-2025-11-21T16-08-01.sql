-- MySQL dump 10.13  Distrib 9.3.0, for macos14.7 (arm64)
--
-- Host: gondola.proxy.rlwy.net    Database: cms
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assignments`
--

DROP TABLE IF EXISTS `assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assignments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `employee_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `task_id` char(16) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `job_id` char(16) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_employee_task` (`employee_id`,`project_idx`,`task_id`),
  UNIQUE KEY `uq_employee_job` (`employee_id`,`project_idx`,`job_id`),
  KEY `project_idx` (`project_idx`),
  KEY `task_id` (`task_id`),
  KEY `job_id` (`job_id`),
  CONSTRAINT `assignments_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assignments_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE,
  CONSTRAINT `assignments_ibfk_3` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`task_id`) ON DELETE CASCADE,
  CONSTRAINT `assignments_ibfk_4` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`job_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_only_one` CHECK ((((`task_id` is not null) and (`job_id` is null)) or ((`task_id` is null) and (`job_id` is not null))))
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignments`
--

LOCK TABLES `assignments` WRITE;
/*!40000 ALTER TABLE `assignments` DISABLE KEYS */;
INSERT INTO `assignments` VALUES (2,25,'E-6303779525','T-2992522073',NULL,'2025-09-22 19:35:27'),(3,25,'E-6789064209','T-7340791523',NULL,'2025-09-23 00:58:54'),(5,25,'E-6263820295','T-7446057811',NULL,'2025-09-23 00:59:42'),(7,25,'E-6789064209','T-3492602909',NULL,'2025-09-23 01:00:59'),(11,25,'E-6263820295','T-5987979072',NULL,'2025-09-23 02:40:28'),(12,25,'E-6303779525','T-9970477989',NULL,'2025-09-23 17:14:00'),(13,25,'E-6303779525','T-4636108331',NULL,'2025-09-23 17:51:25'),(16,25,'E-6263820295',NULL,'J-7496083178','2025-09-27 23:21:17'),(20,25,'E-6303779525','T-7232511547',NULL,'2025-09-28 00:25:40'),(24,25,'E-6303779525','T-1997773484',NULL,'2025-10-26 10:35:49'),(25,25,'E-6263820295','T-2046810699',NULL,'2025-10-26 11:15:14'),(28,25,'E-6263820295',NULL,'J-3046793295','2025-11-03 23:41:38'),(30,25,'E-6263820295','T-4713919051',NULL,'2025-11-03 23:41:44'),(31,25,'E-6303779525','T-4713919051',NULL,'2025-11-03 23:41:44'),(32,25,'E-0306494859','T-6173575164',NULL,'2025-11-04 21:42:07'),(33,25,'E-6263820295','T-5810103042',NULL,'2025-11-04 21:42:31');
/*!40000 ALTER TABLE `assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `customer_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address_line1` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address_line2` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `state` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `zip` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_id` (`customer_id`),
  KEY `project_idx` (`project_idx`),
  CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4005 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (267,25,'C-3271831449','scott','johnson','calvin8@aol.com','3153741369','7001 Bayview Drive','','Sodus Point','New York','14555',NULL,'2025-11-04 15:13:56','2025-11-18 07:56:19'),(270,25,'C-8223585718','dave','anderson','dganders@gmail.com','5858571443','1080 Willits Road','','Ontario','New York','14519','','2025-11-04 21:26:48','2025-11-18 07:56:16'),(272,25,'C-1008185348','matt','vancuran','','5854023186','2733 Pre Emption Street','','Geneva','New York','14456',NULL,'2025-11-05 17:22:12','2025-11-16 06:58:59'),(273,25,'C-9105548245','barbra','strother',NULL,NULL,'eerw',NULL,'',NULL,NULL,'Interested in hot tub #67','2025-11-05 22:17:15','2025-11-16 06:58:59'),(275,25,'C-7572301199','matt','lance','','7162900829',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-07 16:00:57','2025-11-16 06:58:59'),(277,25,'C-3460280222','jim','hawryliak','jim@consolidatedagencyinc.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(278,25,'C-7864448867','john','deleo','nuclearfly@outlook.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(279,25,'C-9998711169','tom','eadie','tceadie7@gmail.com','5857375824',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(280,25,'C-8099234824','denise','waddell-conte','dwadconte@gmail.com','7025217996',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(282,25,'C-7005802063','peter','ragusa','peter@hawthorneandeast.com','5857497117',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(283,25,'C-1844384248','mary','anne lynch','nymom12103@aol.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(284,25,'C-8671345830','peter','ragusa','peter@hawthoprneandeast.com','5857497117',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-16 07:26:15'),(285,25,'C-1934322243','thomas','bowden','thomascbowden@gmail.com','5403922654',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(286,25,'C-0730955508','cathy','saxton','cathysaxtonx@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(287,25,'C-1635972419','john','hennessy','jhennesey8@rochester.rr.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(288,25,'C-1906234797','degwanda','gause','dedegause38@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(289,25,'C-4645674187','frankie','carmine','frankandcarmine@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(290,25,'C-2638898186','ken','dauphinee','kensellshomes@frontier.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(291,25,'C-4377446644','shane','hirt','sdh@dukeprops.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(292,25,'C-6053822490','ron','palermo','palemro@rochester.rr.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(293,25,'C-9715681737','mark','leach','markleach@rochester.rr.com','5855766605',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(294,25,'C-3313673793','dan','bell','dan44bell@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(295,25,'C-6243765262','steve','bumpus','steve.bumpus@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(296,25,'C-2345653283','jared','coates','jaredcoates@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(297,25,'C-1950795636','jay','caltagarone','cesfieldservice@gmail.com','8145411912',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(298,25,'C-6579163172','randy','fiege','rfiege@yahoo.com','5859430925',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(299,25,'C-2596550173','glen','tinsley','gtinsley1@rochester.rr.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(300,25,'C-8807747146','john','reynolds','johnjreynolds@aol.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(301,25,'C-3989705465','dan','rohr','screwgates@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(302,25,'C-5436789632','victor','flow','jeanneflow1234@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(303,25,'C-8373457101','angel','diaz','adunique8809@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(304,25,'C-0679713479','tyler','fleming','tfleming88@me.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(305,25,'C-1310986999','scott','rothfuss','lischer86@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(306,25,'C-5271322403','jeff','cottrone','jeffcottrone@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(307,25,'C-3962793761','kane','buholtz','kbuholtz33@gmail.com','5853294989',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(308,25,'C-9760237329','robert','merkov','rmerkov@aol.com','5857562143',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(309,25,'C-7236357792','anna','patton','golfercop@hotmail.com','3155739567',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(310,25,'C-7588299811','steve','milne','puntar10@aol.com','5854902967',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(311,25,'C-8599505575','greg','gorcica','ggorcica@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(312,25,'C-3223771343','denise','darling','littledarling.dd@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(313,25,'C-1036953989','sam','tarellis','samsoneyes@aol.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(314,25,'C-4845255427','mustafa','erturk','mustafa@24medx.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(315,25,'C-4503586755','steve','reczek','stevereczek@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(316,25,'C-2610723963','danielle','arena','deearena339@yahoo.com','5853508693',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(317,25,'C-6652513575','bill','naylon','bill.naylon@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(318,25,'C-4509265693','joanne','siwinski','jsiwinski56@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(319,25,'C-2131385962','sarah','kluger','haderster@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(320,25,'C-3202105944','mario','belpanno','dreamstarr1@aol.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(321,25,'C-8520664078','sadie','szrama','sadieszrama@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(322,25,'C-1168154649','rick','hessney','rhessney@gmail.com','9173558332',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(323,25,'C-8796641978','rick','andrews','randrew7@rochester.rr.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(324,25,'C-6312857355','mansour','farhadian','jfarhadian2@aol.com','9177010638',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(325,25,'C-4227800762','bernadette','colon','bernadettecolon1969@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(326,25,'C-9542077127','ginny','nelson','ibeginny@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(327,25,'C-0507715728','jason','cordy','jasoncordy311@gnail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(328,25,'C-9140403434','barry','slater','barryslater55@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(329,25,'C-5109563345','paul','morabito','paul.morabito@gmail.com','5859448977',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(330,25,'C-5104552144','michael','wolak','mwolakjr@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(331,25,'C-0074856550','harwinber','teur','kharwinder847@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(332,25,'C-1520294392','curtis','signorino','curt.signorino@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(333,25,'C-9853237106','sean','carroll','scarroll@rwearl.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(334,25,'C-4489037489','matthew','schoell','matthewschoell@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(335,25,'C-5416205011','alex','bielecki','bieleckifamily4@gmail.com','5858570083',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(336,25,'C-4395275454','julia','duerr','jjbean80@yahoo.com','7165238621',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(337,25,'C-5722190461','jason','camilo','jasoncamilo001@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(338,25,'C-2061042943','samuel','desalvo','scdesalvo@gmail.com','5856153246',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(339,25,'C-3701030563','ben','corke','corke.usnc@gmail.com','5857033167',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(340,25,'C-9589403143','jordan','evans','jdevans22@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(341,25,'C-4363970922','ron','prapani','tbirdland@aol.com','5855067180',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(342,25,'C-7016426620','samantha','kerr','samanthammincer@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(343,25,'C-2447398345','peggy','thomas','pthomaslvstriplej@yahoo.com','5857197753',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(344,25,'C-4171685442','devin','hogan','devinhogan.mail@gmail.com','5853036740',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(345,25,'C-6752821525','scott','fitzgerald','scfitz_69@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(346,25,'C-9888682759','peter','foti','lugbolt@hotmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(347,25,'C-8848874690','kim','martinod','kmartinod@gmail.com','8602879993',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(348,25,'C-5397349318','tom','aponte','tapont117@yahoo.com','5856135511',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(349,25,'C-4798608212','sarah','carpino','sleath1@gmail.com','5855066685',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(350,25,'C-9894567546','mike','cadle','mcadle07@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(351,25,'C-3604239999','nicole','fazio','nicole.a.fazio@proton.me',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(352,25,'C-5688145628','larry','wilson','lawrencewilson83@yahoo.com','5856941803',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(353,25,'C-4718449304','darrin','henderberg','darrin.henderberg@xylem.com','6154798942',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(354,25,'C-4992123002','david','gurzynski','dg2922@rochester.rr.com','5857295130',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(355,25,'C-6565523213','roby','reinhart','reinhartroby@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(356,25,'C-2110368669','matt','mattison','mattsshaq32@hotmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(357,25,'C-7642730509','mike','humphrey','mhumphrey@leroycsd.org','5857520626',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(358,25,'C-8380845342','elizabeth','gagnier','eokardas@gmail.com','8454894167',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(359,25,'C-6035322193','rocco','distaffen','roccoagency@yahoo.com','5857520626',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(360,25,'C-3757843684','barbara','grady','bsg51new@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(361,25,'C-6295295278','barry','garigen','bjgarigen@gmail.com','5853562739',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(362,25,'C-4756926943','jason','renkert','jrr0423@hotmail.com','5853305155',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(363,25,'C-1920067526','matthew','delaura','matthewrdelaura@gmail.com','5853034809',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(364,25,'C-9519950796','erin','des grange','tweenybode@rochester.rr.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(365,25,'C-2275962594','martha','ternoois','mternoois1@gmail.com','3155213055',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(366,25,'C-6091953598','nick','coco','ncoco2626@yahoo.com','5857212626',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(367,25,'C-0328644768','donald','schichler','donschich@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(368,25,'C-0156285020','edward','lin','eplin.md@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(369,25,'C-6467338695','randi','cowen','rcowen6@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(370,25,'C-6575064294','amy','ricotta','ajricotta@me.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(371,25,'C-9821250806','ken','keller','ken.keller.46@gmail.com','5852811050',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(372,25,'C-0707345402','john','adams','johnwadams79@gmail.com','5853139889',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(373,25,'C-3164259930','lia','bopp','liabopp22@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(374,25,'C-5546156988','mary','feeney','shopperfeeney@aol.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(375,25,'C-5998822978','ken','rando','kenrando@gmail.com','5852332557',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(376,25,'C-5082313980','naama','tapiero','naama.tapiero@gmail.com','9495015424',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(377,25,'C-5519786531','maryam','parker','maryamparker1@gmail.com','5852828901',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(378,25,'C-7587602061','john','dickquist','johndickquist@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(379,25,'C-8960982788','lucas','southerland','lucasearl32s@yahoo.com','5852021017',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(380,25,'C-0227718392','jose','ramos','codis1923@yahoo.com','5856236854',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(381,25,'C-1534538276','bev','cosner','dbarnhart@rochester.rr.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(382,25,'C-6637140545','joy','grow','joygrow70@gmail.com','5859675790',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(383,25,'C-4358285061','cheryl','jones-richter','cjonesrichter@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(384,25,'C-3826762146','richard','farmer','rfarmer1863@gmail.com','5857708715',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(385,25,'C-4685134352','andriy','romanyuk','aromanyuk1@gmail.com','5853016680',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(386,25,'C-8785249946','pete','hamanne','hamanne_peter@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(387,25,'C-0470795020','sam','cooper','samcooper342@gmail.com','7138254916',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(388,25,'C-7783729900','gary','harris','geharris53@gmail.com','5853308471',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(389,25,'C-3318439614','jean','hamel','jphamel@frontiernet.net',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(390,25,'C-8185773887','jerry','diodato','gdiodato@rochester.rr.com','5857757547',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(391,25,'C-5832348413','matt','cottone','mikecottone1@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(392,25,'C-9381133914','casey','blackburn','caseymahler@gmail.com','5857279599',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(393,25,'C-3336348705','genevieve','halligan','genevievezaharia@gmail.com','7854778817',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(394,25,'C-9456958041','joshua','fisher','joshua.p.fisher45@gmail.com','5852965835',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(396,25,'C-9007219207','matt','hannafon','mhannafon@gmail.com','5854782708',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(397,25,'C-9898488282','bob','janson','bdj82@yahoo.com','5857501412',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(398,25,'C-7709177640','lisa','smith','lsmithbaskets@aol.com','5859448731',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(399,25,'C-9047667489','mike','guzewicz','mongo1972@hotmail.com','3157290359',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(400,25,'C-6431870371','bob','hilbert','rsh071359@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(401,25,'C-7195169937','jose','rosenbaum','jose_rosenbaum@yahoo.com','5854697073',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(402,25,'C-5550986841','mark','spade','mark.spade@yahoo.com','5853819640',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(403,25,'C-4781403725','amy','delucia','amyjonewman@hotmail.com','3157277191',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(404,25,'C-7570915072','gary','gokey','flipahouse@rochester.rr.com','5857041906',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(405,25,'C-3406151114','beth','knickerbocker','knick155@frontiernet.net','5854784023',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(406,25,'C-9926412503','sean','hale','sean.m.hale@gmail.com','7162667221',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(407,25,'C-4853727461','sherry','thireom','sheilaschmeer@gmail.com','5853176112',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(408,25,'C-4695319826','tanner','morse','tannermorse2207@gmail.com','6073467780',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(409,25,'C-4359550992','carol','hopper','whooper@rochester.rr.com','5857524141',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(410,25,'C-1344855702','lianna','dupree','smileslkm@gmail.com','5858136944',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(411,25,'C-5100024815','mike','stacy','mstacy@rochester.rr.com','5856709154',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(412,25,'C-0532331651','deli','cozzarelli','jdec@verizon.net','7164356407',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(413,25,'C-8581471769','mike','johnson','whitey1mj@me.com','5857508234',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(414,25,'C-6432524856','nancy','turnerprice','nancyprice123@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(415,25,'C-5399967063','taylor','rivera','lexandtrivie@gmail.com','5857501905',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(416,25,'C-9237191050','erik','rankin','rankin33@live.com','7166972090',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(417,25,'C-2438840526','jim','lewis','james.l.lewis@gmail.com','7039896774',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(418,25,'C-7141399510','gingerbread','man','williamrobertfallon@gmail.com','4237963624',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(419,25,'C-6114666908','jennifer','miles','jenmiles0719@gmail.com','5855324799',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(420,25,'C-4947870020','david','hermans','dhermans@rochester.rr.com','5857052722',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(421,25,'C-9017596635','erin','stefanovic','eking515@gmail.com','5857339075',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(422,25,'C-6960743492','kevin','gloff','kgloff@gmail.com','5853290728',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(423,25,'C-9414231021','chris','chilson','houseja.chsn@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(424,25,'C-5480017688','lisa','rennell','lisarennell@gmail.com','5853299969',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(425,25,'C-4640032494','carla','morris','cmpasq@yahoo.com','5857941702',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(426,25,'C-2902122392','roger','breedlove','rbreed5190@aol.com','5852021629',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(427,25,'C-6001721225','collin','floom','cfloom@gmail.com','7206018202',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(428,25,'C-2732157374','bruce','parkinson','bcparkinson82@gmail.com','3153596321',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(429,25,'C-0045434350','matthew','calder','calder.matthew@yahoo.com','5857031194',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(430,25,'C-9957764156','jacob','norris','jakenorris910@gmail.com','5852615185',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(431,25,'C-3346562782','john','mcentee','jjmcentee@gmail.com','5857219047',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(432,25,'C-3582935273','remle','gear','geashel@gmail.com','5856135652',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(433,25,'C-3518732689','emily','jones','emilyjone@gmail.com','5853178860',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(434,25,'C-8466939820','kim','fasciano','kim.fasciano@gmail.com','5852618325',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(435,25,'C-5066877605','mike','miles','fishergrad2005@gmail.com','5853131173',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(436,25,'C-5706198703','john','crowley','jcrowley@biznetix.net','5853292924',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(437,25,'C-8007580516','carl','mcdade','chipmcdade@yahoo.com','5859643659',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(438,25,'C-6943962952','steve','morland','droldsmorland@yahoo.com','5857609411',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(439,25,'C-8165229252','mari','louise harrow','marilousie.harrow@gmail.com','5854413899',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(440,25,'C-6404905983','kim','kreischer','kim.krisher@outlook.com','5857097671',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(441,25,'C-3844441517','charles','howard','charlesphoward62@yahoo.com','5857461159',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(442,25,'C-6904536398','windell','grey','wgray@landonrian.com','5852020808',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(444,25,'C-6855396297','morgan','martin','mo4620@gmail.com','5857467303',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(445,25,'C-3113499817','steve','gerbowski','marygrabowski33@gmail.com','5857489396',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(446,25,'C-9321703841','jeff','ternoois','uniquegardensheds@gmail.com','5857346559',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(448,25,'C-1319142887','jack','paulson','jpaulson17a@gmail.com','5857473837',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(449,25,'C-0202621936','bob','welch','jwelch14@rochester.rr.com','5857507268',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(450,25,'C-3949762390','dan','gaita','tam48d@yahoo.com','5852986188',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(451,25,'C-2647638245','val','berger','vberger4830@gmail.com','5854096896',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(452,25,'C-3686689572','katie','lynn','dkpynn@hotmail.com','5853301364',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(453,25,'C-1940817926','daphne','sesnie','dsesnie521@gmail.com','5859670291',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(454,25,'C-8607845139','alex','hawkins','cweibel2@gmail.com','8128276415','','','','','',NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(455,25,'C-2026178260','bill','messmer','bandmpaving@frontiernet.net','5853297474',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(456,25,'C-1516769668','phil','mccord','phillip.mccord@gmail.com','7209372588',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(457,25,'C-8759749331','tracey','cornish','traceylcornish@gmail.com','5857493677',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(458,25,'C-7322669873','tracey','cornish','traceylcornish@gmail.com','5857493677',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-16 07:26:19'),(459,25,'C-2948315266','tracy','cornish','tracylcornish@gmail.com','5857493677',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(460,25,'C-8476373885','ronda','howard','nyhow@yahoo.com','5853469478',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(461,25,'C-8158649051','wesley','moon','serenna.roose@gmail.com','5853297592',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(462,25,'C-4177390739','sarah','perlin','skloves@yahoo.com','5857051358',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(463,25,'C-3500405110','shelly','gately','rmgately@gmail.com','5853561743',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(464,25,'C-4267880966','steve','bergonzi','stephen.bergonzi@gmail.com','5856224357',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(465,25,'C-8406232136','steve','bergonzi','stephen.bergonzi@prudential.com','5856224357',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-16 07:26:19'),(466,25,'C-1854105400','bernie','lehman','bernie@lehmannstrings.com','3012223336',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(467,25,'C-1043446659','tamara','gaita','tam48d@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(468,25,'C-2806663177','bill','intres','bill.intres@gmail.com','3157431807',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(469,25,'C-3264710576','kristen','means','fish4k@hotmail.com','5853144765',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(470,25,'C-8171958520','cassie','hughes','cassiehughes1@hotmail.com','5856894566',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(471,25,'C-1450623262','pam','rector','2002@yahoo.com','5857376647',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(472,25,'C-7700896404','marty','pierce','lenorah22pierce@yahoo.com','5183370282',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(473,25,'C-1553781429','lori','johnson','lorriejohn1@gmail.com','5857337881',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(474,25,'C-2890885933','david','dimmet','dzimmet@gmail.com','5859432710',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(475,25,'C-9796608347','gavin','barry','barry.gavin@gmail.com','5854290127',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(476,25,'C-9668528057','jeff','reidmiller','jwa8929@aol.com','5856157031',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(477,25,'C-1635913494','jj','anglert','jeffrey9896@gmail.com','5859677721',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(478,25,'C-5159274287','taylor','spragge','tspragge@protonmail.com','5853398619',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(479,25,'C-9433845444','mike','perri','mike.perri@yahoo.com','5859576252',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(480,25,'C-8038642926','marcelle','nascimento','mmatosnf@gmail.com','3526823431',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(481,25,'C-7978908832','garrett','traver','gtraver@rochester.rr.com','5853706741',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(482,25,'C-0196888097','david','cook','dcook10@rochester.rr.com','5853292818',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(483,25,'C-0691574291','norma','haffey','nhaffey@rochester.rr.com','5852699047',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(484,25,'C-7415731789','jeff','reidmiller','jeffreidmiller@hotmail.com','5856157031',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-16 07:26:19'),(485,25,'C-4602590358','kyle','miller','millerthepillar@gmail.com','8017099624',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(486,25,'C-0366252589','sindon','hendrickson','shendrickson@sedgwickbusiness.com','5856100008',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(487,25,'C-2174137889','jay','parnes','jayparnes@gmail.com','5857372784',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(488,25,'C-4202379333','lori','vero','laurievero@gmail.com','5859553542',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(489,25,'C-2250946670','michael','o\'connell','nytrooperdad@yahoo.com','6075920473',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(490,25,'C-0899045089','micheal','hendryx','dj1900hendryx@yahoo.com','5859810064',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(491,25,'C-9299253975','traci','ruffell','truffell2@gmail.com','5855450515',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(492,25,'C-2434357785','traci','ruffel','truffell2@gmail.com','5855450515',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(493,25,'C-7171777760','kathy','ellin','chansam4@yahoo.com','5854552283',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(494,25,'C-6605743575','stony','point hoa c/o kendrick corporation','jscarpulla@kenrickfirst.com','5859443336',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(495,25,'C-0811309623','joe','hamm','joe.m.hamm@gmail.com','5857049467',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(496,25,'C-9001488700','michael','napoli','mn.86@hotmail.com','5853336672',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(497,25,'C-9784917356','dru','turk','druturk@yahoo.com','3158822888',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(498,25,'C-0713322781','vince','giardino','vince.giar@gmail.com','5853704039',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(499,25,'C-8037519036','mike','spilberg','spigs838@yahoo.com','3155463742',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(500,25,'C-9399987117','guy','vanhoover','littlebun750@frontiernet.net','5854720164',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(501,25,'C-9042577948','paul','richards','paulnrichards606@gmail.com','5857270359',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(502,25,'C-9657430260','pete','henderson','phenderson2@rochester.rr.com','5857474659',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(503,25,'C-4264426615','joan','zimmerman','jezimmer46@gmail.com','5857395801',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(504,25,'C-2487114132','tom','wooldridge','alywool@gmail.com','5852173405',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(506,25,'C-5083490102','nicole','berardo','berardnm@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(507,25,'C-3561959415','john','dimarzio','john@maxxexchange.com','5853033054',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(508,25,'C-8859684240','stephen','fish','sfish132@gmail.com','5855071815',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(509,25,'C-2950118494','chris','johnson','johnsons.rochester@gmail.com','5857946403',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(510,25,'C-1078802799','david','cook','davidcook2818@gmail.com','5853292818',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-16 07:26:20'),(511,25,'C-5231655073','scott','miller','scott@scottmillerstyle.com','5857522651',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(512,25,'C-2826125440','kody','wagner','kodywagner9@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(514,25,'C-9066068055','doug','labell','labellboug@yahoo.com','5853038800',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(515,25,'C-5181801264','mark','graney','markcgraney@gmail.com','5852812369',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(516,25,'C-4371687351','lynn','taliento','igwt27@yahoo.com','5853549239',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(517,25,'C-3636761215','keith','wilson','kwil1027@frontiernet.net','5853773378',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(518,25,'C-7086742572','patrick','rausch','christine.ridarsky@gmail.com','5857476393',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(519,25,'C-0091624888','doug','magde','dougmagde@gmail.com','5857330402',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(520,25,'C-2752938210','tina','fountaine','tmf46@icloud.com','5858572499',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(521,25,'C-4769315791','rob','opett','robertopett@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(522,25,'C-0004996229','leronne','evans','leronneevans@yahoo.com','5857216857',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(523,25,'C-0891797348','alex','pratt','alex.w.pratt@gmail.com','7147669530',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(524,25,'C-1369263704','eric','wilder','eric.charles.wilder@gmail.com','5858089047',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(525,25,'C-1173949307','lori','murnne','lori.murnane@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(526,25,'C-0809908662','tim','daley','daleytim84@gmail.com','5853153484',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(527,25,'C-2544113776','tammy','davidson','tammyjodavidson@gmail.com','5852592751',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(528,25,'C-8439600349','nick','willcox','nickwilcox.wilcox@gmail.com','5856265269',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(529,25,'C-5732611907','tasia','ortiz','ortiz.tasia00@gmail.com','5854903862',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(530,25,'C-1904964661','mary','ann','maryannrhp@gmail.com','7149168662',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(531,25,'C-0432114919','justin','daley','daleyju08@gmail.com','5856135319',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(532,25,'C-3699857811','virginia','meier','vlm@rochester.rr.com','5857664838',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(533,25,'C-8741558711','kristen','dodds','kdodds12707@gmail.com','5857759603',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(534,25,'C-4992597727','frank','stanish','fstanish@rochester.rr.com','5852489685',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:20'),(535,25,'C-3563963487','ralph','folino','rfolino2654@gmail.com','5853979250',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:20'),(536,25,'C-9039942357','patrick','krenzer','pkrenzer@rochester.rr.com','5856156994',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:20'),(537,25,'C-4688976324','marzena','dominek','mdominek@yahoo.com','5854048664',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:20'),(538,25,'C-8446088972','leslie','hoff','lesliejk31@gmail.com','5856439534',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:20'),(539,25,'C-8867172667','mariah','ehresman','mariaehres@aol.com','5855091160',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:20'),(540,25,'C-7903700466','christopher','sprague','cspra3@gmail.com','5853556925',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:20'),(3373,25,'C-9608043818','adnan','tawseeq','adnan.m22.10@gmail.com','5856228516',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 09:34:44','2025-11-18 07:56:18'),(3443,25,'C-6104309335','alan','dungey','adungey1217@gmail.com','5857973171',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 09:34:44','2025-11-18 07:56:19'),(3473,25,'C-2359180592','austin','allen','','3159091297','176 South Main Street','','Naples','New York','14512','								11/10/25\nWants catalina spa & electrical\n\nAgreed on 5500 and penciled in a calendar date of 12/4 subject to change\nWaiting on deposit\n','2025-11-17 16:18:28','2025-11-17 16:19:02'),(3475,25,'C-0421402435','david','lieberman','lieberda@gmail.com','5617064348',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-18 07:56:02','2025-11-18 07:56:14'),(3911,25,'C-5287566786','adam','hahnel','ahahnel409@gmail.com','5856839686',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-18 07:56:18','2025-11-18 07:56:18');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `employee_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address_line1` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address_line2` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `state` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `zip` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `position` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `department` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `hire_date` datetime DEFAULT NULL,
  `termination_date` datetime DEFAULT NULL,
  `notes` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employee_id` (`employee_id`),
  KEY `project_idx` (`project_idx`),
  CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (115,25,'E-6263820295','Paul','Tanny','paultanny@gmail.com','1425342342','','','','','','CEO BITCH YUHHHHHHHH','Service',NULL,NULL,'','2025-09-22 10:54:33','2025-11-12 19:44:52'),(130,25,'E-6789064209','Brandon','Tanny','brandontanny@gmail.com','1384824232','','','','','','Owner & CEO','',NULL,NULL,'','2025-09-22 10:59:11','2025-11-12 19:44:14'),(133,25,'E-6303779525','Joey','Goff','joeygoff13@gmail.com','6037276444','','','','','07112','Type Shit','Aaah',NULL,NULL,'','2025-09-22 10:59:29','2025-11-12 19:44:43'),(185,25,'E-0306494859','James','Ludwig','','5853513662','','','','','','Shop Technician','Work Shop',NULL,NULL,'','2025-11-03 23:33:22','2025-11-03 23:33:36'),(188,25,'E-8101316451','Roger','Thomas','','3157054864','444','','','','','','',NULL,NULL,'','2025-11-03 23:34:09','2025-11-18 08:42:14');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_definitions`
--

DROP TABLE IF EXISTS `job_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_definitions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_definition_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_definition_id` (`job_definition_id`),
  KEY `project_idx` (`project_idx`),
  CONSTRAINT `job_definitions_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_definitions`
--

LOCK TABLES `job_definitions` WRITE;
/*!40000 ALTER TABLE `job_definitions` DISABLE KEYS */;
INSERT INTO `job_definitions` VALUES (3,'ceafbe9ab524f622',25,'Sale','Acquire and resell a hot tub','2025-09-17 18:13:35','2025-11-05 00:55:20'),(4,'96b8b901175a8492',25,'Refurbishment','Customer tub refurbishment','2025-09-17 18:20:37','2025-09-17 18:20:37'),(5,'644b82387191f696',25,'Service','Customer tub service job','2025-09-17 18:20:55','2025-09-17 18:20:55'),(8,'17a315bf52274b31',124,'Sale','Sale','2025-11-12 07:43:59','2025-11-12 07:43:59');
/*!40000 ALTER TABLE `job_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `job_definition_id` bigint DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `customer_id` bigint DEFAULT NULL,
  `valuation` decimal(10,2) DEFAULT NULL,
  `status` enum('waiting_diagnosis','waiting_work','waiting_parts','waiting_listing','listed','waiting_customer','waiting_delivery','complete','delivered','cancelled') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'waiting_work',
  `priority` enum('low','medium','high','urgent') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'medium',
  `scheduled_start_date` datetime DEFAULT NULL,
  `completed_date` datetime DEFAULT NULL,
  `notes` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_id` (`job_id`),
  KEY `project_idx` (`project_idx`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `job_definition_id` (`job_definition_id`),
  CONSTRAINT `jobs_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `jobs_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `jobs_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `jobs_ibfk_4` FOREIGN KEY (`job_definition_id`) REFERENCES `job_definitions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12031 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (10699,'J-7777109774',25,4,NULL,NULL,0.00,'waiting_parts','high','2025-10-16 04:00:00','2025-10-30 23:30:00','Job description','2025-09-20 23:11:52','2025-09-22 22:07:19'),(11292,'J-0466133491',25,5,NULL,NULL,0.00,'complete','urgent','2025-09-17 05:00:00','2025-09-18 04:00:00',NULL,'2025-09-21 22:09:41','2025-09-21 22:18:00'),(11310,'J-8354539608',25,4,NULL,NULL,0.00,'delivered','high','2025-09-16 04:00:00','2025-09-22 04:00:00',NULL,'2025-09-21 23:11:29','2025-09-22 19:12:48'),(11378,'J-3046026214',25,3,NULL,NULL,NULL,'waiting_work','medium',NULL,NULL,NULL,'2025-09-22 22:41:59','2025-09-22 22:41:59'),(11389,'J-5646467867',25,3,NULL,NULL,339.00,'delivered','high','2025-09-03 04:00:00','2025-09-10 04:00:00',NULL,'2025-09-23 01:02:01','2025-10-22 18:24:56'),(11394,'J-5061611354',25,5,NULL,NULL,0.00,'waiting_work','medium',NULL,NULL,NULL,'2025-09-23 01:02:45','2025-09-23 01:02:58'),(11397,'J-5592745445',25,4,NULL,NULL,NULL,'waiting_work','medium',NULL,NULL,NULL,'2025-09-23 01:03:06','2025-09-23 01:03:06'),(11449,'J-7496083178',25,5,NULL,NULL,0.00,'complete','medium','2025-09-25 04:00:00','2025-10-01 04:00:00',NULL,'2025-09-23 17:15:47','2025-10-20 17:19:27'),(11788,'J-8199885383',25,4,NULL,NULL,0.00,'delivered','medium','2025-10-08 04:00:00','2025-10-10 04:00:00','12342342','2025-10-22 18:42:34','2025-10-22 18:50:07'),(11794,'J-9946270990',25,5,NULL,NULL,NULL,'waiting_work','medium',NULL,NULL,NULL,'2025-10-22 23:46:52','2025-10-22 23:46:52'),(11795,'J-5414692569',25,4,NULL,NULL,0.00,'waiting_work','medium','2025-10-15 04:00:00','2025-10-16 15:30:00','hello!!!','2025-10-25 02:30:06','2025-10-25 07:27:22'),(11797,'J-8323419864',25,4,NULL,NULL,0.00,'waiting_work','medium','2025-11-13 05:00:00','2025-11-18 05:00:00',NULL,'2025-10-25 02:39:08','2025-10-25 23:16:18'),(11864,'J-3076511985',25,4,NULL,NULL,0.00,'delivered','medium','2025-10-02 04:00:00','2025-10-03 04:00:00',NULL,'2025-10-26 10:34:09','2025-10-29 06:20:15'),(11867,'J-9833765612',25,5,NULL,NULL,33.00,'waiting_work','medium',NULL,NULL,NULL,'2025-10-26 10:35:21','2025-10-29 23:08:48'),(11880,'J-5680526789',25,3,NULL,NULL,33.42,'cancelled','medium','2025-10-31 04:00:00','2025-11-02 04:00:00',NULL,'2025-10-29 23:07:22','2025-10-30 04:20:24'),(11892,'J-9453891954',25,5,NULL,NULL,0.00,'waiting_work','urgent','2025-10-09 04:00:00','2025-10-31 20:45:00',NULL,'2025-10-30 04:45:42','2025-11-03 23:11:32'),(11904,'J-3046793295',25,3,NULL,NULL,4650.00,'waiting_work','medium',NULL,NULL,NULL,'2025-11-03 23:22:04','2025-11-03 23:26:14'),(11978,'J-2390119693',25,5,369,NULL,0.00,'complete','medium','2025-11-04 05:00:00','2025-11-04 06:00:00','Drain + clean of swim spa\nFull winterization \nStart: 10:30am \nEnd: 2:30pm\n\nWinterization: 750\nClean: 500','2025-11-05 15:58:02','2025-11-05 16:10:05'),(11986,'J-8262245758',25,3,368,NULL,0.00,'listed','urgent',NULL,NULL,NULL,'2025-11-05 16:25:11','2025-11-19 20:23:46'),(11987,'J-0304529701',25,3,372,NULL,2650.00,'listed','urgent',NULL,NULL,NULL,'2025-11-05 16:25:22','2025-11-19 20:15:45'),(11988,'J-3069170594',25,3,366,270,0.00,'delivered','medium',NULL,NULL,NULL,'2025-11-05 16:25:43','2025-11-05 16:26:38'),(11993,'J-6698749251',25,3,373,NULL,2650.00,'listed','urgent',NULL,NULL,NULL,'2025-11-05 16:28:49','2025-11-05 17:19:52'),(12004,'J-6668891028',25,3,390,275,2650.00,'listed','urgent',NULL,NULL,NULL,'2025-11-07 15:35:34','2025-11-12 03:09:51'),(12024,'J-3600230389',124,8,399,NULL,NULL,'waiting_work','medium',NULL,NULL,NULL,'2025-11-12 07:44:00','2025-11-12 07:44:00');
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `media_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `folder_id` bigint DEFAULT NULL,
  `public_id` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `type` enum('image','video','file') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'image',
  `url` text COLLATE utf8mb4_general_ci NOT NULL,
  `alt_text` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `width` int DEFAULT NULL,
  `height` int DEFAULT NULL,
  `size` bigint DEFAULT NULL,
  `tags` json DEFAULT (json_array()),
  `ordinal` int NOT NULL DEFAULT '0',
  `originalName` text COLLATE utf8mb4_general_ci,
  `s3Key` text COLLATE utf8mb4_general_ci,
  `bucket` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `extension` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mimeType` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `transformed` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_id` (`media_id`),
  KEY `project_idx` (`project_idx`),
  KEY `folder_id` (`folder_id`),
  CONSTRAINT `media_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `media_ibfk_2` FOREIGN KEY (`folder_id`) REFERENCES `media_folders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=831 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (728,'MEDIA-9662044530',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F5578f476-3678-4d8e-bb9f-16f0638299b0.webp','',NULL,NULL,NULL,NULL,NULL,32,'2025-11-11-18-49-57-140--ggoxmytol1y0urv8yz65_webp.webp','prod/PROJ-90959de1e1d/5578f476-3678-4d8e-bb9f-16f0638299b0.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:49:58','2025-11-12 23:40:09'),(729,'MEDIA-7390429334',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F079f60ec-bba8-4af4-9f54-1b57f5109f7d.webp','',NULL,NULL,NULL,NULL,NULL,0,'2025-11-11-18-49-57-140--gsloejvdzovkwrdvogf1_webp.webp','prod/PROJ-90959de1e1d/079f60ec-bba8-4af4-9f54-1b57f5109f7d.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:49:58','2025-11-17 06:52:39'),(730,'MEDIA-0202122880',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F0b2b09b7-fcd6-4bdb-b166-c599a3d442e1.webp','',NULL,NULL,NULL,NULL,NULL,2,'2025-11-11-18-49-57-140--i11b6e5qjvv2asvlcvwn_webp.webp','prod/PROJ-90959de1e1d/0b2b09b7-fcd6-4bdb-b166-c599a3d442e1.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:49:58','2025-11-16 06:36:12'),(731,'MEDIA-8748462023',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F75fde21d-e445-457a-87f7-801e1ac3b127.webp','',NULL,NULL,NULL,NULL,NULL,3,'2025-11-11-18-49-57-140--kuf94iwi76c7ewpkirjl_webp.webp','prod/PROJ-90959de1e1d/75fde21d-e445-457a-87f7-801e1ac3b127.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:49:58','2025-11-16 06:36:12'),(732,'MEDIA-9623159786',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F406e75c4-d76f-4db4-92e6-90a3cea61249.webp','',NULL,NULL,NULL,NULL,NULL,5,'2025-11-11-18-49-57-140--nmn3e8c8wmw33rwsbm2h_webp.webp','prod/PROJ-90959de1e1d/406e75c4-d76f-4db4-92e6-90a3cea61249.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:49:58','2025-11-13 03:49:27'),(733,'MEDIA-1477009469',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F0a80f4bb-55df-491a-9a25-3d92a69ba140.webp','',NULL,NULL,NULL,NULL,NULL,1,'2025-11-11-18-49-57-140--pm1shjbupny49fqjpaxo_webp.webp','prod/PROJ-90959de1e1d/0a80f4bb-55df-491a-9a25-3d92a69ba140.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:49:58','2025-11-17 06:52:39'),(734,'MEDIA-1886282550',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fe925cdcc-c827-4b59-b232-30837c7783c4.webp','',NULL,NULL,NULL,NULL,NULL,7,'2025-11-11-18-49-57-140--whz5kgleueldtoulhvut_webp.webp','prod/PROJ-90959de1e1d/e925cdcc-c827-4b59-b232-30837c7783c4.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:49:58','2025-11-13 03:49:34'),(735,'MEDIA-9944328510',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F2a0ba0c5-fdda-4591-af7e-6eea5fb24bb3.webp','',NULL,NULL,NULL,NULL,NULL,6,'2025-11-11-18-49-57-140--yscmeamwdqnh3cpjrbhh_webp.webp','prod/PROJ-90959de1e1d/2a0ba0c5-fdda-4591-af7e-6eea5fb24bb3.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:49:58','2025-11-13 03:49:34'),(736,'MEDIA-5735592662',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F25e31375-1967-4827-8c54-b8fff0e1f987.webp','',NULL,NULL,NULL,NULL,NULL,8,'2025-11-11-18-50-32-842--bjtloupjplmh9zxp1hqp_webp.webp','prod/PROJ-90959de1e1d/25e31375-1967-4827-8c54-b8fff0e1f987.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-13 03:49:27'),(737,'MEDIA-4428080733',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fb5463c45-0a53-4552-9a75-f84240826a9e.webp','',NULL,NULL,NULL,NULL,NULL,9,'2025-11-11-18-50-32-842--jrzdlc5izcl9tf1ogmax_webp.webp','prod/PROJ-90959de1e1d/b5463c45-0a53-4552-9a75-f84240826a9e.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-13 03:49:27'),(738,'MEDIA-3073924498',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F181e3f69-88cf-429e-82fd-eeef27a37085.webp','',NULL,NULL,NULL,NULL,NULL,10,'2025-11-11-18-50-32-842--ldloubbiltkfs4iw4y5s_webp.webp','prod/PROJ-90959de1e1d/181e3f69-88cf-429e-82fd-eeef27a37085.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-13 03:49:27'),(739,'MEDIA-2778362769',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F4fabaf4f-ef7a-4a9d-a793-ea558ae389c0.webp','',NULL,NULL,NULL,NULL,NULL,11,'2025-11-11-18-50-32-842--mlf3xq1q2bvbyecxtfza_webp.webp','prod/PROJ-90959de1e1d/4fabaf4f-ef7a-4a9d-a793-ea558ae389c0.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-13 03:49:27'),(740,'MEDIA-7317459535',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fe4cee457-f179-4194-9c2b-1a7d206117c7.webp','',NULL,NULL,NULL,NULL,NULL,12,'2025-11-11-18-50-32-842--otaqvfpkjl7pygw4pfsr_webp.webp','prod/PROJ-90959de1e1d/e4cee457-f179-4194-9c2b-1a7d206117c7.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-13 03:49:27'),(741,'MEDIA-0193729226',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F2c0689f0-ed5d-43c8-aa4c-9afafd82396e.webp','',NULL,NULL,NULL,NULL,NULL,13,'2025-11-11-18-50-32-842--ruv7tbt3hskjdrjndxmb_webp.webp','prod/PROJ-90959de1e1d/2c0689f0-ed5d-43c8-aa4c-9afafd82396e.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-13 03:49:27'),(742,'MEDIA-9299595616',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fa9d65053-7216-4157-81ad-3e0ce6203217.webp','',NULL,NULL,NULL,NULL,NULL,14,'2025-11-11-18-50-32-842--tcrmnu9ii9uivrpu2c7z_webp.webp','prod/PROJ-90959de1e1d/a9d65053-7216-4157-81ad-3e0ce6203217.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-13 03:49:27'),(743,'MEDIA-4966922788',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F6903d2c1-9828-4b2b-acbd-2bac16d06171.webp','',NULL,NULL,NULL,NULL,NULL,15,'2025-11-11-18-50-32-842--umaqojubqbflujijvioa_webp.webp','prod/PROJ-90959de1e1d/6903d2c1-9828-4b2b-acbd-2bac16d06171.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-13 03:49:27'),(744,'MEDIA-7371759684',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F4234af70-96e0-445b-a127-5520b80b5d75.webp','',NULL,NULL,NULL,NULL,NULL,16,'2025-11-11-18-50-32-842--wq9pivaaynb58jk7iupa_webp.webp','prod/PROJ-90959de1e1d/4234af70-96e0-445b-a127-5520b80b5d75.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-13 03:49:27'),(745,'MEDIA-2389102154',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fbf2f293c-24c3-409f-b7d2-624880cdc768.webp','',NULL,NULL,NULL,NULL,NULL,17,'2025-11-11-18-50-32-842--ylwqmai04bojyjkhqakf_webp.webp','prod/PROJ-90959de1e1d/bf2f293c-24c3-409f-b7d2-624880cdc768.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-13 03:49:27'),(746,'MEDIA-8901569610',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F91108393-1623-4413-8b4d-3db3eb36593e.webp','',NULL,NULL,NULL,NULL,NULL,18,'2025-11-11-18-50-58-231--a0pntij35ukgbfvkst3q_webp.webp','prod/PROJ-90959de1e1d/91108393-1623-4413-8b4d-3db3eb36593e.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:59','2025-11-13 03:49:27'),(747,'MEDIA-6497647025',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F458acc0c-fd3b-417c-abbe-1f635d43a1f6.webp','',NULL,NULL,NULL,NULL,NULL,19,'2025-11-11-18-50-58-231--eyptkkmjjffo8vnun8wl_webp.webp','prod/PROJ-90959de1e1d/458acc0c-fd3b-417c-abbe-1f635d43a1f6.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:59','2025-11-13 03:49:27'),(748,'MEDIA-3319376154',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fcee60f50-81fb-4e72-8362-6ff44b2e09f5.webp','',NULL,NULL,NULL,NULL,NULL,20,'2025-11-11-18-50-58-231--fmn2qnyf81dx3okbtq4d_webp.webp','prod/PROJ-90959de1e1d/cee60f50-81fb-4e72-8362-6ff44b2e09f5.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:59','2025-11-13 03:49:27'),(749,'MEDIA-0360391895',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F42b527e0-63bf-498c-a0c4-13811d2c3d99.webp','',NULL,NULL,NULL,NULL,NULL,21,'2025-11-11-18-50-58-231--ilxxzfqmho23qrff0obc_webp.webp','prod/PROJ-90959de1e1d/42b527e0-63bf-498c-a0c4-13811d2c3d99.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:59','2025-11-13 03:49:27'),(750,'MEDIA-4088598714',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F0d0f1a5c-9f0c-4365-bb6b-47c40d18b38d.webp','',NULL,NULL,NULL,NULL,NULL,22,'2025-11-11-18-50-58-231--wpmqoxrowqxyfphyefh0_webp.webp','prod/PROJ-90959de1e1d/0d0f1a5c-9f0c-4365-bb6b-47c40d18b38d.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:59','2025-11-13 03:49:27'),(751,'MEDIA-7352061585',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F51367de4-b5aa-4403-9e17-6a67a793d3ed.webp','',NULL,NULL,NULL,NULL,NULL,23,'2025-11-11-18-50-58-231--zjq2u1trrrnkit2hai3w_webp.webp','prod/PROJ-90959de1e1d/51367de4-b5aa-4403-9e17-6a67a793d3ed.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:59','2025-11-13 03:49:27'),(752,'MEDIA-0995568397',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Ff59cf54e-6b59-437f-bb02-70fac105b20d.webp','',NULL,NULL,NULL,NULL,NULL,4,'2025-11-11-18-51-17-266--ao9s5f10cuk2rbpnerua_webp.webp','prod/PROJ-90959de1e1d/f59cf54e-6b59-437f-bb02-70fac105b20d.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-16 06:36:12'),(753,'MEDIA-7602481629',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Feaf58992-3d54-4c3a-8258-a00236dca221.webp','',NULL,NULL,NULL,NULL,NULL,24,'2025-11-11-18-51-17-266--ftcl0iomsmvveo7el42o_webp.webp','prod/PROJ-90959de1e1d/eaf58992-3d54-4c3a-8258-a00236dca221.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-12 23:40:09'),(754,'MEDIA-7547150141',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F2afb98a2-1391-4163-b90a-12ebcac49513.webp','',NULL,NULL,NULL,NULL,NULL,25,'2025-11-11-18-51-17-266--hnjyjxxkjvhncbefx8gv_webp.webp','prod/PROJ-90959de1e1d/2afb98a2-1391-4163-b90a-12ebcac49513.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-12 23:40:09'),(755,'MEDIA-1105641631',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F5e8fc2c3-4242-4a13-a430-034f8de61c21.webp','',NULL,NULL,NULL,NULL,NULL,26,'2025-11-11-18-51-17-266--pl9ksg3claaugiyyqsn0_webp.webp','prod/PROJ-90959de1e1d/5e8fc2c3-4242-4a13-a430-034f8de61c21.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-12 23:40:09'),(756,'MEDIA-5735775865',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F5a4219ff-005f-469c-a069-3e9fb328c480.webp','',NULL,NULL,NULL,NULL,NULL,27,'2025-11-11-18-51-17-266--s5mxdu4xwx3r7egeaagh_webp.webp','prod/PROJ-90959de1e1d/5a4219ff-005f-469c-a069-3e9fb328c480.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-12 23:40:09'),(757,'MEDIA-5972975382',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fd85f0080-78ff-41a4-8cb8-ffb32b0f6781.webp','',NULL,NULL,NULL,NULL,NULL,28,'2025-11-11-18-51-17-266--t3ruymdm3hq5iwniwpas_webp.webp','prod/PROJ-90959de1e1d/d85f0080-78ff-41a4-8cb8-ffb32b0f6781.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-12 23:40:09'),(758,'MEDIA-5036328663',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fe70e7182-959e-48b0-bf10-7c9a5aa0acf2.webp','',NULL,NULL,NULL,NULL,NULL,29,'2025-11-11-18-51-17-266--tkhjlryc2klruypjsyat_webp.webp','prod/PROJ-90959de1e1d/e70e7182-959e-48b0-bf10-7c9a5aa0acf2.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-12 23:40:09'),(759,'MEDIA-2849564603',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F6be23be6-8b30-42ca-b4b9-475e0eeb1b95.webp','',NULL,NULL,NULL,NULL,NULL,30,'2025-11-11-18-51-17-266--tl4pbzmxwjbhzzg5xy0n_webp.webp','prod/PROJ-90959de1e1d/6be23be6-8b30-42ca-b4b9-475e0eeb1b95.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-12 23:40:09'),(760,'MEDIA-6585884698',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fa512cb7b-f340-4740-8c64-35321560b256.webp','',NULL,NULL,NULL,NULL,NULL,31,'2025-11-11-18-51-17-266--z1wpzuuhuvej7l9yvivh_webp.webp','prod/PROJ-90959de1e1d/a512cb7b-f340-4740-8c64-35321560b256.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-12 23:40:09'),(761,'MEDIA-8933929142',25,438,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F20119955-c59f-4a15-9f33-3ac3cbcbecfe.webp','',NULL,NULL,NULL,NULL,NULL,0,'2025-11-11-22-29-44-536--logo_png.png','prod/PROJ-90959de1e1d/20119955-c59f-4a15-9f33-3ac3cbcbecfe.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-12 03:29:45','2025-11-12 06:56:59'),(763,'MEDIA-1130735691',25,438,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F85223ee8-409d-47d8-a0cd-4b071edebf87.webp','',NULL,NULL,NULL,NULL,NULL,2,'2025-11-11-22-33-48-607--logo_light3_png.png','prod/PROJ-90959de1e1d/85223ee8-409d-47d8-a0cd-4b071edebf87.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-12 03:33:49','2025-11-12 10:39:18'),(769,'MEDIA-4489828454',25,438,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F7bbe59f8-f78d-4a9c-91e9-4468d38dcb0e.webp','',NULL,NULL,NULL,NULL,NULL,1,'2025-11-11-22-41-26-569--logo_light2_png.png','prod/PROJ-90959de1e1d/7bbe59f8-f78d-4a9c-91e9-4468d38dcb0e.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-12 03:41:26','2025-11-12 10:39:18'),(829,'MEDIA-1078291141',124,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-6182098829%2Ffd73cb7d-7c8d-4edf-85ca-0d8f2da7420e.webp','',NULL,NULL,NULL,NULL,NULL,0,'2025-11-18-03-44-53-426--RiverAware_png.png','prod/PROJ-6182098829/fd73cb7d-7c8d-4edf-85ca-0d8f2da7420e.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-18 08:44:53','2025-11-18 08:44:53'),(830,'MEDIA-3542794486',124,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-6182098829%2F01783416-5428-4fef-a09b-df58f3cc2032.webp','',NULL,NULL,NULL,NULL,NULL,1,'2025-11-18-03-49-13-547--RiverAwareLogo_png.png','prod/PROJ-6182098829/01783416-5428-4fef-a09b-df58f3cc2032.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-18 08:49:13','2025-11-18 08:49:13');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_folders`
--

DROP TABLE IF EXISTS `media_folders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_folders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `folder_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `parent_folder_id` bigint DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `ordinal` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `folder_id` (`folder_id`),
  KEY `project_idx` (`project_idx`),
  KEY `parent_folder_id` (`parent_folder_id`),
  CONSTRAINT `media_folders_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `media_folders_ibfk_2` FOREIGN KEY (`parent_folder_id`) REFERENCES `media_folders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=444 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_folders`
--

LOCK TABLES `media_folders` WRITE;
/*!40000 ALTER TABLE `media_folders` DISABLE KEYS */;
INSERT INTO `media_folders` VALUES (438,'F-1898140772',25,NULL,'Brand',0,'2025-11-12 03:34:15','2025-11-12 23:40:13');
/*!40000 ALTER TABLE `media_folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_link`
--

DROP TABLE IF EXISTS `media_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_link` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `entity_type` enum('product','page','module','job') COLLATE utf8mb4_general_ci NOT NULL,
  `entity_id` bigint NOT NULL,
  `media_id` bigint NOT NULL,
  `ordinal` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `entity_type` (`entity_type`,`entity_id`,`media_id`),
  KEY `media_id` (`media_id`),
  CONSTRAINT `media_link_ibfk_1` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=341 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_link`
--

LOCK TABLES `media_link` WRITE;
/*!40000 ALTER TABLE `media_link` DISABLE KEYS */;
INSERT INTO `media_link` VALUES (270,'product',373,733,0),(271,'product',373,731,1),(272,'product',373,732,2),(273,'product',373,735,3),(274,'product',373,728,4),(275,'product',373,730,5),(276,'product',373,729,6),(277,'product',373,734,7),(278,'product',372,742,0),(279,'product',372,739,1),(280,'product',372,740,2),(281,'product',372,738,3),(282,'product',372,736,4),(283,'product',372,737,5),(284,'product',372,741,7),(285,'product',372,744,8),(286,'product',372,745,9),(287,'product',372,743,6),(288,'product',390,750,0),(289,'product',390,747,1),(290,'product',390,749,2),(291,'product',390,746,3),(292,'product',390,748,4),(293,'product',390,751,5),(294,'product',368,760,0),(295,'product',368,754,1),(296,'product',368,755,2),(297,'product',368,756,3),(298,'product',368,753,4),(299,'product',368,757,5),(300,'product',368,752,6),(301,'product',368,758,7),(302,'product',368,759,8);
/*!40000 ALTER TABLE `media_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_definitions`
--

DROP TABLE IF EXISTS `page_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `page_definitions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `page_definition_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `identifier` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `parent_page_definition_id` bigint DEFAULT NULL,
  `allowed_sections` json DEFAULT (json_array()),
  `config_schema` json DEFAULT (json_object()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `page_definition_id` (`page_definition_id`),
  KEY `fk_page_definitions_parent` (`parent_page_definition_id`),
  CONSTRAINT `fk_page_definitions_parent` FOREIGN KEY (`parent_page_definition_id`) REFERENCES `page_definitions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_definitions`
--

LOCK TABLES `page_definitions` WRITE;
/*!40000 ALTER TABLE `page_definitions` DISABLE KEYS */;
INSERT INTO `page_definitions` VALUES (1,'PD-4473478327','Page 1','page-1',NULL,'[]','{}'),(2,'PD-7661298906','Page 1 IN','page-1-in',1,'[\"Home\", \"Nav\"]','{}');
/*!40000 ALTER TABLE `page_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `customer_id` bigint DEFAULT NULL,
  `serial_number` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `highlight` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` text COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `note` text COLLATE utf8mb4_general_ci,
  `make` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `model` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `type` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `length` decimal(6,2) DEFAULT NULL,
  `width` decimal(6,2) DEFAULT NULL,
  `height` decimal(6,2) DEFAULT NULL,
  `ordinal` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`),
  UNIQUE KEY `unique_project_serial` (`project_idx`,`serial_number`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=409 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (363,'P-1472922937',25,270,'TSA8490NJC006',NULL,'Green Jacuzzi',NULL,'','Jacuzzi',NULL,NULL,84.00,90.00,0.00,0,'2025-11-04 21:28:01','2025-11-12 04:24:23'),(366,'P-3834929730',25,270,'TSA8787L2MX038',NULL,'Brown MAAX Spa',NULL,'','MAAX','',NULL,87.00,87.00,34.00,1,'2025-11-04 21:43:31','2025-11-06 01:00:57'),(368,'P-1586806747',25,NULL,'TSA7777N2SR045',NULL,'Small Gray Sunrise Hot Tub','','','Sunrise','',NULL,77.00,77.00,0.00,2,'2025-11-05 15:55:31','2025-11-12 20:05:49'),(369,'P-8047394352',25,267,'SCOTTJOHNSONSWIMSPA',NULL,'Scott Johnson Service Call','Scott Johnson Swim Spa ','',NULL,NULL,NULL,0.00,0.00,0.00,3,'2025-11-05 15:57:38','2025-11-05 16:15:57'),(372,'P-4956068717',25,NULL,'TSA8483L2JC080',NULL,'Jacuzzi White Marble Shell','FREE DELIVERY & INSTALLATION INCLUDED\n\nThis is an excellent condition Jacuzzi Hot Tub\n\n✅ Included:\n  - BRAND NEW folding leather cover \n    (You pick the color!)\n  - 90-day warranty \n  - Hot water delivery (if requested)\n  - Again, FREE DELIVERY & INSTALLATION \n\n➕ Additional Accessories:\n   - Spa care kit $200\n   - Entry steps $100\n   - Cover Lifter $150\n  \n🧪 Spa-Care Package ($200):\n   - Skimmer net\n   - Water test strips\n   - Oxidizing Shock\n   - Chlorine granulate \n   - PH Up \n   - PH Down \n   - Water clarifier \n   - Thermometer\n   - Kid-safe sealed bucket for chemicals\n   - Step-by-step tutorial \n\n📏 Dimensions:\n            83\"    x    91\"   x     38\" \n       (Length)x(Width)x(Height)\n\n⚡️ Electrical: 240v, 50A\n\n💲Discounts: As a small business, we’re able to offer discounted rates for customers who purchase BOTH a hot tub + an electrical installation through us! Message for more info!\n\n*** No holds. First come, first serve. ***','','Jacuzzi','J330',NULL,84.00,84.00,0.00,4,'2025-11-05 16:24:41','2025-11-12 02:53:01'),(373,'P-5297536816',25,3473,'TSA7676N1CT053',NULL,'Small Dark Brown Catalina','FREE DELIVERY & INSTALLATION INCLUDED\n\nThis is an excellent condition Sunrise Odyssey Hot Tub. \n\n✅ Included:\n  - BRAND NEW folding leather cover \n    (You pick the color!)\n  - 90-day warranty \n  - Hot water delivery (if requested)\n  - Again, FREE DELIVERY & INSTALLATION \n\n➕ Additional Accessories:\n   - Spa care kit $200\n   - Entry steps $100\n   - Cover Lifter $150\n  \n🧪 Spa-Care Package ($200):\n   - Skimmer net\n   - Water test strips\n   - Oxidizing Shock\n   - Chlorine granulate \n   - PH Up \n   - PH Down \n   - Water clarifier \n   - Thermometer\n   - Kid-safe sealed bucket for chemicals\n   - Step-by-step tutorial \n\n📏 Dimensions:\n            77\"    x    77\"   x     38\" \n       (Length)x(Width)x(Height)\n\n⚡️ Electrical: 240v, 50A\n\n💲Discounts: As a small business, we’re able to offer discounted rates for customers who purchase BOTH a hot tub + an electrical installation through us! Message for more info!\n\n*** No holds. First come, first serve. ***','Matt is interested. No deposit collected yet. waiting to get pics of his electrical system before confirming prices','Catalina',NULL,NULL,76.00,76.00,0.00,5,'2025-11-05 16:28:41','2025-11-17 16:33:29'),(383,'P-9388566084',25,273,'TSA8491L2JC067',NULL,'Jacuzzi Silver Shell',NULL,'Barbra interested. Has not paid the deposit yet','Jacuzzi','J355',NULL,84.00,91.00,0.00,6,'2025-11-05 22:16:25','2025-11-05 22:21:16'),(390,'P-6756275021',25,275,'TSA8484L1JC078',NULL,'Light Brown Jacuzzi J335','FREE DELIVERY & INSTALLATION INCLUDED\n\nThis is an excellent condition 50th Anniversary Edition Jacuzzi Hot Tub!\n\n✅ Included:\n  - BRAND NEW folding leather cover \n    (You pick the color!)\n  - 90-day warranty \n  - Hot water delivery (if requested)\n  - Again, FREE DELIVERY & INSTALLATION \n\n➕ Additional Accessories:\n   - Spa care kit $200\n   - Entry steps $100\n   - Cover Lifter $150\n  \n🧪 Spa-Care Package ($200):\n   - Skimmer net\n   - Water test strips\n   - Oxidizing Shock\n   - Chlorine granulate \n   - PH Up \n   - PH Down \n   - Water clarifier \n   - Thermometer\n   - Kid-safe sealed bucket for chemicals\n   - Step-by-step tutorial \n\n📏 Dimensions:\n            84\"    x    84\"   x     38\" \n       (Length)x(Width)x(Height)\n\n⚡️ Electrical: 240v, 50A\n\n💲Discounts: As a small business, we’re able to offer discounted rates for customers who purchase BOTH a hot tub + an electrical installation through us! Message for more info!\n\n*** No holds. First come, first serve. ***','Matt Lance interested in picking up tub from shop with no warranty $2500. no deposit yet. inform him if others are interested','Jacuzzi','J335',NULL,84.00,84.00,0.00,7,'2025-11-07 15:35:29','2025-11-12 03:49:58'),(399,'P-0168938282',124,NULL,'4EWFASDFSDF',NULL,'',NULL,'',NULL,NULL,NULL,0.00,0.00,0.00,0,'2025-11-12 03:18:13','2025-11-12 03:18:13');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_integrations`
--

DROP TABLE IF EXISTS `project_integrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_integrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `integration_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `integration_key` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `integration_value` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `integration_id` (`integration_id`),
  UNIQUE KEY `uq_project_module` (`project_idx`,`integration_key`),
  CONSTRAINT `project_integrations_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_integrations`
--

LOCK TABLES `project_integrations` WRITE;
/*!40000 ALTER TABLE `project_integrations` DISABLE KEYS */;
INSERT INTO `project_integrations` VALUES (12,'I-4399925184',25,'GOOGLE_MAPS_API_KEY','U2FsdGVkX1+ammiudE6UPHcYnc23EEBrBRTQyezzpmPILI4ZPq44pb3Rz5E/erGJ+IZX2UksWK6J50Sr664Pfw==','2025-11-15 06:02:33','2025-11-15 06:02:33'),(13,'I-2094220214',25,'WIX_GENERATED_SECRET','U2FsdGVkX18PhcWN1J5P7S5iFX9VPqfRRgFLv08spOtBzOQShlcvZnb1s61hQowFEVl0Uf+0KD8/AVky7JuZTJmTJuZHXBvRBmmWHcgpmteFFMtNA3SO4Ud44iwrAwCk','2025-11-15 06:35:34','2025-11-15 06:35:34'),(14,'I-5307868029',25,'WIX_BACKEND_URL','U2FsdGVkX19PacMRAXPffIK5XeVVLZQ//XmCyYDhfZ9IiZ2aGCpK2wB32ST+lSbCvyKa9kAvKak3HkjgMd20npOQWZ4yeKPQafonnuvaUEI=','2025-11-15 06:35:41','2025-11-15 06:35:41'),(15,'I-2485151321',25,'GOOGLE_SERVICE_ACCOUNT_JSON','U2FsdGVkX1/FykkWxfyUohcK40CdPrxyebTftCVThSDVr8nNsZlbUdQuLJUQHnBBEcr+GW7Q+6HF7+YayBIKHmrWnN9FfdxclyjOCg1+vdF+I/q78FaU7DZBD6cDRodXmQBxaNWVVWb6Fquk2oSV36HOeUV87IAkFPVsDQAxl7dI7p8YgxLMSCLV6Iwe+dYdFbWveExzZAlBeR74sLqYw7l4CMDZENUZfPRN9ERV1ZMFE6qGNDYokOxxhvfvAytPyatkkL3/zmPNFcTjvvxhl/P4D65oW/XGZearkjC8YGkGpfUgsKb0UA1qV7MFuBiniNtiWJnq/AZ9IMpeBmA3IYPnmvE2n16qejEqZH3tHsPBwkFelcaLchexCYHEfaanQX2wtDq1ZmGXkjbW3iV//4jKJ11y5l6+IuTZAE3rkcoSUKYRA+JYAMLsg68X1+EkV1jR9P9KF8ka3zUdyxV3bWfUNuoCLA7VTHKXbYlwrl5XMNdItq+XOlXc7sMsHjceBgeMzB9DQUsqrFfN1aKH26fv1uvF1B2RV8/0yqzYhMzCEuYAoO+NVuR0ezjZsYT13Nm+HflYnsn2pu9jOWbk8VaCCqd0dhizI6ANqckAeO4Kjs4FDlpo1dnMDn/xpolIMYEM1+KQjjt/nTIPT7M440idKD4nbhgV1MCxL1XsKd9utQKk5hFnp0BsA7L5JEHMxdMvlhOYUYefTVpkFCEcy3BpNQ4xuHHy6za991Qc2k09WpmglxYYm0X3WBhy8odZf39T6iJUwvTPxnjUppQISXqRsRSuG9Kk261Xe4aVvcOdVwAqBzFtx5ctaD91y3J4BX85T8KZgFQ9jHMcIp5+SMtp8jB3pR9FDMn06E1bOX120eae47s/OfsKIcjMlQgxRf+Nqr+h4GGqsbbYZA7QGTi2euY0NQ2ln/8naDKswys0su+Y6/wLD+z1TsvrLLTRxS0AD8w4bC2ZEdTe4TIByrqYgN349lDEjyhFHsTmy+ug52M84Bwu45TYXAe8O7MJJ8GFxkt8zV69hNjdJBtn3n/evi4Y63l5n478dkZpfUh+rIWY09nc9jNVPdXr2D89/Sqs1odH0ExFCh/7RZnk3/wXCIgfGYRG4xt2ZHjJmmg2WYlsViMzFVNPfNVkCFaX8NnSTDyBkZaxkQrh6wIcqEVElto7ebovNUBeE0oIqOI6Wy3Phlcdw31j+VbzbA5tTlwn0V0GLQf3qb/19WwOTOSia21xgP1YflY27WwmmK9YOeJkY7mkGASUOd991hGXAAQjKhoVYzxgTdzg02NzeZReHsJ283dWrM1bIlFXGRZbPnXQM05HdMDOHUaDuxk2UqAP7EtOb4z2IwKBcZmcDoQMXzj3AFGGljOYQE9t2i68QKtG9rF78NHt3mlO1MCEB0PB2i+D9KZaHvUD1eA7Lh6Nm6s7WwvcF9rRcDdEoLZGbvBXmZNLB0yYxT526oGohMnclvEpagnZBmfZx2sBk3CBNp88pWb07MjbN3Pk4WEZ0HMVyVpeNKl3nIM6s4zTOdUpmzBsQ4khB8p87HmWhIuBWODjMv5DKZw46RvlUgi0b6qKfiN4Sqawe8A+dxSanzVU3P9nvxOD05yYOczhxE77DUxvUjMu5CTzsry5WQ8czwL2y57+Xq4tCYbFqZvb+9wOoJDG6i8wMPayyAHJkMV/eNr/KZRzD0TMPoUCIts98EGVRH+xHEnD1eTeCGs3R8BDpxRKPwVk4oxOBWBbegl7DplhrECizRTTdEvuhZ33I3mD/5DCIg7PSh04+zpfDnwbhD150tnTJlovmqfZpIoMtGBCYDEoWG1s7QRFMhhmkZ6xeMaO6NJ9gyrRXEVsEsogOyO7+8EWIcuV/nG+MJtQcKDzbagTz+6QncEdSP7lJaI1B7myEpTJezpGImh6RTAEJZcH+C8WrXlyb4SWxGZMxGEZexitl4I2OOIZZ86QpeUlbB4yiBYCD+ntsKfgSLJ2Yg0P760/sF6mragKSN00Bejs6aTdHmzbOI27YBOIC+953ZiS9/poxvuUdP75kQm+tyyeNkVwSmRf9FNdTpqYkoIKZc5AS4dJuJaAuV/9nnJ4rofTafB/h2EQq6icCit6fV2DdU8mi2IT+MjHuKNKhx+dkihlf5+J4sQgnGNvC4Cd/VA1LsLp1dfGcft0vnTvFhQYkImIP3Fe0/vp8ISq9RrrI2fmPJKGhHmE1qmEnAxtr3wVrVt6CEmMvqyjjJ+QbcMSEu2i7LOKfd8LTrPsiG3M1VQwD66+enmrK14+XtS9cWHt2eAo9zM3dTjia/sfm83R28rA9DGsJ9Yux/JoqW1QOKMnoeXogwvjJg29zOTLl7Fhjdp6wtTIVOX7zD65W3V3LS93mWeMWXAEEChknsTlVfyirV9k6e7leQNTqN3hwz02Bp0Y1d2uHVNjC5CyDOiLhYxX/ybh28pZfCGEBQOQyLKny/UZVnUkMBf4Ux5sjCmQ+XsUGritFw3RtsODMekkT6WWSfACWp1RkKOHxbJ0penkX4JeQbvCkvd56VPLPSnL4xs38Sz6iCVPIIlvDyINZNjJSdBAgAH3Yu+uQDEdQvQTNKwtoZ3eso7kas+ePOAo7e6QB+b42mjD/fafAAJi9C2id/Jv/OEhh0lHc935j6CdNBINDuI1EmSnPOdv8XSN4WM+4/rJ6EhR3GRNqpB1bFCBgNt+I94//b8YpZIEY7CDxvkmQIXDairXsVso8w4zp/6fVFzHyveznW7Fq1ahjP7Hc6Cg7c1Eu/pVKtfBg88QNyYZLaXR+h/I3MftJp6yUL4pVKCSrsp6oDCDMNDF7K0+F18+eCgqwQD5OfTpXk1OCMgfNf6yNNY9rxreeIZarCcMczN/6zSb1UTa4fSgFBsATb/iEFxBsOq0NkOXbIheMEJV5hZvMT6iP6XiY9msmHqVgNEsnh47ieWWSq3Y70lYP7OTc5SvFxnGWSxoYsVsNrsSxb+YqXAR1cLMTmcdnFYHgNM3RAshwq1dfxQU7VUEGSQuzUcarUV2QvqSmUJWcYEEpP0CPvFjBmuAAD/6jbPMAzzbAmsU5rvsloStkL8xti5ktL19K76ZduFJO/BzkmugsGt4I/DVYfuh3JW4q1xZ+k4Ib+NDDfReLQIGVUAVgKu9OcrT2BJDPE204NnQyi9+kMqzF4OQ7I4ZjLKupwYZa7gMA6UL','2025-11-15 06:35:57','2025-11-15 19:39:02'),(16,'I-9075894264',25,'GOOGLE_REFRESH_TOKEN_OBJECT','U2FsdGVkX1/iKUVSxnhHB0ycKm04X9WZ+5sCiZ/Rci6dBWwqfvi/Yf6282mNIqbkP8DephaBvL/QlV+I91Wk/GXtVzqDaMPYEysUCJz7SOxX2M4My2vsAEocBNb3eE164N6spAKx6gc8jFJfCbbf0Oe7nYW3vYz0K14tCwZNcPEv6VMlEGq3Tq3Qsa+Mx21nqHEsDhyZNWby1Fs/Hib7kbdzWXOvsdecc2HNDozdslRh5gk0MOq0Z/57e+yVQINngguTJAV+duW0yKLGXNJptWOT37JF9VsNYJZjQTElaIXSLfHp9BDHP5CL0RhctwEILSPQNG/eKpkYmGHLG2mO9poTDv1Ozxk0+zVFDe5D2hLt6Tkk7QvXHQKQzhAsD1Rd+X8j2X/23cUOgbCm0BgZlKMmKjhP2EAFdfKSlrk5hPGUOFG7044M11fBFW10Vq6+KyYOaGfpImQc6l1JpD++yIUnwSU5HGUO47tzOpwQR7GYwkmaHR6iBCFkMiBqlnECs7WaCpmZFuto7uzm7S6exwO1vIrLQS1bpHkOro/VmLS1eD7LVeqXXct1BuRULDWQteK/1zh6zlXIqNtl6GZVpKdF9Dj8S0w2WXXLiZtIMUcF3U6ITcZWKzoCCaqWz2HTHkGwb7VrpuofIoiXxKXuuFqvWIMW7KH+LKXn68zuiEQlj2CahdKftisIp51T9h6VIyoXBNBho/cwU9Wo9x6J2Ax7kLLZhJCMfiqHlG90CZwPXQKPQFAggqb5mUPpJ4XxlkTZRhQ5S+b5iQfIPfoXTtXQIi5BhPrfLaHMxoFAke13kvWeHpc/jwB/t8wm8OmJGnYfd/04SsXFHCvbAY5VJqiUFESeNkPs/wzN90oJJmzyDRCiDDRHw+8/VF+BxJR0RlDs0r8cJ4lHKDcFf7+ei3hU2y6dhQangWC4zxJMeP5zQ/ZJpEU57/bZEyl4xTnM0vqHflto3yq8ihaBWE/OdEbbsU7FuEiGOgtqs64P/l5OGRRBebdJvzXi8p7FHZsAotY/tKz+H9HCW72l74Z9enn9JH3R0klZeggNtIYTysmsZHcCQRVFzH6Qnp/rigOk6ccYb83GS4Fz7Ugq10EOIDH1ii6qpKnjLmbgWoNdaEeARYAdpi58yOkQ2bzBLpDWIXcJ0z/eCvtTRt7WwrmaiacT4m6TicVEFkZV/YdkaHjcy3yBgvlep9Wjyl5R+GWPZ+sQT73YEMLq0DJiWvatPX9TNfeMRS9od1W2WdJpGxjkTwCEpkpwJRis+Xp7dsvGeWKpahUW5vzuF1+iTbT6CjU0jCD69Wfjor8kgb5YenzTW/aqyLxa+2/hhRc+bGZH9RToCCNMt7zujO9recctCk95+ZjsglnLOK2VEdPxqFdQKQzMbmngd+GmEzh6CF9X8TBUn6YHuyDH1hC0LVXeQd0O80PTVDsMd4mxVeOzwniQur344dLw/O+Wp1l2IVkgZo6+p2QBAnp8/GbLhPxr3NIFnnDduaNawf8TV1ScfxpVzKT1hPbvnmoojgw1mpwnYgBv1NvVK5YFWDyMU87RZFsbCNZSMu0BdyBjML9zBmMnYriBM+ujMI7e3++T/WhLPJ/owbIqdMvjbbmSXNz+2xQimZuozY8MijogyWs2bGjUznFZY6qeU+7QgdAtO/iuHqupvS3MNJtRLt2I40aIlZ6vwgAqojtrs8neC8HEAy4Km1v43yT2ZIm7fpsMSXZmk7OsCNh2xi3+8iW56OFWxww9V5yVLQC9h4/klVYzqhqU217a5JgN/vShVb0c2GT19/lpjGVT2oLCZhFBZQ5HjMwGFfwFPVPK2cZQ4ggCTRv79nApRhoaupCXN8RnsDEVW/ymWj3qzW0Re0CTVOQHI0UGYtlfPzt6MZeFVeTYQBdb8MW9x/hLq1UWH4RXGCnJWrCmsoE6rx3h2ZrvEB4BG0Qu3yiUWuCryrfPPVA1TnfjX9UpyPa3Gpjm8sHNIyYRGExxwM04DhqNMu8Ws2G1a0XLdRyxU7VEVt2JZFo7R0a72x2FOCKrzNdgeEi6B2ESP/9RUlahGzHk4Nr+fAGVLMwEd/ln/pcdQdHbnLF3cmlgx/XsZsiTjgN+GIbhVW3Zc7DKSYTZKrQU8MVsEFUib5gEIj2MlppuCMk129t7b1AHow1oxvuI5UpRgxDU/Z4XQXF2F4TMXtPTxVFy/gXFIluJbetOf1mwga3LxkqzmwiUaDuYskRvG7J6u8BKcKH8J55S04qHMinzmz0h8cSu/oEdKVgs7aYYXIHSW9SrR/ynWY5IG/TQ48FtVHD11u3j4VUtJ4RToYVLMuJk8dp0QUSqiBF2LiUSLVFAig+uMlMYK5mmbdUv/+hOBq+M9wQS0vB6q+BPzS1D2YXaYH3NbamNaktPSe8gwSECnK52ClJEpItupiUwNXL5glg5QzpOd4rqoiRR9fNEhT0jEtFtryeR6w1BzNXeZnY5HUBTtDJQeNKtqHCJ4Up5Q3oq9uAE8Om3JL1jLn2SZJLNqO9zWw1jHmn820mvr14aJzGrYttrymdqpmxgnV3Mc6ih5zwhdtr7ve36aiJ8fiSx+ofz6g==','2025-11-15 06:36:12','2025-11-20 11:35:15'),(18,'I-0102549419',25,'GOOGLE_INVENTORY_SHEET_ID','U2FsdGVkX19xl/pJZWXoUPwLaaPNDYCHJFi9v89xhk8JULguGdSDkZ2JUJSGSz0ypTHmG/gZQmta7MKeLDB12Q==','2025-11-15 06:36:28','2025-11-15 06:56:04'),(19,'I-7731023618',25,'GOOGLE_CLIENT_SECRET_OBJECT','U2FsdGVkX1/nVjTWpuMjkhiaJkKk9/eufbToVvYOtkKuVzGPPQSdN4+6Y071cy8Zf5bwbbZWdVehJEE4e0t9Uy+2cH4lqx4a3V5fTsrMf0zV+Pluylx3eNLLKEepmYrPyT+eZeP/TCgljgTbUHGIkdnpEZ8JhU7Bm2WgEFCM074BRpd6/FAsuYYPTANb6xL2P53n20BAsKzI9fMFqvyrnqGWCCSvS/MLWKV5oUJzDHPRdbdsn4WX+Kh2/Srkj8RNLsHTyqFgTHpSOFEwr/HvGpu4sFwniVP/eAtwpvVyH9QOgh07eaSrzNevhM0UP1jpbt78G0hkT/gugsIFgIOufnyeK77a/+3BHGyKLj1p4hyYvO8i8FP0W63yweU6pdH8oZvDv6CXtgtZtoQb0MNVf+3+mmfMqigMDh3/yAoiDkgQx249nt95vTCCToyo/jPc3ygWg8jWsCLcPehtUNwFo9ttDeyUyohkaX3KbWvx6VezSenrCtjJd8yu7cXX+ozeefJk164v5Zgvk+4LPSt3zKWYq+uwmJ8aTrtHnt2sR8Jk1jtyFmC8rig4T2h8yoze','2025-11-15 06:36:38','2025-11-15 19:38:34'),(21,'I-0092252766',25,'GOOGLE_INVENTORY_TAB_GID','U2FsdGVkX18L0lvxyS4E8TJoFwBBnRbsSyhG6fNZRh8=','2025-11-15 07:10:54','2025-11-15 07:10:54'),(22,'I-7244279441',25,'WAVE_ACCESS_TOKEN','U2FsdGVkX193jmocF48GJDMs3hS6MsOgMKeZNeG4doJz8EyEo2rswl8hwovN8+Eb','2025-11-15 17:42:52','2025-11-15 17:42:52'),(23,'I-5968931265',25,'WAVE_BUSINESS_ID','U2FsdGVkX1+oP44fsOXP3wYOhFA+SbtWKRChGhFYpgCOZcXp8tMf4MX9Tijh7pxXlbUM4bVEkpnLordp1ja9AsUKWEfeKWFC5BUilriGl08=','2025-11-15 17:43:08','2025-11-15 17:43:08'),(27,'I-0098297216',124,'GOOGLE_ADS_CAMPAIGN_ID','U2FsdGVkX19ZoaxscCmCGr7fKWzw9PLV4G6VtlhX0UM=','2025-11-18 08:51:26','2025-11-18 08:51:26'),(28,'I-7388032951',124,'GOOGLE_ADS_CLIENT_ID','U2FsdGVkX19zQqnu1fPxS+cvegs6DFA5r6gR+O6zmb2HzXbaDfraa62WWbYnepeVvd8apQoR6w9VhBIAV851I1CYFJfIqItBOytIyVl9dYk25iZmCs9K51TiAmHHGnXZ','2025-11-18 08:51:38','2025-11-18 08:51:38'),(29,'I-8468990082',124,'GOOGLE_ADS_CLIENT_SECRET','U2FsdGVkX1+xAq/+zFCuTnOsVW/UFhjSaE1z7kUA3Q/nO7UuiBgekCx3JdTy3kyh7ASzhgktR5CYnpRLIaM0iA==','2025-11-18 08:51:47','2025-11-18 08:51:47'),(30,'I-1511570799',124,'GOOGLE_ADS_DEVELOPER_TOKEN','U2FsdGVkX18xNlvGeFOcyh93MquBR85/pIjK5adj4nPIri377hwrAqxmGLbWDMNu','2025-11-18 08:51:54','2025-11-18 08:51:54'),(31,'I-8675675412',124,'GOOGLE_ADS_REFRESH_TOKEN','U2FsdGVkX1+a4t5nyAs9artvOh7F4mmGKkxtsBl2xjheeBcT9PPKZdhZ+pf++gxoqHJ7dj5PmEGBe51/aS40/C4MIumDn0IWfwMRcYYziX65/hzWYpgZ/KzPo+lgXi/lmCSr/WhSv3hTsDAGgoJcpcEMivFD3HVjfLlWvZKLfjw=','2025-11-18 08:52:03','2025-11-18 08:52:03'),(32,'I-4025563607',124,'GOOGLE_ADS_CUSTOMER_ID','U2FsdGVkX18I4fPSWxZq9DcL0rdMFLpaQHT+qT477Fg=','2025-11-18 08:52:09','2025-11-18 21:39:53');
/*!40000 ALTER TABLE `project_integrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_modules`
--

DROP TABLE IF EXISTS `project_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_modules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `module_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `module_identifier` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `settings` json DEFAULT NULL,
  `required_access` decimal(4,2) NOT NULL DEFAULT '1.00',
  `frontend_visible` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `module_id` (`module_id`),
  UNIQUE KEY `unique_project_idx_module_identifier` (`project_idx`,`module_identifier`),
  KEY `idx_project_idx` (`project_idx`),
  CONSTRAINT `project_modules_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_modules`
--

LOCK TABLES `project_modules` WRITE;
/*!40000 ALTER TABLE `project_modules` DISABLE KEYS */;
INSERT INTO `project_modules` VALUES (7,'M-6701354551','employees-module',25,'[]',1.00,1),(13,'M-6745899459','media-module',25,'[]',1.00,1),(21,'M-4123526402','customer-products-google-sheets-module',25,'[]',1.00,1),(22,'M-6804606366','customer-products-wix-sync-module',25,'[]',1.00,1),(23,'M-4954926823','google-module',25,'[]',1.00,1),(24,'M-7481788209','google-maps-api-module',25,'[]',1.00,1),(35,'M-4611457451','dashboard-module',25,'[]',1.00,1),(56,'M-5939305747','customer-products-module',25,'[]',1.00,1),(58,'M-1290498079','global-media-module',25,'[]',1.00,1),(59,'M-0950679887','pages-module',25,'[]',1.00,1),(62,'M-7404568025','customer-google-wave-sync-module',25,'[]',1.00,1),(63,'M-5835086121','customers-module',25,'[]',1.00,1),(64,'M-7818172343','google-ads-api-module',25,'[]',1.00,1),(65,'M-8244838421','media-module',124,'[]',1.00,1),(66,'M-5331469198','google-module',124,'[]',1.00,1),(67,'M-0198153017','dashboard-module',124,'[]',1.00,1),(68,'M-9983212730','google-ads-api-module',124,'[]',1.00,1),(71,'M-9222878192','google-gmail-module',25,'[]',1.00,1);
/*!40000 ALTER TABLE `project_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_pages`
--

DROP TABLE IF EXISTS `project_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_pages` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `page_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `parent_page_id` bigint DEFAULT NULL,
  `definition_id` bigint DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `ordinal` int NOT NULL DEFAULT '0',
  `seo_title` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8mb4_general_ci,
  `seo_keywords` json DEFAULT (json_array()),
  `template` varchar(100) COLLATE utf8mb4_general_ci DEFAULT 'default',
  `published` tinyint(1) DEFAULT '1',
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `page_id` (`page_id`),
  UNIQUE KEY `uq_project_slug` (`project_idx`,`slug`),
  KEY `parent_page_id` (`parent_page_id`),
  KEY `definition_id` (`definition_id`),
  CONSTRAINT `project_pages_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `project_pages_ibfk_2` FOREIGN KEY (`parent_page_id`) REFERENCES `project_pages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `project_pages_ibfk_3` FOREIGN KEY (`definition_id`) REFERENCES `page_definitions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_pages`
--

LOCK TABLES `project_pages` WRITE;
/*!40000 ALTER TABLE `project_pages` DISABLE KEYS */;
INSERT INTO `project_pages` VALUES (18,25,'P-2623065033',NULL,1,'Home','/',0,NULL,NULL,'[]',NULL,0,NULL,'2025-10-20 05:52:56',NULL),(37,25,'P-3369613688',NULL,1,'Services','/services',1,NULL,NULL,'[]',NULL,0,NULL,'2025-10-29 05:27:32','2025-10-29 09:41:05');
/*!40000 ALTER TABLE `project_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_sections`
--

DROP TABLE IF EXISTS `project_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_sections` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `section_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `parent_section_id` bigint DEFAULT NULL,
  `project_page_id` bigint NOT NULL,
  `definition_id` bigint DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `config` json DEFAULT (json_object()),
  `ordinal` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_id` (`section_id`),
  KEY `project_idx` (`project_idx`),
  KEY `project_page_id` (`project_page_id`),
  KEY `definition_id` (`definition_id`),
  CONSTRAINT `project_sections_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `project_sections_ibfk_2` FOREIGN KEY (`project_page_id`) REFERENCES `project_pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `project_sections_ibfk_3` FOREIGN KEY (`definition_id`) REFERENCES `section_definitions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_sections`
--

LOCK TABLES `project_sections` WRITE;
/*!40000 ALTER TABLE `project_sections` DISABLE KEYS */;
INSERT INTO `project_sections` VALUES (1,25,'PS-3886425456',NULL,18,1,'1','{\"text1\": \"12345679\"}',0,'2025-10-20 15:32:55','2025-10-30 04:20:05'),(3,25,'PS-2708413707',NULL,18,1,'2','{\"text1\": \"1252\"}',1,'2025-10-20 15:38:35','2025-10-30 04:20:05');
/*!40000 ALTER TABLE `project_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_themes`
--

DROP TABLE IF EXISTS `project_themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_themes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_id` bigint NOT NULL,
  `theme_id` bigint NOT NULL,
  `applied_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_id` (`project_id`),
  KEY `theme_id` (`theme_id`),
  CONSTRAINT `project_themes_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `project_themes_ibfk_2` FOREIGN KEY (`theme_id`) REFERENCES `themes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_themes`
--

LOCK TABLES `project_themes` WRITE;
/*!40000 ALTER TABLE `project_themes` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_users`
--

DROP TABLE IF EXISTS `project_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `clearance` decimal(4,2) NOT NULL DEFAULT '1.00',
  `invited_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_idx` (`project_idx`,`email`),
  CONSTRAINT `project_users_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_users`
--

LOCK TABLES `project_users` WRITE;
/*!40000 ALTER TABLE `project_users` DISABLE KEYS */;
INSERT INTO `project_users` VALUES (16,'opendreamstudios@gmail.com',25,9.00,'2025-08-27 10:54:27'),(67,'tannyspaacquisitions@gmail.com',25,8.00,'2025-11-03 22:25:49'),(70,'opendreamstudios@gmail.com',124,9.00,'2025-11-12 03:10:26'),(71,'opendreamstudios@gmail.com',132,9.00,'2025-11-20 09:45:32');
/*!40000 ALTER TABLE `project_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `short_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `domain` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `backend_domain` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `brand` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `logo` text COLLATE utf8mb4_general_ci,
  `logo_light` text COLLATE utf8mb4_general_ci,
  `logo_dark` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (25,'PROJ-90959de1e1d','TSA Backend','TSA','tannyspaacquisitions.com','https://tannyspaacquisitions.shop','Tanny Spa Acquisition','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F20119955-c59f-4a15-9f33-3ac3cbcbecfe.webp',NULL,NULL,'2025-08-27 10:54:27'),(124,'PROJ-6182098829','River Aware App','RiverAware',NULL,NULL,'RiverAware','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-6182098829%2F01783416-5428-4fef-a09b-df58f3cc2032.webp',NULL,NULL,'2025-11-12 03:10:26'),(132,'PROJ-3133159650','Tri Cities',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-20 09:45:32');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `section_definitions`
--

DROP TABLE IF EXISTS `section_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `section_definitions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `section_definition_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `identifier` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `parent_section_definition_id` bigint DEFAULT NULL,
  `allowed_elements` json DEFAULT (json_array()),
  `config_schema` json DEFAULT (json_object()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_definition_id` (`section_definition_id`),
  KEY `fk_section_definitions_parent` (`parent_section_definition_id`),
  CONSTRAINT `fk_section_definitions_parent` FOREIGN KEY (`parent_section_definition_id`) REFERENCES `section_definitions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section_definitions`
--

LOCK TABLES `section_definitions` WRITE;
/*!40000 ALTER TABLE `section_definitions` DISABLE KEYS */;
INSERT INTO `section_definitions` VALUES (1,'PSD-4713237590','Section 1','section-1',NULL,'[]','{\"fields\": [{\"key\": \"text1\", \"help\": \"\", \"type\": \"string\", \"label\": \"\", \"required\": true}]}'),(2,'PSD-2815477625','Section 1 IN','section-1',1,'[]','{\"fields\": []}');
/*!40000 ALTER TABLE `section_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `task_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `job_id` bigint DEFAULT NULL,
  `status` enum('waiting_work','waiting_parts','waiting_customer','complete','cancelled') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'waiting_work',
  `priority` enum('low','medium','high','urgent') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'medium',
  `scheduled_start_date` datetime DEFAULT NULL,
  `completed_date` datetime DEFAULT NULL,
  `task` text COLLATE utf8mb4_general_ci,
  `description` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_id` (`task_id`),
  KEY `project_idx` (`project_idx`),
  KEY `job_id` (`job_id`),
  CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tasks_ibfk_2` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3590 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` VALUES (1,'T-8871644771',25,NULL,'waiting_customer','low','2025-11-01 16:00:00',NULL,'blurred','blurred description','2025-09-20 00:23:22','2025-09-20 03:18:19'),(21,'T-6645762078',25,NULL,'waiting_work','medium','2025-09-20 02:54:58',NULL,NULL,NULL,'2025-09-20 02:54:58','2025-09-20 02:54:58'),(22,'T-6287357386',25,NULL,'waiting_work','medium','2025-09-20 02:56:00',NULL,NULL,NULL,'2025-09-20 02:56:00','2025-09-20 02:56:00'),(25,'T-7459029606',25,NULL,'complete','medium','2025-09-26 16:00:00',NULL,NULL,NULL,'2025-09-20 03:20:04','2025-09-20 03:20:25'),(29,'T-8584079177',25,NULL,'cancelled','medium','2025-09-20 03:27:33',NULL,'fjf jadsklfjas dfjasdf','asdasdf klasdjfk ajskdfasdasfd','2025-09-20 03:27:33','2025-09-20 03:57:49'),(48,'T-2033398800',25,NULL,'waiting_parts','urgent','2025-09-24 16:00:00',NULL,'testtt ','test 99','2025-09-20 04:02:28','2025-09-20 14:22:35'),(3369,'T-8038312328',25,NULL,'waiting_parts','medium','2025-09-19 21:50:10',NULL,NULL,NULL,'2025-09-20 21:50:10','2025-09-20 23:11:16'),(3395,'T-2992522073',25,10699,'complete','urgent','2025-09-17 16:35:13',NULL,'task for this day 2221',NULL,'2025-09-21 04:35:13','2025-09-22 22:44:45'),(3405,'T-0661674860',25,11292,'complete','medium','2025-09-21 14:16:34',NULL,NULL,'jkljkl','2025-09-21 22:16:34','2025-09-21 22:17:10'),(3412,'T-8294336944',25,11310,'complete','medium','2025-09-21 13:42:54',NULL,NULL,NULL,'2025-09-22 05:42:55','2025-09-22 18:54:47'),(3418,'T-0049794234',25,10699,'complete','medium','2025-09-21 12:25:58',NULL,'Get the water out',NULL,'2025-09-22 16:25:58','2025-09-22 22:07:09'),(3419,'T-1965096348',25,10699,'complete','medium','2025-09-21 20:26:00',NULL,'Run 100 miles',NULL,'2025-09-22 16:26:00','2025-09-22 19:11:47'),(3456,'T-1665666167',25,11378,'cancelled','medium','2025-09-22 10:44:47',NULL,NULL,'1234','2025-09-22 22:44:47','2025-09-22 23:15:31'),(3461,'T-7340791523',25,NULL,'waiting_work','high','2025-09-22 12:58:41',NULL,'Replace Spa Pack',NULL,'2025-09-23 00:58:41','2025-09-23 01:00:18'),(3464,'T-3248109094',25,NULL,'waiting_work','medium','2025-09-22 12:59:06',NULL,'Replace Left Side Panel',NULL,'2025-09-23 00:59:06','2025-09-23 01:00:18'),(3466,'T-7446057811',25,NULL,'waiting_work','medium','2025-09-22 12:59:29',NULL,'Scrub inside and power wash','Deep clean inside','2025-09-23 00:59:29','2025-09-23 01:00:18'),(3476,'T-3492602909',25,NULL,'cancelled','medium','2025-09-22 13:00:33',NULL,'Replace Broken Wiring',NULL,'2025-09-23 01:00:33','2025-09-23 03:03:15'),(3481,'T-4040632594',25,NULL,'cancelled','medium','2025-09-22 13:01:07',NULL,'Fix pump #3',NULL,'2025-09-23 01:01:08','2025-09-23 03:03:16'),(3484,'T-0846307826',25,NULL,'cancelled','medium','2025-09-22 13:01:33',NULL,'Deep Clean',NULL,'2025-09-23 01:01:33','2025-09-23 03:03:18'),(3489,'T-5987979072',25,11389,'complete','high','2025-09-22 13:02:20',NULL,'Retake Photos',NULL,'2025-09-23 01:02:20','2025-09-23 02:40:33'),(3491,'T-6942418300',25,11389,'complete','medium','2025-09-22 01:02:32',NULL,'125','Lower listing222','2025-09-23 01:02:32','2025-10-22 05:55:02'),(3495,'T-1510107546',25,11394,'waiting_work','medium','2025-09-22 17:02:50',NULL,'Routine Maintenance',NULL,'2025-09-23 01:02:50','2025-09-23 01:02:58'),(3498,'T-1067146813',25,11397,'waiting_work','medium','2025-09-22 21:03:13',NULL,NULL,NULL,'2025-09-23 01:03:13','2025-09-23 01:03:13'),(3499,'T-7232511547',25,NULL,'complete','urgent','2025-09-22 09:48:33',NULL,'Replace jet number 6','f','2025-09-23 01:48:33','2025-10-22 02:54:20'),(3508,'T-9970477989',25,NULL,'complete','high','2025-09-24 12:00:00',NULL,'3332','23234','2025-09-23 17:13:48','2025-09-23 17:15:41'),(3513,'T-4636108331',25,11449,'waiting_work','medium','2025-09-23 01:48:00',NULL,NULL,'jjjnjljkl','2025-09-23 17:48:00','2025-09-24 06:59:40'),(3518,'T-7536541938',25,11449,'waiting_customer','medium','2025-09-23 10:01:18',NULL,NULL,NULL,'2025-09-23 18:01:18','2025-09-25 20:16:26'),(3519,'T-5848530814',25,11449,'waiting_work','medium','2025-09-23 14:01:19',NULL,NULL,NULL,'2025-09-23 18:01:19','2025-09-23 18:01:19'),(3534,'T-8238115249',25,11389,'complete','medium','2025-10-21 13:54:34',NULL,'3','31234','2025-10-22 05:54:34','2025-10-22 05:55:25'),(3535,'T-4550256466',25,11389,'waiting_work','medium','2025-10-22 01:54:36',NULL,NULL,NULL,'2025-10-22 05:54:36','2025-10-22 05:54:36'),(3536,'T-4228873083',25,11389,'waiting_work','medium','2025-10-22 01:54:37',NULL,NULL,NULL,'2025-10-22 05:54:37','2025-10-22 05:54:37'),(3537,'T-1657710988',25,11389,'waiting_work','medium','2025-10-22 01:54:38',NULL,NULL,NULL,'2025-10-22 05:54:38','2025-10-22 05:54:38'),(3547,'T-7565486808',25,11788,'waiting_work','medium','2025-10-22 14:43:03',NULL,NULL,NULL,'2025-10-22 18:43:03','2025-10-22 18:43:03'),(3548,'T-1997773484',25,11867,'waiting_customer','high','2025-10-30 12:00:00',NULL,NULL,NULL,'2025-10-26 10:35:40','2025-10-26 10:35:57'),(3552,'T-2046810699',25,11864,'complete','high','2025-10-26 03:15:02',NULL,'Deep Clean','kk','2025-10-26 11:15:02','2025-10-26 11:15:18'),(3561,'T-0304603638',25,11892,'complete','urgent','2025-10-31 08:21:44',NULL,'plumbing','fix leaks','2025-10-31 20:21:44','2025-11-03 22:36:16'),(3569,'T-5237105127',25,11892,'waiting_work','medium','2025-11-03 17:34:55',NULL,NULL,NULL,'2025-11-03 22:34:56','2025-11-03 22:34:56'),(3576,'T-4713919051',25,11904,'waiting_work','medium','2025-11-03 18:41:42',NULL,NULL,NULL,'2025-11-03 23:41:42','2025-11-03 23:41:42'),(3577,'T-6173575164',25,NULL,'waiting_work','medium','2025-11-04 11:41:25',NULL,NULL,'Fix leak','2025-11-04 21:41:25','2025-11-04 21:42:49'),(3579,'T-5810103042',25,NULL,'waiting_work','medium','2025-11-04 11:42:12',NULL,NULL,'Fix FLO code','2025-11-04 21:42:13','2025-11-04 21:42:49'),(3585,'T-0433325488',25,11986,'complete','medium','2025-11-11 18:56:57',NULL,NULL,NULL,'2025-11-12 19:56:57','2025-11-17 19:21:08');
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `themes`
--

DROP TABLE IF EXISTS `themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `themes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `config` json NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `themes`
--

LOCK TABLES `themes` WRITE;
/*!40000 ALTER TABLE `themes` DISABLE KEYS */;
/*!40000 ALTER TABLE `themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `twilio_apps`
--

DROP TABLE IF EXISTS `twilio_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `twilio_apps` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `numbers` json DEFAULT NULL,
  `connected_numbers` json DEFAULT NULL,
  `account_sid` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `auth_token` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `api_key` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `api_secret` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `twiml_app_sid` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `project_idx` (`project_idx`),
  CONSTRAINT `twilio_apps_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `twilio_apps`
--

LOCK TABLES `twilio_apps` WRITE;
/*!40000 ALTER TABLE `twilio_apps` DISABLE KEYS */;
INSERT INTO `twilio_apps` VALUES (1,25,'[2319772866]','[5555555555]','AC1e9b18783f8c5979d852d4f7c483535d','6d2703bac920551eb6d2a930619d5daa','SK8d7be33a280a57200e6523d3e73ac06d','M8kNMT9MVCCTsyPux4kFEibqeUyd0Fow','AP3d9642cc096ac1058867c490faf273c4','2025-09-24 19:18:28');
/*!40000 ALTER TABLE `twilio_apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(200) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `first_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `profile_img_src` text COLLATE utf8mb4_general_ci,
  `theme` enum('light','dark') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'dark',
  `auth_provider` enum('google','facebook','discord','local') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'local',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `password_reset` varchar(6) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password_reset_timestamp` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=516 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (505,'aa575ab285f793e2c90c3aa0aba675','opendreamstudios@gmail.com',NULL,1,'Open','Dream','https://lh3.googleusercontent.com/a/ACg8ocLQ1SpRJ3iL9bKeqTyDRLVrBwV-_EG2BfjGosZdVZEZE5LcpFg=s96-c','dark','google','2025-08-23 17:13:30',NULL,NULL),(506,'cf529e7f470b9f8e028a0623758fe2','joeygoff9@gmail.com',NULL,0,'Joseph','Goff','https://lh3.googleusercontent.com/a/ACg8ocJMBGdEobMVL6BENlpzVnpzWNPSaUDGLBwEvqwaA5slOEN8Hg=s96-c','dark','google','2025-08-25 11:58:18',NULL,NULL),(507,'4b502ebba70edd84e920d669aa208b','joeygoff13@gmail.com',NULL,0,'Joseph','Goff','https://lh3.googleusercontent.com/a/ACg8ocKj9bTTTYqctXRWGJGdiCuGnpCfHdDolJrPnKEU4xp9FRNmXQ=s96-c','dark','google','2025-08-25 20:49:45',NULL,NULL),(509,'ffdf0a0d739fb087a4ffc188cac7f2','joeygoff99@gmail.com','$2a$10$PeA/DxBOkS3.krq5lUrJc.LXyX60y42Ua5n8lONO/fQ5TKAqUCLw2',0,'Jo','Go',NULL,'dark','local','2025-10-25 03:20:58',NULL,NULL),(510,'cc83de1ab8d5a8afa54b3404415051','infinityslide03@gmail.com',NULL,0,'Infinity','Slide','https://lh3.googleusercontent.com/a/ACg8ocKf49XhE8QxQ11AyzgIEaOI0Xo2FZdGovEGC4MtqOfY7Oa3nA=s96-c','light','google','2025-10-31 04:12:02',NULL,NULL),(512,'7920795e8f0b51b7e0580070b43ce5','opendreamai@gmail.com',NULL,0,'Joey','Goff','https://lh3.googleusercontent.com/a/ACg8ocIrOB6FrhB2b9jqf8CGpY56GhQoMqNcQBVVNI4o4kqMtmOl-Q=s96-c','dark','google','2025-10-31 19:56:30',NULL,NULL),(513,'38350829bbc92ba9fdb786f42fd043','johndenver@gmail.com','$2a$10$TT1j59Us1Z3oTDyhlkJGc.BOR6MqJQeKjWxH9Atenrj6vP81/HmzS',0,'John','Denv',NULL,'light','local','2025-10-31 20:04:38',NULL,NULL),(514,'0dc1a0202416936f0386e2b6972ef5','infinityslide01@gmail.com','$2a$10$PcZyiXk8s5z8nH2kJhf1Pu2wQB2OLlPYi87b9HyDIAxYw9G/8wEwa',0,'Infinity','Slide',NULL,'light','local','2025-10-31 20:59:39','586797','2025-11-05 22:29:22'),(515,'30b909a2823e7a6dac6839cdcfab9d','tannyspaacquisitions@gmail.com',NULL,0,'Tanny','Spa Acquisitions','https://lh3.googleusercontent.com/a/ACg8ocLapr65yPV_chL_g-CPEhSchwkcxi9Mi--Ie8No_Vh5AvfoFw=s96-c','dark','google','2025-11-03 22:30:07',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'cms'
--

--
-- Dumping routines for database 'cms'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-21 16:08:09

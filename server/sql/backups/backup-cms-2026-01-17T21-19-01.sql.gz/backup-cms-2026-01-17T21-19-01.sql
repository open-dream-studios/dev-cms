-- MySQL dump 10.13  Distrib 9.3.0, for macos14.7 (arm64)
--
-- Host: gondola.proxy.rlwy.net    Database: cms
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `action_definitions`
--

DROP TABLE IF EXISTS `action_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `action_definitions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `action_definition_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `parent_action_definition_id` bigint DEFAULT NULL,
  `project_idx` bigint NOT NULL,
  `identifier` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `action_definition_id` (`action_definition_id`),
  UNIQUE KEY `project_idx` (`project_idx`,`identifier`),
  KEY `fk_action_definitions_parent` (`parent_action_definition_id`),
  CONSTRAINT `action_definitions_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_action_definitions_parent` FOREIGN KEY (`parent_action_definition_id`) REFERENCES `action_definitions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action_definitions`
--

LOCK TABLES `action_definitions` WRITE;
/*!40000 ALTER TABLE `action_definitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `action_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `actions`
--

DROP TABLE IF EXISTS `actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `actions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `action_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `job_id` varchar(35) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `customer_id` varchar(35) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `action_definition_id` varchar(35) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` enum('open','on_hold','complete','cancelled') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'open',
  `priority` enum('low','medium','high','urgent') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'medium',
  `scheduled_start_date` datetime DEFAULT NULL,
  `completed_date` datetime DEFAULT NULL,
  `title` text COLLATE utf8mb4_general_ci,
  `description` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `action_id` (`action_id`),
  KEY `project_idx` (`project_idx`),
  KEY `job_id` (`job_id`),
  KEY `customer_id` (`customer_id`),
  KEY `action_definition_id` (`action_definition_id`),
  CONSTRAINT `actions_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `actions_ibfk_2` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`job_id`) ON DELETE SET NULL,
  CONSTRAINT `actions_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE SET NULL,
  CONSTRAINT `actions_ibfk_4` FOREIGN KEY (`action_definition_id`) REFERENCES `action_definitions` (`action_definition_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actions`
--

LOCK TABLES `actions` WRITE;
/*!40000 ALTER TABLE `actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignments`
--

DROP TABLE IF EXISTS `assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assignments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `employee_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `task_id` varchar(35) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `job_id` varchar(35) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_employee_task` (`employee_id`,`project_idx`,`task_id`),
  UNIQUE KEY `uq_employee_job` (`employee_id`,`project_idx`,`job_id`),
  KEY `project_idx` (`project_idx`),
  KEY `assignments_ibfk_3` (`task_id`),
  KEY `assignments_ibfk_4` (`job_id`),
  CONSTRAINT `assignments_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assignments_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE,
  CONSTRAINT `assignments_ibfk_3` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`task_id`) ON DELETE CASCADE,
  CONSTRAINT `assignments_ibfk_4` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`job_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_only_one` CHECK ((((`task_id` is not null) and (`job_id` is null)) or ((`task_id` is null) and (`job_id` is not null))))
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignments`
--

LOCK TABLES `assignments` WRITE;
/*!40000 ALTER TABLE `assignments` DISABLE KEYS */;
INSERT INTO `assignments` VALUES (2,25,'E-6303779525','T-2992522073',NULL,'2025-09-22 19:35:27'),(3,25,'E-6789064209','T-7340791523',NULL,'2025-09-23 00:58:54'),(5,25,'E-6263820295','T-7446057811',NULL,'2025-09-23 00:59:42'),(7,25,'E-6789064209','T-3492602909',NULL,'2025-09-23 01:00:59'),(11,25,'E-6263820295','T-5987979072',NULL,'2025-09-23 02:40:28'),(12,25,'E-6303779525','T-9970477989',NULL,'2025-09-23 17:14:00'),(13,25,'E-6303779525','T-4636108331',NULL,'2025-09-23 17:51:25'),(16,25,'E-6263820295',NULL,'J-7496083178','2025-09-27 23:21:17'),(20,25,'E-6303779525','T-7232511547',NULL,'2025-09-28 00:25:40'),(24,25,'E-6303779525','T-1997773484',NULL,'2025-10-26 10:35:49'),(25,25,'E-6263820295','T-2046810699',NULL,'2025-10-26 11:15:14'),(28,25,'E-6263820295',NULL,'J-3046793295','2025-11-03 23:41:38'),(30,25,'E-6263820295','T-4713919051',NULL,'2025-11-03 23:41:44'),(31,25,'E-6303779525','T-4713919051',NULL,'2025-11-03 23:41:44'),(32,25,'E-0306494859','T-6173575164',NULL,'2025-11-04 21:42:07'),(33,25,'E-6263820295','T-5810103042',NULL,'2025-11-04 21:42:31'),(35,25,'E-8101316451','T-7631104588',NULL,'2025-11-25 20:49:01'),(36,25,'E-6263820295','T-9793937077',NULL,'2025-11-25 20:52:23'),(37,25,'E-6263820295','T-9055200375',NULL,'2025-11-25 20:53:58'),(38,25,'E-0306494859','T-5496719116',NULL,'2025-12-02 17:42:22'),(39,25,'E-0306494859','T-0178430366',NULL,'2025-12-02 17:42:51'),(40,25,'E-7652882889','T-3508672292',NULL,'2025-12-02 17:44:19'),(41,25,'E-7652882889','T-5501540662',NULL,'2025-12-02 17:45:17'),(42,25,'E-7652882889','T-1577724853',NULL,'2025-12-02 17:46:59'),(43,25,'E-6263820295','T-0325121942',NULL,'2025-12-02 22:04:19'),(44,25,'E-6263820295',NULL,'J-7261169558','2025-12-02 22:14:36'),(45,25,'E-6263820295','T-2887350048',NULL,'2025-12-02 22:14:59'),(46,25,'E-6263820295',NULL,'J-4137806502','2025-12-02 22:22:05'),(47,25,'E-6789064209','T-1796696036',NULL,'2025-12-02 22:22:20'),(48,25,'E-6789064209',NULL,'J-1697647729','2025-12-02 22:46:53'),(49,25,'E-6789064209','T-8850594181',NULL,'2025-12-02 22:47:10'),(50,25,'E-6263820295','T-2512488422',NULL,'2025-12-05 19:56:11');
/*!40000 ALTER TABLE `assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_data`
--

DROP TABLE IF EXISTS `business_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `business_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `business_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `business_review_count` bigint DEFAULT NULL,
  `business_rating` decimal(2,1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `business_id` (`business_id`),
  KEY `project_idx` (`project_idx`),
  CONSTRAINT `business_data_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_data`
--

LOCK TABLES `business_data` WRITE;
/*!40000 ALTER TABLE `business_data` DISABLE KEYS */;
INSERT INTO `business_data` VALUES (1,'BIZ-01KE8HM0SMG54N1RZK23YV7D8H',25,17,4.4);
/*!40000 ALTER TABLE `business_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calls`
--

DROP TABLE IF EXISTS `calls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calls` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `call_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `aircall_call_id` bigint NOT NULL,
  `call_uuid` text COLLATE utf8mb4_general_ci,
  `direction` text COLLATE utf8mb4_general_ci,
  `from_number` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `to_number` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `ended_at` timestamp NULL DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `status` text COLLATE utf8mb4_general_ci,
  `agent_id` bigint DEFAULT NULL,
  `agent_name` text COLLATE utf8mb4_general_ci,
  `agent_email` text COLLATE utf8mb4_general_ci,
  `hangup_cause` text COLLATE utf8mb4_general_ci,
  `recording_url` text COLLATE utf8mb4_general_ci,
  `transcription` json DEFAULT NULL,
  `aircall_direct_link` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `call_id` (`call_id`),
  UNIQUE KEY `aircall_call_id` (`aircall_call_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calls`
--

LOCK TABLES `calls` WRITE;
/*!40000 ALTER TABLE `calls` DISABLE KEYS */;
INSERT INTO `calls` VALUES (4,25,'CALL-1299891804',3349828783,'CA953e4067d4a1486e6ff225380d155b6b','inbound','6176510598','9843588401','2025-12-10 15:06:00','2025-12-10 15:06:18',18,'done',1801089,'Test User2','infinityslide02@gmail.com',NULL,'https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/recordings/7bb40dd4-6008-4c9d-93ea-828eebc06922.mp3','[{\"text\": \"Hey, Paul. Uh, could you please help me out here? Thank you.\", \"speaker\": \"speaker_0\"}]','https://api.aircall.io/v1/calls/3349828783','2025-12-10 20:06:25'),(5,25,'CALL-6819701971',3352782862,'CAd54b2db1b7d942cb74125d6717f8e8c0','inbound','6176510598','9843588401','2025-12-11 11:13:54','2025-12-11 11:14:19',26,'done',1801089,'Test User2','infinityslide02@gmail.com',NULL,'https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/recordings/6998472c-a131-453b-bc40-79ed1a2d4235.mp3','[{\"text\": \"Testing, one, two, three. Testing, one, two, three.\", \"speaker\": \"speaker_0\"}]','https://api.aircall.io/v1/calls/3352782862','2025-12-11 16:14:27'),(6,25,'CALL-1717774916',3352789008,'CA5f6cfce493e5a601cd64a48850ce0f96','inbound','6176510598','9843588401','2025-12-11 11:15:08','2025-12-11 11:15:38',30,'done',1801089,'Test User2','infinityslide02@gmail.com',NULL,'https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/recordings/fbd8d936-ffb2-4938-ae27-e87d08caf7bf.mp3','[{\"text\": \"Hello? \", \"speaker\": \"speaker_0\"}, {\"text\": \"Hi, this is TSA. Thanks for calling. How can we help you today? \", \"speaker\": \"speaker_1\"}, {\"text\": \"Fuck off, bitch.\", \"speaker\": \"speaker_0\"}]','https://api.aircall.io/v1/calls/3352789008','2025-12-11 16:15:46'),(7,25,'CALL-1373976669',3353058680,'CAce5721093d361caa385e8887cad3365a','inbound','6176510598','9843588401','2025-12-11 17:16:52','2025-12-11 17:17:08',16,'done',1801089,'Test User2','infinityslide02@gmail.com',NULL,'https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/recordings/de69f3b2-6746-42ba-a0b9-e3400b500cc1.mp3',NULL,'https://api.aircall.io/v1/calls/3353058680','2025-12-11 17:17:14'),(8,25,'CALL-1007313110',3353130191,'CA683f234610f758dfd240464e465590cb','inbound','6176510598','9843588401','2025-12-11 17:38:21','2025-12-11 17:38:42',22,'done',1802313,'Brandon Tanny','tannyspaacquisitions@gmail.com',NULL,'https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/recordings/bceec982-170b-4d64-9f11-5977e551b59a.mp3',NULL,'https://api.aircall.io/v1/calls/3353130191','2025-12-11 17:38:48'),(9,25,'CALL-9182383812',3361781096,'CA196b0335635065d89da252986fbb9118','inbound','6176510598','9843588401','2025-12-15 21:22:07','2025-12-15 21:22:48',40,'done',1801089,'Test User2','infinityslide02@gmail.com',NULL,'https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/recordings/3edc26a1-9b3d-4d46-a08d-3110784a52cc.mp3','[{\"text\": \"(bemol)\", \"speaker\": \"speaker_0\"}]','https://api.aircall.io/v1/calls/3361781096','2025-12-15 21:22:55');
/*!40000 ALTER TABLE `calls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversation_messages`
--

DROP TABLE IF EXISTS `conversation_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversation_messages` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `message_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `conversation_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `user_from` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `user_to` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `message_text` text COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `message_id` (`message_id`),
  KEY `idx_conv_created` (`conversation_id`,`created_at`),
  KEY `fk_conv_messages_project` (`project_idx`),
  KEY `idx_conv_messages_latest` (`conversation_id`,`created_at` DESC),
  CONSTRAINT `fk_conv_messages_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`conversation_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_conv_messages_project` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversation_messages`
--

LOCK TABLES `conversation_messages` WRITE;
/*!40000 ALTER TABLE `conversation_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversation_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversation_participants`
--

DROP TABLE IF EXISTS `conversation_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversation_participants` (
  `conversation_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`conversation_id`,`user_id`),
  CONSTRAINT `fk_conv_participants_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`conversation_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversation_participants`
--

LOCK TABLES `conversation_participants` WRITE;
/*!40000 ALTER TABLE `conversation_participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversation_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversations`
--

DROP TABLE IF EXISTS `conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `conversation_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `conversation_id` (`conversation_id`),
  KEY `project_idx` (`project_idx`),
  CONSTRAINT `conversations_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversations`
--

LOCK TABLES `conversations` WRITE;
/*!40000 ALTER TABLE `conversations` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `customer_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address_line1` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address_line2` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `state` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `zip` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_id` (`customer_id`),
  KEY `project_idx` (`project_idx`),
  CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4041 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (267,25,'C-3271831449','scott','johnson','calvin8@aol.com','3153741369','7001 Bayview Drive','','Sodus Point','New York','14555',NULL,'2025-11-04 15:13:56','2025-11-18 07:56:19'),(270,25,'C-8223585718','dave','anderson','dganders@gmail.com','5858571443','1080 Willits Road','','Ontario','New York','14519','','2025-11-04 21:26:48','2025-11-18 07:56:16'),(272,25,'C-1008185348','matt','vancuran','','5854023186','2733 Pre Emption Street','','Geneva','New York','14456',NULL,'2025-11-05 17:22:12','2025-11-16 06:58:59'),(273,25,'C-9105548245','barbra','strother',NULL,NULL,'eerw',NULL,'',NULL,NULL,'Interested in hot tub #67','2025-11-05 22:17:15','2025-11-16 06:58:59'),(275,25,'C-7572301199','matt','lance','','7162900829',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-07 16:00:57','2025-11-16 06:58:59'),(277,25,'C-3460280222','jim','hawryliak','jim@consolidatedagencyinc.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(278,25,'C-7864448867','john','deleo','nuclearfly@outlook.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(279,25,'C-9998711169','tom','eadie','tceadie7@gmail.com','5857375824',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(280,25,'C-8099234824','denise','waddell-conte','dwadconte@gmail.com','7025217996',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(282,25,'C-7005802063','peter','ragusa','peter@hawthorneandeast.com','5857497117',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(283,25,'C-1844384248','mary','anne lynch','nymom12103@aol.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(284,25,'C-8671345830','peter','ragusa','peter@hawthoprneandeast.com','5857497117',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-16 07:26:15'),(285,25,'C-1934322243','thomas','bowden','thomascbowden@gmail.com','5403922654',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(286,25,'C-0730955508','cathy','saxton','cathysaxtonx@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(287,25,'C-1635972419','john','hennessy','jhennesey8@rochester.rr.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(288,25,'C-1906234797','degwanda','gause','dedegause38@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(289,25,'C-4645674187','frankie','carmine','frankandcarmine@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(290,25,'C-2638898186','ken','dauphinee','kensellshomes@frontier.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(291,25,'C-4377446644','shane','hirt','sdh@dukeprops.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(292,25,'C-6053822490','ron','palermo','palemro@rochester.rr.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(293,25,'C-9715681737','mark','leach','markleach@rochester.rr.com','5855766605',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(294,25,'C-3313673793','dan','bell','dan44bell@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(295,25,'C-6243765262','steve','bumpus','steve.bumpus@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(296,25,'C-2345653283','jared','coates','jaredcoates@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(297,25,'C-1950795636','jay','caltagarone','cesfieldservice@gmail.com','8145411912',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(298,25,'C-6579163172','randy','fiege','rfiege@yahoo.com','5859430925',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(299,25,'C-2596550173','glen','tinsley','gtinsley1@rochester.rr.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(300,25,'C-8807747146','john','reynolds','johnjreynolds@aol.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(301,25,'C-3989705465','dan','rohr','screwgates@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(302,25,'C-5436789632','victor','flow','jeanneflow1234@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(303,25,'C-8373457101','angel','diaz','adunique8809@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(304,25,'C-0679713479','tyler','fleming','tfleming88@me.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:14'),(305,25,'C-1310986999','scott','rothfuss','lischer86@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(306,25,'C-5271322403','jeff','cottrone','jeffcottrone@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(307,25,'C-3962793761','kane','buholtz','kbuholtz33@gmail.com','5853294989',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(308,25,'C-9760237329','robert','merkov','rmerkov@aol.com','5857562143',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(309,25,'C-7236357792','anna','patton','golfercop@hotmail.com','3155739567',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(310,25,'C-7588299811','steve','milne','puntar10@aol.com','5854902967',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(311,25,'C-8599505575','greg','gorcica','ggorcica@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(312,25,'C-3223771343','denise','darling','littledarling.dd@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(313,25,'C-1036953989','sam','tarellis','samsoneyes@aol.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(314,25,'C-4845255427','mustafa','erturk','mustafa@24medx.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:15','2025-11-18 07:56:15'),(315,25,'C-4503586755','steve','reczek','stevereczek@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(316,25,'C-2610723963','danielle','arena','deearena339@yahoo.com','5853508693',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(317,25,'C-6652513575','bill','naylon','bill.naylon@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(318,25,'C-4509265693','joanne','siwinski','jsiwinski56@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(319,25,'C-2131385962','sarah','kluger','haderster@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(320,25,'C-3202105944','mario','belpanno','dreamstarr1@aol.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(321,25,'C-8520664078','sadie','szrama','sadieszrama@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(322,25,'C-1168154649','rick','hessney','rhessney@gmail.com','9173558332',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(323,25,'C-8796641978','rick','andrews','randrew7@rochester.rr.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(324,25,'C-6312857355','mansour','farhadian','jfarhadian2@aol.com','9177010638',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(325,25,'C-4227800762','bernadette','colon','bernadettecolon1969@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(326,25,'C-9542077127','ginny','nelson','ibeginny@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(327,25,'C-0507715728','jason','cordy','jasoncordy311@gnail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(328,25,'C-9140403434','barry','slater','barryslater55@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(329,25,'C-5109563345','paul','morabito','paul.morabito@gmail.com','5859448977',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(330,25,'C-5104552144','michael','wolak','mwolakjr@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(331,25,'C-0074856550','harwinber','teur','kharwinder847@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(332,25,'C-1520294392','curtis','signorino','curt.signorino@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(333,25,'C-9853237106','sean','carroll','scarroll@rwearl.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(334,25,'C-4489037489','matthew','schoell','matthewschoell@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(335,25,'C-5416205011','alex','bielecki','bieleckifamily4@gmail.com','5858570083',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(336,25,'C-4395275454','julia','duerr','jjbean80@yahoo.com','7165238621',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(337,25,'C-5722190461','jason','camilo','jasoncamilo001@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(338,25,'C-2061042943','samuel','desalvo','scdesalvo@gmail.com','5856153246',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(339,25,'C-3701030563','ben','corke','corke.usnc@gmail.com','5857033167',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(340,25,'C-9589403143','jordan','evans','jdevans22@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(341,25,'C-4363970922','ron','prapani','tbirdland@aol.com','5855067180',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(342,25,'C-7016426620','samantha','kerr','samanthammincer@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(343,25,'C-2447398345','peggy','thomas','pthomaslvstriplej@yahoo.com','5857197753',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(344,25,'C-4171685442','devin','hogan','devinhogan.mail@gmail.com','5853036740',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(345,25,'C-6752821525','scott','fitzgerald','scfitz_69@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(346,25,'C-9888682759','peter','foti','lugbolt@hotmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(347,25,'C-8848874690','kim','martinod','kmartinod@gmail.com','8602879993',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(348,25,'C-5397349318','tom','aponte','tapont117@yahoo.com','5856135511',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(349,25,'C-4798608212','sarah','carpino','sleath1@gmail.com','5855066685',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(350,25,'C-9894567546','mike','cadle','mcadle07@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:15'),(351,25,'C-3604239999','nicole','fazio','nicole.a.fazio@proton.me',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(352,25,'C-5688145628','larry','wilson','lawrencewilson83@yahoo.com','5856941803',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(353,25,'C-4718449304','darrin','henderberg','darrin.henderberg@xylem.com','6154798942',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(354,25,'C-4992123002','david','gurzynski','dg2922@rochester.rr.com','5857295130',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(355,25,'C-6565523213','roby','reinhart','reinhartroby@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(356,25,'C-2110368669','matt','mattison','mattsshaq32@hotmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(357,25,'C-7642730509','mike','humphrey','mhumphrey@leroycsd.org','5857520626',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(358,25,'C-8380845342','elizabeth','gagnier','eokardas@gmail.com','8454894167',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(359,25,'C-6035322193','rocco','distaffen','roccoagency@yahoo.com','5857520626',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(360,25,'C-3757843684','barbara','grady','bsg51new@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:16','2025-11-18 07:56:16'),(361,25,'C-6295295278','barry','garigen','bjgarigen@gmail.com','5853562739',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(362,25,'C-4756926943','jason','renkert','jrr0423@hotmail.com','5853305155',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(363,25,'C-1920067526','matthew','delaura','matthewrdelaura@gmail.com','5853034809',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(364,25,'C-9519950796','erin','des grange','tweenybode@rochester.rr.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(365,25,'C-2275962594','martha','ternoois','mternoois1@gmail.com','3155213055',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(366,25,'C-6091953598','nick','coco','ncoco2626@yahoo.com','5857212626',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(367,25,'C-0328644768','donald','schichler','donschich@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(368,25,'C-0156285020','edward','lin','eplin.md@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(369,25,'C-6467338695','randi','cowen','rcowen6@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(370,25,'C-6575064294','amy','ricotta','ajricotta@me.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(371,25,'C-9821250806','ken','keller','ken.keller.46@gmail.com','5852811050',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(372,25,'C-0707345402','john','adams','johnwadams79@gmail.com','5853139889',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(373,25,'C-3164259930','lia','bopp','liabopp22@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(374,25,'C-5546156988','mary','feeney','shopperfeeney@aol.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(375,25,'C-5998822978','ken','rando','kenrando@gmail.com','5852332557',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(376,25,'C-5082313980','naama','tapiero','naama.tapiero@gmail.com','9495015424',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(377,25,'C-5519786531','maryam','parker','maryamparker1@gmail.com','5852828901',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(378,25,'C-7587602061','john','dickquist','johndickquist@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(379,25,'C-8960982788','lucas','southerland','lucasearl32s@yahoo.com','5852021017',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(380,25,'C-0227718392','jose','ramos','codis1923@yahoo.com','5856236854',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(381,25,'C-1534538276','bev','cosner','dbarnhart@rochester.rr.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(382,25,'C-6637140545','joy','grow','joygrow70@gmail.com','5859675790',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(383,25,'C-4358285061','cheryl','jones-richter','cjonesrichter@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,'I (Brandon) spoke with Cheryl on the phone 01/06/2025:\n - Told her there was a mixup with her cover and it came but it is the wrong size\n- I offered a refund for the cover and she elected to have us order a new cover instead\n- cover ordered 1/6/25\n','2025-11-16 07:26:17','2026-01-06 20:31:58'),(384,25,'C-3826762146','richard','farmer','rfarmer1863@gmail.com','5857708715',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(385,25,'C-4685134352','andriy','romanyuk','aromanyuk1@gmail.com','5853016680',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(386,25,'C-8785249946','pete','hamanne','hamanne_peter@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(387,25,'C-0470795020','sam','cooper','samcooper342@gmail.com','7138254916',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(388,25,'C-7783729900','gary','harris','geharris53@gmail.com','5853308471',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(389,25,'C-3318439614','jean','hamel','jphamel@frontiernet.net',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(390,25,'C-8185773887','jerry','diodato','gdiodato@rochester.rr.com','5857757547',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(391,25,'C-5832348413','matt','cottone','mikecottone1@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(392,25,'C-9381133914','casey','blackburn','caseymahler@gmail.com','5857279599',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(393,25,'C-3336348705','genevieve','halligan','genevievezaharia@gmail.com','7854778817',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(394,25,'C-9456958041','joshua','fisher','joshua.p.fisher45@gmail.com','5852965835',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(396,25,'C-9007219207','matt','hannafon','mhannafon@gmail.com','5854782708',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(397,25,'C-9898488282','bob','janson','bdj82@yahoo.com','5857501412',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:16'),(398,25,'C-7709177640','lisa','smith','lsmithbaskets@aol.com','5859448731',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(399,25,'C-9047667489','mike','guzewicz','mongo1972@hotmail.com','3157290359',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(400,25,'C-6431870371','bob','hilbert','rsh071359@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(401,25,'C-7195169937','jose','rosenbaum','jose_rosenbaum@yahoo.com','5854697073',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(402,25,'C-5550986841','mark','spade','mark.spade@yahoo.com','5853819640',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(403,25,'C-4781403725','amy','delucia','amyjonewman@hotmail.com','3157277191',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(404,25,'C-7570915072','gary','gokey','flipahouse@rochester.rr.com','5857041906',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(405,25,'C-3406151114','beth','knickerbocker','knick155@frontiernet.net','5854784023',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(406,25,'C-9926412503','sean','hale','sean.m.hale@gmail.com','7162667221',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(407,25,'C-4853727461','sherry','thireom','sheilaschmeer@gmail.com','5853176112',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(408,25,'C-4695319826','tanner','morse','tannermorse2207@gmail.com','6073467780',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:17','2025-11-18 07:56:17'),(409,25,'C-4359550992','carol','hopper','whooper@rochester.rr.com','5857524141',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(410,25,'C-1344855702','lianna','dupree','smileslkm@gmail.com','5858136944',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(411,25,'C-5100024815','mike','stacy','mstacy@rochester.rr.com','5856709154',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(412,25,'C-0532331651','deli','cozzarelli','jdec@verizon.net','7164356407',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(413,25,'C-8581471769','mike','johnson','whitey1mj@me.com','5857508234',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(414,25,'C-6432524856','nancy','turnerprice','nancyprice123@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(415,25,'C-5399967063','taylor','rivera','lexandtrivie@gmail.com','5857501905',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(416,25,'C-9237191050','erik','rankin','rankin33@live.com','7166972090',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(417,25,'C-2438840526','jim','lewis','james.l.lewis@gmail.com','7039896774',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(418,25,'C-7141399510','gingerbread','man','williamrobertfallon@gmail.com','4237963624',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(419,25,'C-6114666908','jennifer','miles','jenmiles0719@gmail.com','5855324799',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(420,25,'C-4947870020','david','hermans','dhermans@rochester.rr.com','5857052722',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(421,25,'C-9017596635','erin','stefanovic','eking515@gmail.com','5857339075',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(422,25,'C-6960743492','kevin','gloff','kgloff@gmail.com','5853290728',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(423,25,'C-9414231021','chris','chilson','houseja.chsn@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(424,25,'C-5480017688','lisa','rennell','lisarennell@gmail.com','5853299969',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(425,25,'C-4640032494','carla','morris','cmpasq@yahoo.com','5857941702',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(426,25,'C-2902122392','roger','breedlove','rbreed5190@aol.com','5852021629',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(427,25,'C-6001721225','collin','floom','cfloom@gmail.com','7206018202',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(428,25,'C-2732157374','bruce','parkinson','bcparkinson82@gmail.com','3153596321',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(429,25,'C-0045434350','matthew','calder','calder.matthew@yahoo.com','5857031194',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(430,25,'C-9957764156','jacob','norris','jakenorris910@gmail.com','5852615185',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(431,25,'C-3346562782','john','mcentee','jjmcentee@gmail.com','5857219047',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(432,25,'C-3582935273','remle','gear','geashel@gmail.com','5856135652',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(433,25,'C-3518732689','emily','jones','emilyjone@gmail.com','5853178860',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(434,25,'C-8466939820','kim','fasciano','kim.fasciano@gmail.com','5852618325',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(435,25,'C-5066877605','mike','miles','fishergrad2005@gmail.com','5853131173',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(436,25,'C-5706198703','john','crowley','jcrowley@biznetix.net','5853292924',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(437,25,'C-8007580516','carl','mcdade','chipmcdade@yahoo.com','5859643659',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(438,25,'C-6943962952','steve','morland','droldsmorland@yahoo.com','5857609411',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(439,25,'C-8165229252','mari','louise harrow','marilousie.harrow@gmail.com','5854413899',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(440,25,'C-6404905983','kim','kreischer','kim.krisher@outlook.com','5857097671',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(441,25,'C-3844441517','charles','howard','charlesphoward62@yahoo.com','5857461159',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(442,25,'C-6904536398','windell','grey','wgray@landonrian.com','5852020808',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:17'),(444,25,'C-6855396297','morgan','martin','mo4620@gmail.com','5857467303',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(445,25,'C-3113499817','steve','gerbowski','marygrabowski33@gmail.com','5857489396',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(446,25,'C-9321703841','jeff','ternoois','uniquegardensheds@gmail.com','5857346559',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(448,25,'C-1319142887','jack','paulson','jpaulson17a@gmail.com','5857473837',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(449,25,'C-0202621936','bob','welch','jwelch14@rochester.rr.com','5857507268',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(450,25,'C-3949762390','dan','gaita','tam48d@yahoo.com','5852986188',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(451,25,'C-2647638245','val','berger','vberger4830@gmail.com','5854096896',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(452,25,'C-3686689572','katie','lynn','dkpynn@hotmail.com','5853301364',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(453,25,'C-1940817926','daphne','sesnie','dsesnie521@gmail.com','5859670291',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(454,25,'C-8607845139','alex','hawkins','cweibel2@gmail.com','8128276415','','','','','',NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(455,25,'C-2026178260','bill','messmer','bandmpaving@frontiernet.net','5853297474',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:18','2025-11-18 07:56:18'),(456,25,'C-1516769668','phil','mccord','phillip.mccord@gmail.com','7209372588',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(457,25,'C-8759749331','tracey','cornish','traceylcornish@gmail.com','5857493677',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(458,25,'C-7322669873','tracey','cornish','traceylcornish@gmail.com','5857493677',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-16 07:26:19'),(459,25,'C-2948315266','tracy','cornish','tracylcornish@gmail.com','5857493677',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(460,25,'C-8476373885','ronda','howard','nyhow@yahoo.com','5853469478',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(461,25,'C-8158649051','wesley','moon','serenna.roose@gmail.com','5853297592',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(462,25,'C-4177390739','sarah','perlin','skloves@yahoo.com','5857051358',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(463,25,'C-3500405110','shelly','gately','rmgately@gmail.com','5853561743',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(464,25,'C-4267880966','steve','bergonzi','stephen.bergonzi@gmail.com','5856224357',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(465,25,'C-8406232136','steve','bergonzi','stephen.bergonzi@prudential.com','5856224357',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-16 07:26:19'),(466,25,'C-1854105400','bernie','lehman','bernie@lehmannstrings.com','3012223336',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(467,25,'C-1043446659','tamara','gaita','tam48d@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(468,25,'C-2806663177','bill','intres','bill.intres@gmail.com','3157431807',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(469,25,'C-3264710576','kristen','means','fish4k@hotmail.com','5853144765',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(470,25,'C-8171958520','cassie','hughes','cassiehughes1@hotmail.com','5856894566',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(471,25,'C-1450623262','pam','rector','2002@yahoo.com','5857376647',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(472,25,'C-7700896404','marty','pierce','lenorah22pierce@yahoo.com','5183370282',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(473,25,'C-1553781429','lori','johnson','lorriejohn1@gmail.com','5857337881',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(474,25,'C-2890885933','david','dimmet','dzimmet@gmail.com','5859432710',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(475,25,'C-9796608347','gavin','barry','barry.gavin@gmail.com','5854290127',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(476,25,'C-9668528057','jeff','reidmiller','jwa8929@aol.com','5856157031',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(477,25,'C-1635913494','jj','anglert','jeffrey9896@gmail.com','5859677721',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(478,25,'C-5159274287','taylor','spragge','tspragge@protonmail.com','5853398619',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(479,25,'C-9433845444','mike','perri','mike.perri@yahoo.com','5859576252',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(480,25,'C-8038642926','marcelle','nascimento','mmatosnf@gmail.com','3526823431',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(481,25,'C-7978908832','garrett','traver','gtraver@rochester.rr.com','5853706741',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(482,25,'C-0196888097','david','cook','dcook10@rochester.rr.com','5853292818',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(483,25,'C-0691574291','norma','haffey','nhaffey@rochester.rr.com','5852699047',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(484,25,'C-7415731789','jeff','reidmiller','jeffreidmiller@hotmail.com','5856157031',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-16 07:26:19'),(485,25,'C-4602590358','kyle','miller','millerthepillar@gmail.com','8017099624',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(486,25,'C-0366252589','sindon','hendrickson','shendrickson@sedgwickbusiness.com','5856100008',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:18'),(487,25,'C-2174137889','jay','parnes','jayparnes@gmail.com','5857372784',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(488,25,'C-4202379333','lori','vero','laurievero@gmail.com','5859553542',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(489,25,'C-2250946670','michael','o\'connell','nytrooperdad@yahoo.com','6075920473',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(490,25,'C-0899045089','micheal','hendryx','dj1900hendryx@yahoo.com','5859810064',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(491,25,'C-9299253975','traci','ruffell','truffell2@gmail.com','5855450515',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(492,25,'C-2434357785','traci','ruffel','truffell2@gmail.com','5855450515',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(493,25,'C-7171777760','kathy','ellin','chansam4@yahoo.com','5854552283',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(494,25,'C-6605743575','stony','point hoa c/o kendrick corporation','jscarpulla@kenrickfirst.com','5859443336',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(495,25,'C-0811309623','joe','hamm','joe.m.hamm@gmail.com','5857049467',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(496,25,'C-9001488700','michael','napoli','mn.86@hotmail.com','5853336672',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(497,25,'C-9784917356','dru','turk','druturk@yahoo.com','3158822888',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(498,25,'C-0713322781','vince','giardino','vince.giar@gmail.com','5853704039',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(499,25,'C-8037519036','mike','spilberg','spigs838@yahoo.com','3155463742',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(500,25,'C-9399987117','guy','vanhoover','littlebun750@frontiernet.net','5854720164',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(501,25,'C-9042577948','paul','richards','paulnrichards606@gmail.com','5857270359',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(502,25,'C-9657430260','pete','henderson','phenderson2@rochester.rr.com','5857474659',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:19','2025-11-18 07:56:19'),(503,25,'C-4264426615','joan','zimmerman','jezimmer46@gmail.com','5857395801',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(504,25,'C-2487114132','tom','wooldridge','alywool@gmail.com','5852173405',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(506,25,'C-5083490102','nicole','berardo','berardnm@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(507,25,'C-3561959415','john','dimarzio','john@maxxexchange.com','5853033054',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(508,25,'C-8859684240','stephen','fish','sfish132@gmail.com','5855071815',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(509,25,'C-2950118494','chris','johnson','johnsons.rochester@gmail.com','5857946403',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(510,25,'C-1078802799','david','cook','davidcook2818@gmail.com','5853292818',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-16 07:26:20'),(511,25,'C-5231655073','scott','miller','scott@scottmillerstyle.com','5857522651',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(512,25,'C-2826125440','kody','wagner','kodywagner9@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(514,25,'C-9066068055','doug','labell','labellboug@yahoo.com','5853038800',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(515,25,'C-5181801264','mark','graney','markcgraney@gmail.com','5852812369',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(516,25,'C-4371687351','lynn','taliento','igwt27@yahoo.com','5853549239',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(517,25,'C-3636761215','keith','wilson','kwil1027@frontiernet.net','5853773378',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(518,25,'C-7086742572','patrick','rausch','christine.ridarsky@gmail.com','5857476393',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(519,25,'C-0091624888','doug','magde','dougmagde@gmail.com','5857330402',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(520,25,'C-2752938210','tina','fountaine','tmf46@icloud.com','5858572499',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(521,25,'C-4769315791','rob','opett','robertopett@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(522,25,'C-0004996229','leronne','evans','leronneevans@yahoo.com','5857216857',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(523,25,'C-0891797348','alex','pratt','alex.w.pratt@gmail.com','7147669530',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(524,25,'C-1369263704','eric','wilder','eric.charles.wilder@gmail.com','5858089047',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(525,25,'C-1173949307','lori','murnne','lori.murnane@yahoo.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(526,25,'C-0809908662','tim','daley','daleytim84@gmail.com','5853153484',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(527,25,'C-2544113776','tammy','davidson','tammyjodavidson@gmail.com','5852592751',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(528,25,'C-8439600349','nick','willcox','nickwilcox.wilcox@gmail.com','5856265269',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(529,25,'C-5732611907','tasia','ortiz','ortiz.tasia00@gmail.com','5854903862',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(530,25,'C-1904964661','mary','ann','maryannrhp@gmail.com','7149168662',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(531,25,'C-0432114919','justin','daley','daleyju08@gmail.com','5856135319',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(532,25,'C-3699857811','virginia','meier','vlm@rochester.rr.com','5857664838',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(533,25,'C-8741558711','kristen','dodds','kdodds12707@gmail.com','5857759603',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:19'),(534,25,'C-4992597727','frank','stanish','fstanish@rochester.rr.com','5852489685',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:20'),(535,25,'C-3563963487','ralph','folino','rfolino2654@gmail.com','5853979250',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:20'),(536,25,'C-9039942357','patrick','krenzer','pkrenzer@rochester.rr.com','5856156994',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:20'),(537,25,'C-4688976324','marzena','dominek','mdominek@yahoo.com','5854048664',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:20'),(538,25,'C-8446088972','leslie','hoff','lesliejk31@gmail.com','5856439534',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:20'),(539,25,'C-8867172667','mariah','ehresman','mariaehres@aol.com','5855091160',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:20'),(540,25,'C-7903700466','christopher','sprague','cspra3@gmail.com','5853556925',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 07:26:20','2025-11-18 07:56:20'),(3373,25,'C-9608043818','adnan','tawseeq','adnan.m22.10@gmail.com','5856228516',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 09:34:44','2025-11-18 07:56:18'),(3443,25,'C-6104309335','alan','dungey','adungey1217@gmail.com','5857973171',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 09:34:44','2025-11-18 07:56:19'),(3473,25,'C-2359180592','austin','allen','','3159091297','176 South Main Street','','Naples','New York','14512','								11/10/25\nWants catalina spa & electrical\n\nAgreed on 5500 and penciled in a calendar date of 12/4 subject to change\nWaiting on deposit\n','2025-11-17 16:18:28','2025-11-17 16:19:02'),(3475,25,'C-0421402435','david','lieberman','lieberda@gmail.com','5617064348',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-18 07:56:02','2025-11-18 07:56:14'),(4005,25,'C-0005609356','ken','rando',NULL,'5852332557',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-25 20:38:09','2025-11-25 20:38:09'),(4007,25,'C-9861846607','soloman','tam','oranspitzer@gmail.com','5164011653','9 Rose Rd',NULL,'Rochester','NY','14624','Purchased a restoration in Nov 2025','2025-12-02 22:10:19','2025-12-02 22:10:41'),(4009,25,'C-0505723429','paul','anastasia','anastasi42270@hotmail.com','5857291677','141 Bram Hall Dr','','Rochester','NY','14626','Purchased restoration in Nov 2025','2025-12-02 22:19:46','2025-12-02 22:19:46'),(4018,136,'C-1961576981','wqe','fdqw',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-03 06:02:15','2025-12-03 06:02:15'),(4026,25,'C-1362139054','todd','smith','todd.smith@leonardsexpress.com','5856833640','521 N Main St',NULL,'Canandaigua','NY','14424','Bought tub #80 on 12/05/2025\nsent venmo deposit of $260 to Griffin ','2025-12-05 19:54:31','2025-12-05 19:54:31'),(4027,25,'C-8146998977','joey','goff','joeygoff13@gmail.com','6176510598','',NULL,NULL,NULL,NULL,NULL,'2025-12-11 15:47:34','2025-12-18 05:03:57'),(4033,25,'C-9026873971','adam','hahnel','ahahnel409@gmail.com','5856839686',NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-18 05:03:29','2025-12-18 05:03:40'),(4038,25,'CUST-01KEFCC4QH539631C1S3M0TCJ1','julie','kramp',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-08 18:02:19','2026-01-08 18:02:19'),(4040,25,'CUST-01KEFHW28KJ8AC18PHB5X6QK44','kristen','fox','obrn9377@gmail.com','3154141949','9377 Tosch Road',NULL,'Wolcott','NY','14590',NULL,'2026-01-08 19:38:24','2026-01-08 19:38:24');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `employee_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address_line1` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address_line2` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `state` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `zip` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `position` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `department` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `hire_date` datetime DEFAULT NULL,
  `termination_date` datetime DEFAULT NULL,
  `notes` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employee_id` (`employee_id`),
  KEY `project_idx` (`project_idx`),
  CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=215 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (115,25,'E-6263820295','Paul','Tanny','paultanny@gmail.com','1425342342','','','','','','CEO BITCH YUHHHHHHHH','Service',NULL,NULL,'','2025-09-22 10:54:33','2025-12-22 23:13:01'),(130,25,'E-6789064209','Brandon','Tanny','brandontanny@gmail.com','1384824232','','','','','','Owner & CEO','',NULL,NULL,'','2025-09-22 10:59:11','2025-12-16 23:15:36'),(133,25,'E-6303779525','Joey','Goff','joeygoff13@gmail.com','6037276444','1140 Commonwealth Avenue','','Boston','Massachusetts','02134','Type Shit','',NULL,NULL,'','2025-09-22 10:59:29','2025-12-03 04:20:52'),(185,25,'E-0306494859','James','Ludwig','','5853513662','','','','','','Shop Technician','Work Shop',NULL,NULL,'','2025-11-03 23:33:22','2025-11-03 23:33:36'),(188,25,'E-8101316451','Roger','Thomas','','3157054864','','','','','','','',NULL,NULL,'','2025-11-03 23:34:09','2025-12-22 23:12:57'),(197,25,'E-7652882889','Griffin','Tanny','griffinmtanny@gmail.com','','','','','','','Salesman','Sales',NULL,NULL,'','2025-12-02 17:44:07','2025-12-02 20:22:03'),(206,136,'E-4469397747','Dsrf','Wer','','','','','','','','','',NULL,NULL,'','2025-12-04 17:48:12','2025-12-04 17:48:12');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimation_costs`
--

DROP TABLE IF EXISTS `estimation_costs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimation_costs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `estimate_cost_id` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  `estimate_run_idx` bigint NOT NULL,
  `cost_node_idx` bigint NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `min_cost` decimal(12,2) NOT NULL,
  `max_cost` decimal(12,2) NOT NULL,
  `applied_facts` json NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `estimate_cost_id` (`estimate_cost_id`),
  KEY `estimate_run_idx` (`estimate_run_idx`),
  KEY `cost_node_idx` (`cost_node_idx`),
  CONSTRAINT `estimation_costs_ibfk_1` FOREIGN KEY (`estimate_run_idx`) REFERENCES `estimation_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `estimation_costs_ibfk_2` FOREIGN KEY (`cost_node_idx`) REFERENCES `estimation_graph_nodes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimation_costs`
--

LOCK TABLES `estimation_costs` WRITE;
/*!40000 ALTER TABLE `estimation_costs` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimation_costs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimation_fact_definitions`
--

DROP TABLE IF EXISTS `estimation_fact_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimation_fact_definitions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fact_id` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `fact_key` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `fact_type` enum('boolean','number','string','enum') COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fact_id` (`fact_id`),
  UNIQUE KEY `unique_fact_key` (`project_idx`,`fact_key`),
  CONSTRAINT `estimation_fact_definitions_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimation_fact_definitions`
--

LOCK TABLES `estimation_fact_definitions` WRITE;
/*!40000 ALTER TABLE `estimation_fact_definitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimation_fact_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimation_facts`
--

DROP TABLE IF EXISTS `estimation_facts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimation_facts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `estimate_fact_id` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  `estimate_run_idx` bigint NOT NULL,
  `fact_key` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `fact_value` json NOT NULL,
  `source_node_idx` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `estimate_fact_id` (`estimate_fact_id`),
  KEY `estimate_run_idx` (`estimate_run_idx`),
  KEY `source_node_idx` (`source_node_idx`),
  CONSTRAINT `estimation_facts_ibfk_1` FOREIGN KEY (`estimate_run_idx`) REFERENCES `estimation_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `estimation_facts_ibfk_2` FOREIGN KEY (`source_node_idx`) REFERENCES `estimation_graph_nodes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimation_facts`
--

LOCK TABLES `estimation_facts` WRITE;
/*!40000 ALTER TABLE `estimation_facts` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimation_facts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimation_graph_edges`
--

DROP TABLE IF EXISTS `estimation_graph_edges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimation_graph_edges` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `edge_id` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  `graph_idx` bigint NOT NULL,
  `from_node_idx` bigint NOT NULL,
  `to_node_idx` bigint NOT NULL,
  `edge_condition` json NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `edge_id` (`edge_id`),
  KEY `graph_idx` (`graph_idx`),
  KEY `from_node_idx` (`from_node_idx`),
  KEY `to_node_idx` (`to_node_idx`),
  CONSTRAINT `estimation_graph_edges_ibfk_1` FOREIGN KEY (`graph_idx`) REFERENCES `estimation_graphs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `estimation_graph_edges_ibfk_2` FOREIGN KEY (`from_node_idx`) REFERENCES `estimation_graph_nodes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `estimation_graph_edges_ibfk_3` FOREIGN KEY (`to_node_idx`) REFERENCES `estimation_graph_nodes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimation_graph_edges`
--

LOCK TABLES `estimation_graph_edges` WRITE;
/*!40000 ALTER TABLE `estimation_graph_edges` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimation_graph_edges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimation_graph_nodes`
--

DROP TABLE IF EXISTS `estimation_graph_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimation_graph_nodes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `node_id` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  `graph_idx` bigint NOT NULL,
  `node_type` enum('question','cost') COLLATE utf8mb4_general_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `config` json NOT NULL,
  `position` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `node_id` (`node_id`),
  KEY `graph_idx` (`graph_idx`),
  CONSTRAINT `estimation_graph_nodes_ibfk_1` FOREIGN KEY (`graph_idx`) REFERENCES `estimation_graphs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimation_graph_nodes`
--

LOCK TABLES `estimation_graph_nodes` WRITE;
/*!40000 ALTER TABLE `estimation_graph_nodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimation_graph_nodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimation_graphs`
--

DROP TABLE IF EXISTS `estimation_graphs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimation_graphs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `graph_id` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `graph_type` enum('decision','pricing') COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `status` enum('draft','published','archived') COLLATE utf8mb4_general_ci DEFAULT 'draft',
  `version` int NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `graph_id` (`graph_id`),
  UNIQUE KEY `unique_graph_version` (`project_idx`,`graph_type`,`version`),
  CONSTRAINT `estimation_graphs_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimation_graphs`
--

LOCK TABLES `estimation_graphs` WRITE;
/*!40000 ALTER TABLE `estimation_graphs` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimation_graphs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimation_runs`
--

DROP TABLE IF EXISTS `estimation_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimation_runs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `estimate_run_id` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `decision_graph_idx` bigint NOT NULL,
  `pricing_graph_idx` bigint NOT NULL,
  `created_by` bigint DEFAULT NULL,
  `status` enum('in_progress','completed','archived') COLLATE utf8mb4_general_ci DEFAULT 'in_progress',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `estimate_run_id` (`estimate_run_id`),
  KEY `project_idx` (`project_idx`),
  KEY `decision_graph_idx` (`decision_graph_idx`),
  KEY `pricing_graph_idx` (`pricing_graph_idx`),
  CONSTRAINT `estimation_runs_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `estimation_runs_ibfk_2` FOREIGN KEY (`decision_graph_idx`) REFERENCES `estimation_graphs` (`id`),
  CONSTRAINT `estimation_runs_ibfk_3` FOREIGN KEY (`pricing_graph_idx`) REFERENCES `estimation_graphs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimation_runs`
--

LOCK TABLES `estimation_runs` WRITE;
/*!40000 ALTER TABLE `estimation_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimation_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimation_summary`
--

DROP TABLE IF EXISTS `estimation_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimation_summary` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `estimate_summary_id` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  `estimate_run_idx` bigint NOT NULL,
  `total_min` decimal(12,2) NOT NULL,
  `total_max` decimal(12,2) NOT NULL,
  `inferred_tier` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `confidence_notes` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `estimate_summary_id` (`estimate_summary_id`),
  KEY `estimate_run_idx` (`estimate_run_idx`),
  CONSTRAINT `estimation_summary_ibfk_1` FOREIGN KEY (`estimate_run_idx`) REFERENCES `estimation_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimation_summary`
--

LOCK TABLES `estimation_summary` WRITE;
/*!40000 ALTER TABLE `estimation_summary` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimation_summary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_definitions`
--

DROP TABLE IF EXISTS `job_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_definitions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_definition_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `identifier` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `parent_job_definition_id` bigint DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_definition_id` (`job_definition_id`),
  UNIQUE KEY `uniq_project_identifier` (`project_idx`,`identifier`),
  KEY `fk_job_definitions_parent` (`parent_job_definition_id`),
  CONSTRAINT `fk_job_definitions_parent` FOREIGN KEY (`parent_job_definition_id`) REFERENCES `job_definitions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_definitions_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_definitions`
--

LOCK TABLES `job_definitions` WRITE;
/*!40000 ALTER TABLE `job_definitions` DISABLE KEYS */;
INSERT INTO `job_definitions` VALUES (3,'ceafbe9ab524f622',25,'sale-job',NULL,'Sale','Acquire and resell a hot tub','2025-09-17 18:13:35','2026-01-03 20:20:49'),(4,'96b8b901175a8492',25,'refurbishment-job',NULL,'Refurbishment','Customer tub refurbishment','2025-09-17 18:20:37','2026-01-03 20:20:49'),(5,'644b82387191f696',25,'service-job',NULL,'Service','Customer tub service job','2025-09-17 18:20:55','2026-01-03 20:20:49'),(13,'JOBDEF-01KEJM0WYWVR0815GETECMB9ZA',25,'tub-maintenance-service',5,'Tub Maintenance','Tub Maintenance Service','2026-01-10 00:13:43','2026-01-10 00:14:04'),(14,'JOBDEF-01KEJM1CJP8AK3KKAJX32F0VVT',25,'deck-build-service',5,'Deck Build','Deck Build Service','2026-01-10 00:13:59','2026-01-10 00:13:59');
/*!40000 ALTER TABLE `job_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `job_definition_id` bigint DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `customer_id` bigint DEFAULT NULL,
  `valuation` decimal(10,2) DEFAULT NULL,
  `status` enum('waiting_diagnosis','waiting_work','waiting_parts','waiting_listing','listed','waiting_customer','waiting_delivery','complete','delivered','cancelled') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'waiting_work',
  `priority` enum('low','medium','high','urgent') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'medium',
  `scheduled_start_date` datetime DEFAULT NULL,
  `completed_date` datetime DEFAULT NULL,
  `notes` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_id` (`job_id`),
  KEY `project_idx` (`project_idx`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `job_definition_id` (`job_definition_id`),
  CONSTRAINT `jobs_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `jobs_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `jobs_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `jobs_ibfk_4` FOREIGN KEY (`job_definition_id`) REFERENCES `job_definitions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12224 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (10699,'J-7777109774',25,4,NULL,NULL,0.00,'waiting_parts','high','2025-10-16 04:00:00','2025-10-30 23:30:00','Job description','2025-09-20 23:11:52','2025-09-22 22:07:19'),(11292,'J-0466133491',25,5,NULL,NULL,0.00,'complete','urgent','2025-09-17 05:00:00','2025-09-18 04:00:00',NULL,'2025-09-21 22:09:41','2025-09-21 22:18:00'),(11310,'J-8354539608',25,4,NULL,NULL,0.00,'delivered','high','2025-09-16 04:00:00','2025-09-22 04:00:00',NULL,'2025-09-21 23:11:29','2025-09-22 19:12:48'),(11378,'J-3046026214',25,3,NULL,NULL,NULL,'waiting_work','medium',NULL,NULL,NULL,'2025-09-22 22:41:59','2025-09-22 22:41:59'),(11389,'J-5646467867',25,3,NULL,NULL,339.00,'delivered','high','2025-09-03 04:00:00','2025-09-10 04:00:00',NULL,'2025-09-23 01:02:01','2025-10-22 18:24:56'),(11394,'J-5061611354',25,5,NULL,NULL,0.00,'waiting_work','medium',NULL,NULL,NULL,'2025-09-23 01:02:45','2025-09-23 01:02:58'),(11397,'J-5592745445',25,4,NULL,NULL,NULL,'waiting_work','medium',NULL,NULL,NULL,'2025-09-23 01:03:06','2025-09-23 01:03:06'),(11449,'J-7496083178',25,5,NULL,NULL,0.00,'complete','medium','2025-09-25 04:00:00','2025-10-01 04:00:00',NULL,'2025-09-23 17:15:47','2025-10-20 17:19:27'),(11788,'J-8199885383',25,4,NULL,NULL,0.00,'delivered','medium','2025-10-08 04:00:00','2025-10-10 04:00:00','12342342','2025-10-22 18:42:34','2025-10-22 18:50:07'),(11794,'J-9946270990',25,5,NULL,NULL,NULL,'waiting_work','medium',NULL,NULL,NULL,'2025-10-22 23:46:52','2025-10-22 23:46:52'),(11795,'J-5414692569',25,4,NULL,NULL,0.00,'waiting_work','medium','2025-10-15 04:00:00','2025-10-16 15:30:00','hello!!!','2025-10-25 02:30:06','2025-10-25 07:27:22'),(11797,'J-8323419864',25,4,NULL,NULL,0.00,'waiting_work','medium','2025-11-13 05:00:00','2025-11-18 05:00:00',NULL,'2025-10-25 02:39:08','2025-10-25 23:16:18'),(11864,'J-3076511985',25,4,NULL,NULL,0.00,'delivered','medium','2025-10-02 04:00:00','2025-10-03 04:00:00',NULL,'2025-10-26 10:34:09','2025-10-29 06:20:15'),(11867,'J-9833765612',25,5,NULL,NULL,33.00,'waiting_work','medium',NULL,NULL,NULL,'2025-10-26 10:35:21','2025-10-29 23:08:48'),(11880,'J-5680526789',25,3,NULL,NULL,33.42,'cancelled','medium','2025-10-31 04:00:00','2025-11-02 04:00:00',NULL,'2025-10-29 23:07:22','2025-10-30 04:20:24'),(11892,'J-9453891954',25,5,NULL,NULL,0.00,'waiting_work','urgent','2025-10-09 04:00:00','2025-10-31 20:45:00',NULL,'2025-10-30 04:45:42','2025-11-03 23:11:32'),(11904,'J-3046793295',25,3,NULL,NULL,4650.00,'waiting_work','medium',NULL,NULL,NULL,'2025-11-03 23:22:04','2025-11-03 23:26:14'),(11978,'J-2390119693',25,5,369,NULL,0.00,'complete','medium','2025-11-04 05:00:00','2025-11-04 06:00:00','Drain + clean of swim spa\nFull winterization \nStart: 10:30am \nEnd: 2:30pm\n\nWinterization: 750\nClean: 500','2025-11-05 15:58:02','2025-11-05 16:10:05'),(11986,'J-8262245758',25,3,368,NULL,2650.00,'listed','urgent','2025-11-20 05:00:00','2025-11-28 05:00:00',NULL,'2025-11-05 16:25:11','2025-12-22 20:01:05'),(11987,'J-0304529701',25,3,372,4026,2650.00,'delivered','urgent','2025-12-11 14:00:00','2025-12-11 18:30:00','Deliver tub\nremove old tub\nBring spa care kit\nbring cover lifter that is currently attached to white marble jacuzzi #80\ntake his cover lifter back to our shop (bottom mount cover lifter)','2025-11-05 16:25:22','2026-01-13 22:49:29'),(11988,'J-3069170594',25,3,366,270,0.00,'delivered','medium',NULL,NULL,NULL,'2025-11-05 16:25:43','2025-11-26 17:13:28'),(11993,'J-6698749251',25,3,373,NULL,2650.00,'listed','urgent',NULL,NULL,NULL,'2025-11-05 16:28:49','2025-12-19 16:38:06'),(12004,'J-6668891028',25,3,390,NULL,2650.00,'delivered','urgent',NULL,NULL,NULL,'2025-11-07 15:35:34','2026-01-16 16:04:17'),(12024,'J-3600230389',124,NULL,399,NULL,NULL,'waiting_work','medium',NULL,NULL,NULL,'2025-11-12 07:44:00','2025-11-12 07:44:00'),(12046,'J-0430747833',25,5,430,4005,0.00,'waiting_work','urgent','2025-12-03 17:00:00','2025-12-03 20:00:00','Ken Rando Service Call\n\nNeeds:\n- waterfall still ordered (only have 1)\n- cover to be ordered','2025-11-25 20:43:11','2025-11-25 20:51:50'),(12055,'J-9298968009',25,5,430,4005,0.00,'waiting_work','urgent','2025-12-03 17:00:00','2025-12-03 20:00:00','Ken Rando Service Call\n\nNeeds:\n- waterfall still ordered (only have 1)\n- cover to be ordered','2025-11-25 20:54:02','2025-11-25 20:54:02'),(12071,'J-5945848088',25,3,363,270,3650.00,'listed','medium',NULL,NULL,'Fix and post for sale again','2025-12-02 17:41:22','2025-12-22 21:45:35'),(12090,'J-5525540383',136,NULL,448,NULL,0.00,'waiting_parts','medium','2025-12-10 05:00:00','2025-12-11 05:00:00','77777','2025-12-02 21:11:47','2025-12-03 05:35:23'),(12126,'J-5098928401',25,4,453,296,0.00,'waiting_work','high',NULL,NULL,NULL,'2025-12-02 22:02:13','2025-12-02 22:02:17'),(12128,'J-7261169558',25,4,454,4007,0.00,'waiting_work','high',NULL,NULL,NULL,'2025-12-02 22:14:20','2025-12-02 22:14:32'),(12130,'J-4137806502',25,4,456,4009,0.00,'waiting_work','high',NULL,NULL,NULL,'2025-12-02 22:21:56','2025-12-02 22:21:59'),(12132,'J-6852097234',25,3,457,NULL,4650.00,'delivered','medium',NULL,NULL,NULL,'2025-12-02 22:34:15','2025-12-22 20:01:45'),(12136,'J-2000432809',25,3,459,NULL,5650.00,'delivered','medium',NULL,NULL,NULL,'2025-12-02 22:35:59','2025-12-02 22:36:07'),(12139,'J-4275982157',25,3,460,NULL,3959.00,'delivered','medium',NULL,NULL,NULL,'2025-12-02 22:37:51','2026-01-11 20:13:37'),(12143,'J-8559779424',25,3,462,NULL,2850.00,'delivered','medium',NULL,NULL,NULL,'2025-12-02 22:39:14','2025-12-02 22:39:24'),(12146,'J-4468535316',25,3,465,NULL,4650.00,'delivered','medium',NULL,NULL,NULL,'2025-12-02 22:40:24','2025-12-02 22:40:48'),(12150,'J-0439608840',25,3,468,436,5650.00,'delivered','medium',NULL,NULL,NULL,'2025-12-02 22:42:23','2025-12-02 22:42:39'),(12154,'J-1697647729',25,3,473,4033,4650.00,'waiting_work','medium',NULL,NULL,'fix and sell to Dan Brake','2025-12-02 22:46:35','2026-01-11 05:44:07'),(12185,'J-4401470710',136,NULL,476,NULL,5.00,'waiting_work','medium',NULL,NULL,'12345','2025-12-03 05:57:42','2025-12-03 05:58:02');
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leads`
--

DROP TABLE IF EXISTS `leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leads` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `lead_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `customer_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `lead_type` enum('product','service') COLLATE utf8mb4_general_ci NOT NULL,
  `product_id` varchar(35) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `job_definition_id` varchar(35) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` enum('new','followup_suggested','waiting_response','converted','on_hold','lost') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'new',
  `notes` text COLLATE utf8mb4_general_ci,
  `source` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lead_id` (`lead_id`),
  KEY `customer_id` (`customer_id`),
  KEY `product_id` (`product_id`),
  KEY `job_definition_id` (`job_definition_id`),
  CONSTRAINT `leads_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE CASCADE,
  CONSTRAINT `leads_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE SET NULL,
  CONSTRAINT `leads_ibfk_3` FOREIGN KEY (`job_definition_id`) REFERENCES `job_definitions` (`job_definition_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leads`
--

LOCK TABLES `leads` WRITE;
/*!40000 ALTER TABLE `leads` DISABLE KEYS */;
INSERT INTO `leads` VALUES (1,'LEAD-01KEJJGDGXHJXZ1D7V8P49C3V8',25,'C-1934322243','product','P-7910743349',NULL,'followup_suggested','',NULL,'2026-01-09 23:47:14','2026-01-11 09:06:32'),(74,'LEAD-01KEP49CH6QM7XQVV40GMJ0YMT',25,'C-4781403725','service',NULL,'JOBDEF-01KEJM1CJP8AK3KKAJX32F0VVT','converted','Notes\n',NULL,'2026-01-11 08:55:41','2026-01-11 09:07:15');
/*!40000 ALTER TABLE `leads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `media_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `folder_id` bigint DEFAULT NULL,
  `public_id` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `type` enum('image','video','file') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'image',
  `url` text COLLATE utf8mb4_general_ci NOT NULL,
  `alt_text` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `width` int DEFAULT NULL,
  `height` int DEFAULT NULL,
  `size` bigint DEFAULT NULL,
  `tags` json DEFAULT (json_array()),
  `ordinal` int NOT NULL DEFAULT '0',
  `originalName` text COLLATE utf8mb4_general_ci,
  `s3Key` text COLLATE utf8mb4_general_ci,
  `bucket` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `extension` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mimeType` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `transformed` tinyint(1) DEFAULT '0',
  `version` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_id` (`media_id`),
  KEY `project_idx` (`project_idx`),
  KEY `folder_id` (`folder_id`),
  CONSTRAINT `media_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `media_ibfk_2` FOREIGN KEY (`folder_id`) REFERENCES `media_folders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (948,'MEDIA-1921580804',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/3120df1c-2bef-4083-86df-64e9ac2df8a7.webp','',NULL,540,540,40376,NULL,1,'2025-11-27-14-08-15-834--a0pntij35ukgbfvkst3q_webp.webp','prod/PROJ-90959de1e1d/media/3120df1c-2bef-4083-86df-64e9ac2df8a7.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:08:19','2025-12-02 20:05:22'),(949,'MEDIA-5371641553',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/8a18620d-3015-4f38-b52b-7a9c7a35ac76.webp','',NULL,540,540,45600,NULL,0,'2025-11-27-14-08-15-834--eyptkkmjjffo8vnun8wl_webp.webp','prod/PROJ-90959de1e1d/media/8a18620d-3015-4f38-b52b-7a9c7a35ac76.webp','tsa-cms-data','webp','image/webp',1,4,'2025-11-27 19:08:19','2025-12-02 20:05:22'),(950,'MEDIA-0949720411',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/9b0bca71-7e5e-4392-a2b5-b4eb6d06913d.webp','',NULL,526,526,45282,NULL,2,'2025-11-27-14-08-15-834--fmn2qnyf81dx3okbtq4d_webp.webp','prod/PROJ-90959de1e1d/media/9b0bca71-7e5e-4392-a2b5-b4eb6d06913d.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:08:19','2025-11-27 19:08:19'),(951,'MEDIA-0107514054',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/a34edcf2-b0ba-498b-8f9b-769ae2450727.webp','',NULL,526,526,63842,NULL,3,'2025-11-27-14-08-15-834--ilxxzfqmho23qrff0obc_webp.webp','prod/PROJ-90959de1e1d/media/a34edcf2-b0ba-498b-8f9b-769ae2450727.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:08:19','2025-11-27 19:08:19'),(952,'MEDIA-9887179503',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/9edfd02c-a919-4d74-ae7b-8881b50f470a.webp','',NULL,526,526,40304,NULL,4,'2025-11-27-14-08-15-834--wpmqoxrowqxyfphyefh0_webp.webp','prod/PROJ-90959de1e1d/media/9edfd02c-a919-4d74-ae7b-8881b50f470a.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:08:19','2025-11-27 19:08:19'),(953,'MEDIA-3965596829',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/4a564d03-099b-491c-bbed-5d3705694c82.webp','',NULL,526,526,47844,NULL,5,'2025-11-27-14-08-15-834--zjq2u1trrrnkit2hai3w_webp.webp','prod/PROJ-90959de1e1d/media/4a564d03-099b-491c-bbed-5d3705694c82.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:08:19','2025-11-27 19:08:19'),(954,'MEDIA-4991984915',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/839ec938-d519-49b7-8b10-3550f5fbff79.webp','',NULL,526,526,35610,NULL,6,'2025-11-27-14-08-55-881--ggoxmytol1y0urv8yz65_webp.webp','prod/PROJ-90959de1e1d/media/839ec938-d519-49b7-8b10-3550f5fbff79.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:08:59','2025-11-27 19:08:59'),(955,'MEDIA-0347790526',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/2026f6bb-a2e3-40fd-b576-3f0166722265.webp','',NULL,526,526,21348,NULL,7,'2025-11-27-14-08-55-882--gsloejvdzovkwrdvogf1_webp.webp','prod/PROJ-90959de1e1d/media/2026f6bb-a2e3-40fd-b576-3f0166722265.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:08:59','2025-12-02 20:30:41'),(956,'MEDIA-5361474362',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/126a9fad-e68a-4005-a8f7-c6ebb6d365ab.webp','',NULL,526,526,35522,NULL,8,'2025-11-27-14-08-55-882--i11b6e5qjvv2asvlcvwn_webp.webp','prod/PROJ-90959de1e1d/media/126a9fad-e68a-4005-a8f7-c6ebb6d365ab.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:08:59','2025-12-02 20:30:41'),(957,'MEDIA-2165240034',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/7195f719-380a-49d8-9391-37e4c4424225.webp','',NULL,526,526,46320,NULL,9,'2025-11-27-14-08-55-882--kuf94iwi76c7ewpkirjl_webp.webp','prod/PROJ-90959de1e1d/media/7195f719-380a-49d8-9391-37e4c4424225.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:08:59','2025-11-27 19:08:59'),(958,'MEDIA-5316252747',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/c1f0d39e-5695-4c26-b3d3-252c1c4f201b.webp','',NULL,526,526,38572,NULL,10,'2025-11-27-14-08-55-882--nmn3e8c8wmw33rwsbm2h_webp.webp','prod/PROJ-90959de1e1d/media/c1f0d39e-5695-4c26-b3d3-252c1c4f201b.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:08:59','2025-11-27 19:08:59'),(959,'MEDIA-2742255743',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/0495113c-fc34-4ebf-9879-e45e00cce049.webp','',NULL,526,526,42462,NULL,11,'2025-11-27-14-08-55-882--pm1shjbupny49fqjpaxo_webp.webp','prod/PROJ-90959de1e1d/media/0495113c-fc34-4ebf-9879-e45e00cce049.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:08:59','2025-11-27 19:08:59'),(960,'MEDIA-1917556251',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/859bf744-1ec6-4fed-b662-748d2fad6673.webp','',NULL,526,526,59882,NULL,12,'2025-11-27-14-08-55-882--whz5kgleueldtoulhvut_webp.webp','prod/PROJ-90959de1e1d/media/859bf744-1ec6-4fed-b662-748d2fad6673.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:08:59','2025-11-27 19:08:59'),(961,'MEDIA-0663915689',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/96c3b5d4-7239-4df4-9772-4928e61835f5.webp','',NULL,526,526,35588,NULL,13,'2025-11-27-14-08-55-882--yscmeamwdqnh3cpjrbhh_webp.webp','prod/PROJ-90959de1e1d/media/96c3b5d4-7239-4df4-9772-4928e61835f5.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:08:59','2025-11-27 19:08:59'),(962,'MEDIA-1722075683',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/b69f9062-1b89-4aa6-95b0-2bfbb0a4f30e.webp','',NULL,1200,900,175518,NULL,14,'2025-11-27-14-09-32-309--ao9s5f10cuk2rbpnerua_webp.webp','prod/PROJ-90959de1e1d/media/b69f9062-1b89-4aa6-95b0-2bfbb0a4f30e.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:09:39','2025-11-27 19:09:39'),(963,'MEDIA-4221053380',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/9a2cbf8c-0efd-4edd-8bc4-679407219267.webp','',NULL,900,1200,275318,NULL,15,'2025-11-27-14-09-32-309--ftcl0iomsmvveo7el42o_webp.webp','prod/PROJ-90959de1e1d/media/9a2cbf8c-0efd-4edd-8bc4-679407219267.webp','tsa-cms-data','webp','image/webp',1,1,'2025-11-27 19:09:39','2025-11-27 19:10:05'),(964,'MEDIA-2457022216',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/e8549e70-2bf5-4135-9490-ae7561f28186.webp','',NULL,900,1200,297090,NULL,16,'2025-11-27-14-09-32-309--hnjyjxxkjvhncbefx8gv_webp.webp','prod/PROJ-90959de1e1d/media/e8549e70-2bf5-4135-9490-ae7561f28186.webp','tsa-cms-data','webp','image/webp',1,1,'2025-11-27 19:09:39','2025-11-27 19:09:59'),(965,'MEDIA-9078905044',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/932ccb9a-56a4-49c9-8701-3832402d3c67.webp','',NULL,900,1200,239562,NULL,17,'2025-11-27-14-09-32-309--pl9ksg3claaugiyyqsn0_webp.webp','prod/PROJ-90959de1e1d/media/932ccb9a-56a4-49c9-8701-3832402d3c67.webp','tsa-cms-data','webp','image/webp',1,1,'2025-11-27 19:09:39','2025-11-27 19:09:56'),(966,'MEDIA-7788680867',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/5076d8be-2be1-4dac-b6dd-037e29ffadc1.webp','',NULL,900,1200,319694,NULL,18,'2025-11-27-14-09-32-309--s5mxdu4xwx3r7egeaagh_webp.webp','prod/PROJ-90959de1e1d/media/5076d8be-2be1-4dac-b6dd-037e29ffadc1.webp','tsa-cms-data','webp','image/webp',1,1,'2025-11-27 19:09:39','2025-11-27 19:10:11'),(967,'MEDIA-2408164224',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/d49c9aee-f1c8-4a4a-af4c-4bcf1fd6428b.webp','',NULL,900,1200,305694,NULL,19,'2025-11-27-14-09-32-309--t3ruymdm3hq5iwniwpas_webp.webp','prod/PROJ-90959de1e1d/media/d49c9aee-f1c8-4a4a-af4c-4bcf1fd6428b.webp','tsa-cms-data','webp','image/webp',1,1,'2025-11-27 19:09:39','2025-11-27 19:10:03'),(968,'MEDIA-8302615584',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/ddb7eae4-f280-47a6-b51a-f7457246deed.webp','',NULL,1200,900,158542,NULL,20,'2025-11-27-14-09-32-309--tkhjlryc2klruypjsyat_webp.webp','prod/PROJ-90959de1e1d/media/ddb7eae4-f280-47a6-b51a-f7457246deed.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:09:39','2025-11-27 19:09:39'),(969,'MEDIA-0758432499',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/d223e69f-0304-4ac3-a29b-8f113d7da4b6.webp','',NULL,900,1200,185168,NULL,21,'2025-11-27-14-09-32-309--tl4pbzmxwjbhzzg5xy0n_webp.webp','prod/PROJ-90959de1e1d/media/d223e69f-0304-4ac3-a29b-8f113d7da4b6.webp','tsa-cms-data','webp','image/webp',1,1,'2025-11-27 19:09:39','2025-11-27 19:10:07'),(970,'MEDIA-7554430815',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/2ad3469d-2be5-4675-b418-fce5d73d8f33.webp','',NULL,1200,900,157990,NULL,22,'2025-11-27-14-09-32-309--z1wpzuuhuvej7l9yvivh_webp.webp','prod/PROJ-90959de1e1d/media/2ad3469d-2be5-4675-b418-fce5d73d8f33.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:09:39','2025-11-27 19:09:39'),(971,'MEDIA-0952706415',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/93665a24-88d8-45ea-a873-b1d01ff2a940.webp','',NULL,526,526,81028,NULL,23,'2025-11-27-14-10-33-000--bjtloupjplmh9zxp1hqp_webp.webp','prod/PROJ-90959de1e1d/media/93665a24-88d8-45ea-a873-b1d01ff2a940.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:10:38','2025-11-27 19:10:38'),(972,'MEDIA-5811388186',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/795f4848-0857-435f-afac-46918bf1beb8.webp','',NULL,540,540,55914,NULL,24,'2025-11-27-14-10-33-000--jrzdlc5izcl9tf1ogmax_webp.webp','prod/PROJ-90959de1e1d/media/795f4848-0857-435f-afac-46918bf1beb8.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:10:38','2025-11-27 19:10:38'),(973,'MEDIA-2303400962',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/6c4d5853-a7c1-426f-91cd-91b57ff8f25d.webp','',NULL,526,526,58532,NULL,25,'2025-11-27-14-10-33-000--ldloubbiltkfs4iw4y5s_webp.webp','prod/PROJ-90959de1e1d/media/6c4d5853-a7c1-426f-91cd-91b57ff8f25d.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:10:38','2025-11-27 19:10:38'),(974,'MEDIA-3229006290',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/173289fd-12a5-4369-9594-525a152d8742.webp','',NULL,526,526,40568,NULL,26,'2025-11-27-14-10-33-000--mlf3xq1q2bvbyecxtfza_webp.webp','prod/PROJ-90959de1e1d/media/173289fd-12a5-4369-9594-525a152d8742.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:10:38','2025-11-27 19:10:38'),(975,'MEDIA-3231790297',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/5e8f2285-5471-4e66-a6af-2ce5eef85189.webp','',NULL,540,540,48214,NULL,27,'2025-11-27-14-10-33-000--otaqvfpkjl7pygw4pfsr_webp.webp','prod/PROJ-90959de1e1d/media/5e8f2285-5471-4e66-a6af-2ce5eef85189.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:10:38','2025-11-27 19:10:38'),(976,'MEDIA-8477563938',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/79c09fa0-b77b-4507-85d6-14b2652dfbf6.webp','',NULL,526,526,61920,NULL,28,'2025-11-27-14-10-33-000--ruv7tbt3hskjdrjndxmb_webp.webp','prod/PROJ-90959de1e1d/media/79c09fa0-b77b-4507-85d6-14b2652dfbf6.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:10:38','2025-11-27 19:10:38'),(977,'MEDIA-3051560727',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/1ded7db9-9fc9-4cc2-8a89-ab103545c724.webp','',NULL,526,526,64836,NULL,29,'2025-11-27-14-10-33-000--tcrmnu9ii9uivrpu2c7z_webp.webp','prod/PROJ-90959de1e1d/media/1ded7db9-9fc9-4cc2-8a89-ab103545c724.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:10:38','2025-11-27 19:10:38'),(978,'MEDIA-1906306480',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/966e8e3b-77aa-4226-8e95-988b7c95da7f.webp','',NULL,526,526,52142,NULL,30,'2025-11-27-14-10-33-000--umaqojubqbflujijvioa_webp.webp','prod/PROJ-90959de1e1d/media/966e8e3b-77aa-4226-8e95-988b7c95da7f.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:10:38','2025-11-27 19:10:38'),(979,'MEDIA-8111321587',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/c291b9c2-ff1b-4ce1-bf82-fe24ed2ca2f3.webp','',NULL,540,540,55528,NULL,31,'2025-11-27-14-10-33-000--wq9pivaaynb58jk7iupa_webp.webp','prod/PROJ-90959de1e1d/media/c291b9c2-ff1b-4ce1-bf82-fe24ed2ca2f3.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:10:38','2025-11-27 19:10:38'),(980,'MEDIA-4959742096',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/617fa6c5-12eb-4f05-b6b8-fa52ee1fb442.webp','',NULL,526,526,59708,NULL,32,'2025-11-27-14-10-33-000--ylwqmai04bojyjkhqakf_webp.webp','prod/PROJ-90959de1e1d/media/617fa6c5-12eb-4f05-b6b8-fa52ee1fb442.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:10:38','2025-11-27 19:10:38'),(983,'MEDIA-0048045745',25,438,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/02ddfaca-accf-4e26-8340-d3cf20b82993.webp?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA4YT55LARAP7DXTFI%2F20251216%2Fus-east-2%2Fs3%2Faws4_request&X-Amz-Date=20251216T225941Z&X-Amz-Expires=3600&X-Amz-Signature=5fc8d75e06c55674ab659abc1949b4c19197cfb50b368cdfb36b0432136e9e83&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject','',NULL,213,203,2930,NULL,2,'2025-11-27-14-11-30-207--logo_dark1_png.png','prod/PROJ-90959de1e1d/media/02ddfaca-accf-4e26-8340-d3cf20b82993.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:11:31','2025-12-16 23:05:34'),(984,'MEDIA-8270842633',25,438,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/f8585e2b-8ecf-43e4-8894-87b972d4e841.webp?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA4YT55LARAP7DXTFI%2F20251216%2Fus-east-2%2Fs3%2Faws4_request&X-Amz-Date=20251216T225941Z&X-Amz-Expires=3600&X-Amz-Signature=04a856e1f2800c490a10432eacf54b2f7f970179a7a13d50e4ea31868325d128&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject','',NULL,213,203,2920,NULL,1,'2025-11-27-14-11-30-207--logo_light2_png.png','prod/PROJ-90959de1e1d/media/f8585e2b-8ecf-43e4-8894-87b972d4e841.webp','tsa-cms-data','webp','image/webp',1,0,'2025-11-27 19:11:31','2025-12-16 23:05:34'),(988,'MEDIA-1409494327',25,NULL,'','video','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/53416dc4-50ae-48be-ac99-e8e26177753b.quicktime','',NULL,NULL,NULL,16098377,NULL,33,'2025-12-02-12-36-56-701--Video_MOV.quicktime','prod/PROJ-90959de1e1d/media/53416dc4-50ae-48be-ac99-e8e26177753b.quicktime','tsa-cms-data','quicktime','video/mp4',0,0,'2025-12-02 17:37:07','2025-12-02 17:37:07'),(989,'MEDIA-8456631417',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/205b3f00-08be-4355-998e-9fa406b4c93b.webp','',NULL,1200,1600,405758,NULL,34,'2025-12-02-12-37-53-803--Corner_Closed_HEIC.heic','prod/PROJ-90959de1e1d/media/205b3f00-08be-4355-998e-9fa406b4c93b.webp','tsa-cms-data','webp','image/webp',1,0,'2025-12-02 17:37:59','2025-12-02 17:37:59'),(990,'MEDIA-9363824467',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/2855b370-038d-4635-88cf-264c12f85897.webp','',NULL,1200,1600,493564,NULL,35,'2025-12-02-12-38-17-763--Corner_HEIC.heic','prod/PROJ-90959de1e1d/media/2855b370-038d-4635-88cf-264c12f85897.webp','tsa-cms-data','webp','image/webp',1,0,'2025-12-02 17:38:39','2025-12-02 17:38:39'),(991,'MEDIA-4592283142',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/f9fc82e6-3471-4e5d-9728-80b462c453a6.webp','',NULL,1200,1600,380196,NULL,36,'2025-12-02-12-38-17-763--Front_Closed_HEIC.heic','prod/PROJ-90959de1e1d/media/f9fc82e6-3471-4e5d-9728-80b462c453a6.webp','tsa-cms-data','webp','image/webp',1,0,'2025-12-02 17:38:39','2025-12-02 17:38:39'),(992,'MEDIA-9995952091',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/a2a4cbb9-7753-4afa-88c1-69504f1984c0.webp','',NULL,1200,1600,471098,NULL,37,'2025-12-02-12-38-17-763--Front_HEIC.heic','prod/PROJ-90959de1e1d/media/a2a4cbb9-7753-4afa-88c1-69504f1984c0.webp','tsa-cms-data','webp','image/webp',1,0,'2025-12-02 17:38:39','2025-12-02 17:38:39'),(993,'MEDIA-6002255833',25,NULL,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/21f72dff-447a-40e5-b608-1473ae1aaa9f.webp','',NULL,1200,1600,339758,NULL,38,'2025-12-02-12-38-17-763--IMG_3367_HEIC.heic','prod/PROJ-90959de1e1d/media/21f72dff-447a-40e5-b608-1473ae1aaa9f.webp','tsa-cms-data','webp','image/webp',1,0,'2025-12-02 17:38:39','2025-12-02 17:38:39'),(1004,'MEDIA-1255770109',136,NULL,'','image','https://infinity-slide-03-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-3070432425/media/73e3ce87-7c97-4dcb-835b-3a82a6ea8c7c.webp?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIAYD5QVPXNPFCKWPW6%2F20251203%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20251203T041828Z&X-Amz-Expires=3600&X-Amz-Signature=4934e8ddd9695c552456c1225cf49fc4dcee7e10aaec95095d17a56c821e5957&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject','',NULL,1128,674,640716,NULL,1,'2025-12-02-17-20-00-457--Screenshot_2025_11_13_at_12_54_10_PM_png.png','prod/PROJ-3070432425/media/73e3ce87-7c97-4dcb-835b-3a82a6ea8c7c.webp','infinity-slide-03-cms-data','webp','image/webp',1,4,'2025-12-02 22:20:01','2025-12-04 17:43:52'),(1005,'MEDIA-0647242094',136,444,'','image','https://infinity-slide-03-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-3070432425/media/66862d54-8298-405d-9844-0fdf22025554.webp?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIAYD5QVPXNPFCKWPW6%2F20251202%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20251202T234822Z&X-Amz-Expires=3600&X-Amz-Signature=79d78db6f92c8e630cf6d6aa59fde76c40f6ef47f6a9a979e557f7a34363b411&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject','',NULL,1200,1552,273822,NULL,2,'2025-12-02-18-22-42-979--Screenshot_2025_10_21_at_3_58_27_PM_png.png','prod/PROJ-3070432425/media/66862d54-8298-405d-9844-0fdf22025554.webp','infinity-slide-03-cms-data','webp','image/webp',1,0,'2025-12-02 23:22:46','2025-12-02 23:48:26'),(1006,'MEDIA-7968010544',136,NULL,'','image','https://infinity-slide-03-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-3070432425/media/a64a8d7d-968f-4d26-bd18-afbcdd875654.webp?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIAYD5QVPXNPFCKWPW6%2F20251203%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20251203T041916Z&X-Amz-Expires=3600&X-Amz-Signature=0c8e8a449287b27d5b05dc0659c701efc4055afbdf7ebb12ebd5265de02686ad&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject','',NULL,1128,674,640566,NULL,0,'2025-12-02-18-22-42-979--Screenshot_2025_11_13_at_12_54_10_PM_png.png','prod/PROJ-3070432425/media/a64a8d7d-968f-4d26-bd18-afbcdd875654.webp','infinity-slide-03-cms-data','webp','image/webp',1,12,'2025-12-02 23:22:46','2025-12-04 17:43:44'),(1007,'MEDIA-0641437211',136,444,'','image','https://infinity-slide-03-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-3070432425/media/eb6c4a7d-2bd5-46c2-8b58-f55cd69e5d48.webp?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIAYD5QVPXNPFCKWPW6%2F20251202%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20251202T234822Z&X-Amz-Expires=3600&X-Amz-Signature=2b993e7a8ff1b9f1e5c39950b7f75c9bd38dd5750d387f35c41d9e7156b354d7&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject','',NULL,1200,899,102248,NULL,1,'2025-12-02-18-22-42-979--Screenshot_2025_11_18_at_6_37_10_AM_png.png','prod/PROJ-3070432425/media/eb6c4a7d-2bd5-46c2-8b58-f55cd69e5d48.webp','infinity-slide-03-cms-data','webp','image/webp',1,2,'2025-12-02 23:22:46','2025-12-02 23:48:26'),(1008,'MEDIA-2604563928',136,444,'','image','https://infinity-slide-03-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-3070432425/media/bed574a3-e5e6-4659-8e4b-e670ed334413.webp?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIAYD5QVPXNPFCKWPW6%2F20251202%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20251202T234822Z&X-Amz-Expires=3600&X-Amz-Signature=6d8be70a7cc111ad470b905d66aac2f931c409649782f9f515131da665facbf7&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject','',NULL,280,326,2532,NULL,0,'2025-12-02-18-22-42-979--Screenshot_2025_11_20_at_3_02_16_AM_png.png','prod/PROJ-3070432425/media/bed574a3-e5e6-4659-8e4b-e670ed334413.webp','infinity-slide-03-cms-data','webp','image/webp',1,0,'2025-12-02 23:22:46','2025-12-02 23:48:26'),(1023,'MEDIA-4251442848',25,438,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/4afc238c-254f-41b1-879e-fb9aa756599f.webp?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA4YT55LARAP7DXTFI%2F20251204%2Fus-east-2%2Fs3%2Faws4_request&X-Amz-Date=20251204T075147Z&X-Amz-Expires=3600&X-Amz-Signature=79f4a2e2aa692537bf57d687f923825436d6a18ebddea34689d473ebf81d15ef&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject','',NULL,213,203,13492,NULL,0,'2025-12-04-02-51-26-564--logo_png.png','prod/PROJ-90959de1e1d/media/4afc238c-254f-41b1-879e-fb9aa756599f.webp','tsa-cms-data','webp','image/webp',1,0,'2025-12-04 07:51:27','2025-12-04 07:51:52'),(1029,'MEDIA-6434543469',25,438,'','image','https://tsa-cms-data.s3.us-east-2.amazonaws.com/prod/PROJ-90959de1e1d/media/2d19bf30-8a78-4867-a54e-7d5ac03bbb09.webp','',NULL,132,132,726,NULL,3,'2025-12-11-19-31-52-188--qr_code_png.png','prod/PROJ-90959de1e1d/media/2d19bf30-8a78-4867-a54e-7d5ac03bbb09.webp','tsa-cms-data','webp','image/webp',1,0,'2025-12-12 00:31:52','2025-12-12 00:31:52'),(1092,'MEDIA-01KF02NG3DR9FC6TZSNFG2TXWY',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/90cdd2ab-4733-4e64-b569-aafbe9b1bcde.webp','',NULL,3132,2087,494014,NULL,0,'2026-01-15-00-34-58-689--_DSC9170_jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/90cdd2ab-4733-4e64-b569-aafbe9b1bcde.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1093,'MEDIA-01KF02NG3DJYHDMV04E5A9S2VZ',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/b2123098-5b63-4d9c-a1a3-b8090c4acb0d.webp','',NULL,6062,4036,596068,NULL,1,'2026-01-15-00-34-58-689--_DSC9176_jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/b2123098-5b63-4d9c-a1a3-b8090c4acb0d.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1094,'MEDIA-01KF02NG3EVV70K897TXZM26TB',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/f546c8a8-294b-4025-9c69-ffd0b3046aa6.webp','',NULL,3131,2087,585492,NULL,2,'2026-01-15-00-34-58-689--_DSC9191_jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/f546c8a8-294b-4025-9c69-ffd0b3046aa6.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1095,'MEDIA-01KF02NG3FSW86QAXT3ES2ZSH4',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/147051f2-93db-408a-a9de-4f31f1b9c07b.webp','',NULL,2663,1775,597220,NULL,3,'2026-01-15-00-34-58-689--_DSC9225_jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/147051f2-93db-408a-a9de-4f31f1b9c07b.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1096,'MEDIA-01KF02NG3F0ERX14ZGQKFDSZET',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/e7015baf-b6c6-47a4-bfba-42e52caae490.webp','',NULL,6008,4005,639582,NULL,4,'2026-01-15-00-34-58-689--_DSC9236_jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/e7015baf-b6c6-47a4-bfba-42e52caae490.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1097,'MEDIA-01KF02NG3FWE3TF6T0VGGAZP8Z',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/224a11ed-2672-4bf9-a51c-db386462258f.webp','',NULL,2048,1365,699412,NULL,5,'2026-01-15-00-34-58-689--_DSC9526_2_jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/224a11ed-2672-4bf9-a51c-db386462258f.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1098,'MEDIA-01KF02NG3F3Q08ZFNVAQ8B7RT7',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/402fb2e6-f65b-4ff8-96f1-269d410532ef.webp','',NULL,3131,2087,507488,NULL,6,'2026-01-15-00-34-58-689--_DSC9564_jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/402fb2e6-f65b-4ff8-96f1-269d410532ef.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1099,'MEDIA-01KF02NG3F77P1KZG2X64YGTGS',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/fd2d4be3-4f6c-4427-ae9a-676a903855ac.webp','',NULL,3131,2087,562830,NULL,7,'2026-01-15-00-34-58-689--_DSC9618_jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/fd2d4be3-4f6c-4427-ae9a-676a903855ac.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1100,'MEDIA-01KF02NG3FNM3BM8E62YD0T9PC',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/5f391bf2-4c02-4159-9b0a-56dafb4b380c.webp','',NULL,2261,1507,639258,NULL,8,'2026-01-15-00-34-58-689--_DSC9653_jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/5f391bf2-4c02-4159-9b0a-56dafb4b380c.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1101,'MEDIA-01KF02NG3GAPXGB7Q9KQB89YWK',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/10b06721-970d-4d7b-9dce-014f85ba528b.webp','',NULL,6000,4000,631896,NULL,9,'2026-01-15-00-34-58-689--_DSC9791_JPG.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/10b06721-970d-4d7b-9dce-014f85ba528b.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1102,'MEDIA-01KF02NG3GEVJFNZRP2XEKPGBA',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/6197e04b-1e68-4edf-8f0c-356e27db6e20.webp','',NULL,2261,1507,545868,NULL,10,'2026-01-15-00-34-58-689--_DSC9808_JPG.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/6197e04b-1e68-4edf-8f0c-356e27db6e20.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1103,'MEDIA-01KF02NG3GV1720AF6MA7Z89FA',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/a6c9e34b-86b1-4cce-bebd-4b0ae77cca62.webp','',NULL,1632,1088,516800,NULL,11,'2026-01-15-00-34-58-689--_DSC9892_JPG.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/a6c9e34b-86b1-4cce-bebd-4b0ae77cca62.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1104,'MEDIA-01KF02NG3GCV8BCRG6W3JXVAF0',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/0182ad45-ddc7-4cc7-bc06-12c304a3fd14.webp','',NULL,1920,1280,544428,NULL,12,'2026-01-15-00-34-58-689--2__jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/0182ad45-ddc7-4cc7-bc06-12c304a3fd14.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1105,'MEDIA-01KF02NG3G7EBW42EK05VGJYKD',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/aa923b33-2e11-457f-859f-9025275a1d66.webp','',NULL,3832,2150,658214,NULL,13,'2026-01-15-00-34-58-689--4__Front_Left_Zoomed_Out_jpeg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/aa923b33-2e11-457f-859f-9025275a1d66.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1106,'MEDIA-01KF02NG3G71N6HT719B3Y0WTN',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/80608eaa-f45f-4e5c-aff5-6e0c958d3b2b.webp','',NULL,1632,1088,561982,NULL,14,'2026-01-15-00-34-58-689--4_jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/80608eaa-f45f-4e5c-aff5-6e0c958d3b2b.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1107,'MEDIA-01KF02NG3H346XWAGS82F86J55',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/39744b2d-babb-45a0-8ea9-0b859cef051c.webp','',NULL,2268,1511,517414,NULL,15,'2026-01-15-00-34-58-689--6__Living_Room_1_jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/39744b2d-babb-45a0-8ea9-0b859cef051c.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1108,'MEDIA-01KF02NG3HGQW2N61ESP5Q5RA0',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/33bb238f-f6db-4f43-8b33-81ba602e0a25.webp','',NULL,1986,1116,586880,NULL,16,'2026-01-15-00-34-58-689--9__jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/33bb238f-f6db-4f43-8b33-81ba602e0a25.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1109,'MEDIA-01KF02NG3H5YWD68G3B8JYY25J',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/a635ad97-308c-4e23-aeae-e51997c3413d.webp','',NULL,6000,4000,626142,NULL,17,'2026-01-15-00-34-58-689--21__Kitchen__8__jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/a635ad97-308c-4e23-aeae-e51997c3413d.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1110,'MEDIA-01KF02NG3HKHYTSP9M8CYF0A7B',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/f7a77eba-c5d6-4a4c-8638-4d9c7b0bf491.webp','',NULL,2337,1313,620734,NULL,18,'2026-01-15-00-34-58-689--DJI_20240910184705_0090_D_jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/f7a77eba-c5d6-4a4c-8638-4d9c7b0bf491.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1111,'MEDIA-01KF02NG3HZHVQCWMBS5ZZ5VRV',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/4b8f4ae0-7251-4261-b3d5-207faac16561.webp','',NULL,1687,948,581300,NULL,19,'2026-01-15-00-34-58-689--DJI_20241005111701_0414_D_JPG.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/4b8f4ae0-7251-4261-b3d5-207faac16561.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1112,'MEDIA-01KF02NG3HPFWWET4QWEDJB4FW',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/c7ac6acc-5aa0-48e8-b198-508860bfdb7d.webp','',NULL,2660,1773,499970,NULL,20,'2026-01-15-00-34-58-689--DSC9155_jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/c7ac6acc-5aa0-48e8-b198-508860bfdb7d.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1113,'MEDIA-01KF02NG3HV0P3FED65A232X37',139,NULL,'','image','https://open-dream-design-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/f2979045-0a85-4a1f-b3b6-3feab750ae85.webp','',NULL,896,676,162368,NULL,21,'2026-01-15-00-34-58-689--Savoie_media_photo_jpg.jpeg','prod/PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7/media/f2979045-0a85-4a1f-b3b6-3feab750ae85.webp','open-dream-design-cms-data','webp','image/webp',1,0,'2026-01-15 05:39:46','2026-01-15 05:39:46'),(1121,'MEDIA-01KF54FFSZWP4CZ52VFQNZRRYY',132,457,'','image','https://infinity-slide-03-cms-data.s3.us-east-1.amazonaws.com/prod/PROJ-3133159650/media/0b4385cf-ae60-4d1c-a76c-4aac06fe92aa.webp?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIAYD5QVPXNPFCKWPW6%2F20260117%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20260117T044738Z&X-Amz-Expires=3600&X-Amz-Signature=aa09eb83c408efc9672c7a6757126d09f2286075b5d2c2cad9a318fa2f4ccd10&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject','',NULL,2000,2000,240230,NULL,0,'2026-01-16-23-47-31-663--logo_png.png','prod/PROJ-3133159650/media/0b4385cf-ae60-4d1c-a76c-4aac06fe92aa.webp','infinity-slide-03-cms-data','webp','image/webp',1,0,'2026-01-17 04:47:38','2026-01-17 04:47:48');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_folders`
--

DROP TABLE IF EXISTS `media_folders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_folders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `folder_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `parent_folder_id` bigint DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `ordinal` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `folder_id` (`folder_id`),
  KEY `project_idx` (`project_idx`),
  KEY `parent_folder_id` (`parent_folder_id`),
  CONSTRAINT `media_folders_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `media_folders_ibfk_2` FOREIGN KEY (`parent_folder_id`) REFERENCES `media_folders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=460 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_folders`
--

LOCK TABLES `media_folders` WRITE;
/*!40000 ALTER TABLE `media_folders` DISABLE KEYS */;
INSERT INTO `media_folders` VALUES (438,'F-1898140772',25,NULL,'Brand',0,'2025-11-12 03:34:15','2025-12-17 19:31:31'),(444,'F-3194578156',136,NULL,'folder_1',0,'2025-12-02 23:22:53','2025-12-02 23:22:57'),(457,'FOLDER-01KF4ATR1NV0T5N45MEJFTPZEQ',132,NULL,'Brand',0,'2026-01-16 21:19:24','2026-01-16 21:19:24'),(459,'FOLDER-01KF4AVM8NKN5299HC3W3KV469',132,NULL,'Jobs',1,'2026-01-16 21:19:53','2026-01-16 21:19:53');
/*!40000 ALTER TABLE `media_folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_link`
--

DROP TABLE IF EXISTS `media_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_link` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `entity_type` enum('product','page','module','job') COLLATE utf8mb4_general_ci NOT NULL,
  `entity_id` bigint NOT NULL,
  `media_id` bigint NOT NULL,
  `ordinal` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `entity_type` (`entity_type`,`entity_id`,`media_id`),
  KEY `media_id` (`media_id`),
  CONSTRAINT `media_link_ibfk_1` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=467 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_link`
--

LOCK TABLES `media_link` WRITE;
/*!40000 ALTER TABLE `media_link` DISABLE KEYS */;
INSERT INTO `media_link` VALUES (423,'product',390,949,0),(424,'product',390,951,1),(425,'product',390,952,2),(426,'product',390,948,3),(427,'product',390,950,4),(428,'product',390,953,5),(429,'product',373,958,1),(430,'product',373,959,2),(431,'product',373,957,0),(432,'product',373,960,3),(433,'product',373,954,4),(434,'product',373,956,5),(435,'product',373,961,6),(436,'product',373,955,7),(440,'product',368,970,1),(441,'product',368,965,0),(442,'product',368,964,2),(443,'product',368,967,3),(444,'product',368,962,4),(445,'product',368,963,5),(446,'product',368,966,6),(447,'product',368,968,7),(448,'product',368,969,8),(449,'product',372,975,0),(450,'product',372,977,1),(451,'product',372,974,2),(452,'product',372,971,3),(453,'product',372,972,4),(454,'product',372,973,5),(455,'product',372,976,6),(456,'product',372,979,7),(457,'product',372,980,8),(458,'product',372,978,9),(461,'product',363,992,0),(462,'product',363,990,1),(463,'product',363,991,2),(464,'product',363,989,3),(465,'product',363,993,4),(466,'product',363,988,5);
/*!40000 ALTER TABLE `media_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `message_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `user_from` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `user_to` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `message_text` text COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `message_id` (`message_id`),
  KEY `project_idx` (`project_idx`),
  CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_definitions`
--

DROP TABLE IF EXISTS `page_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `page_definitions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `page_definition_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `identifier` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `parent_page_definition_id` bigint DEFAULT NULL,
  `allowed_sections` json DEFAULT (json_array()),
  `config_schema` json DEFAULT (json_object()),
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `page_definition_id` (`page_definition_id`),
  KEY `fk_page_definitions_parent` (`parent_page_definition_id`),
  CONSTRAINT `fk_page_definitions_parent` FOREIGN KEY (`parent_page_definition_id`) REFERENCES `page_definitions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_definitions`
--

LOCK TABLES `page_definitions` WRITE;
/*!40000 ALTER TABLE `page_definitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `customer_id` bigint DEFAULT NULL,
  `serial_number` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `highlight` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` text COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `note` text COLLATE utf8mb4_general_ci,
  `make` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `model` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `type` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `length` decimal(6,2) DEFAULT NULL,
  `width` decimal(6,2) DEFAULT NULL,
  `height` decimal(6,2) DEFAULT NULL,
  `ordinal` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`),
  UNIQUE KEY `unique_project_serial` (`project_idx`,`serial_number`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=536 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (363,'P-1472922937',25,270,'TSA8490NJC006',NULL,'Green Jacuzzi','INCLUDED:\n  - Free Delivery & Installation\n  - 90-Day Warranty\n  - Brand new cover\n \nThis is an excellent-condition, single-owner Jacuzzi-brand Hot Tub. This tub was purchased new from the Jacuzzi store and maintained by a certified Jacuzzi technician.\n\n✅ Included:\n  - BRAND NEW folding leather cover \n    (You pick the color!)\n  - 90-day warranty \n  - Hot water delivery (if requested)\n  - Again, FREE DELIVERY & INSTALLATION \n\n➕ Additional Accessories:\n   - Spa care kit $200\n   - Entry steps $100\n   - Cover Lifter $150\n  \n🧪 Spa-Care Package ($200):\n   - Skimmer net\n   - Water test strips\n   - Oxidizing Shock\n   - Chlorine granulate \n   - PH Up \n   - PH Down \n   - Water clarifier \n   - Thermometer\n   - Kid-safe sealed bucket for chemicals\n   - Step-by-step tutorial \n\n📏 Dimensions:\n            84\"    x    90\"   x     38\" \n       (Length)x(Width)x(Height)\n\n⚡️ Electrical: 240v, 50A\n\n*** No holds. First-come, first-served. All sales are final. ***','Sold to Dave Anderson. We credited everything he paid towards the brown MAAX spa and swapped them out.\n\nIt has a leak and is back in our shop as of 12/02/25','Jacuzzi','J360',NULL,84.00,90.00,0.00,0,'2025-11-04 21:28:01','2025-12-22 17:58:13'),(366,'P-3834929730',25,270,'TSA8787L2MX038',NULL,'Brown MAAX Spa',NULL,'','MAAX','',NULL,87.00,87.00,34.00,1,'2025-11-04 21:43:31','2025-11-06 01:00:57'),(368,'P-1586806747',25,NULL,'TSA7777N2SR045',NULL,'Small Gray Sunrise Hot Tub','','','Sunrise','Odyssey ',NULL,77.00,77.00,0.00,2,'2025-11-05 15:55:31','2025-12-22 22:42:33'),(369,'P-8047394352',25,267,'SCOTTJOHNSONSWIMSPA',NULL,'Scott Johnson Service Call','Scott Johnson Swim Spa ','',NULL,NULL,NULL,0.00,0.00,0.00,3,'2025-11-05 15:57:38','2025-11-05 16:15:57'),(372,'P-4956068717',25,4026,'TSA8483L2JC080',NULL,'Jacuzzi White Marble Shell','FREE DELIVERY & INSTALLATION INCLUDED\n\nThis is an excellent condition Jacuzzi Hot Tub\n\n✅ Included:\n  - BRAND NEW folding leather cover \n    (You pick the color!)\n  - 90-day warranty \n  - Hot water delivery (if requested)\n  - Again, FREE DELIVERY & INSTALLATION \n\n➕ Additional Accessories:\n   - Spa care kit $200\n   - Entry steps $100\n   - Cover Lifter $150\n  \n🧪 Spa-Care Package ($200):\n   - Skimmer net\n   - Water test strips\n   - Oxidizing Shock\n   - Chlorine granulate \n   - PH Up \n   - PH Down \n   - Water clarifier \n   - Thermometer\n   - Kid-safe sealed bucket for chemicals\n   - Step-by-step tutorial \n\n📏 Dimensions:\n            83\"    x    91\"   x     38\" \n       (Length)x(Width)x(Height)\n\n⚡️ Electrical: 240v, 50A\n\n💲Discounts: As a small business, we’re able to offer discounted rates for customers who purchase BOTH a hot tub + an electrical installation through us! Message for more info!\n\n*** No holds. First come, first serve. ***','Sold to Todd Smith on 12/05/25 - he venmoed griffin on 12/5 $260 for the deposit\nhe is getting some electrical work done for $100\nspa care kit $200','Jacuzzi','J330',NULL,84.00,84.00,0.00,4,'2025-11-05 16:24:41','2025-12-05 19:55:54'),(373,'P-5297536816',25,NULL,'TSA7676N1CT053',NULL,'Small Dark Brown Catalina','FREE DELIVERY & INSTALLATION INCLUDED\n\nThis is an excellent condition Sunrise Odyssey Hot Tub. \n\n✅ Included:\n  - BRAND NEW folding leather cover \n    (You pick the color!)\n  - 90-day warranty \n  - Hot water delivery (if requested)\n  - Again, FREE DELIVERY & INSTALLATION \n\n➕ Additional Accessories:\n   - Spa care kit $200\n   - Entry steps $100\n   - Cover Lifter $150\n  \n🧪 Spa-Care Package ($200):\n   - Skimmer net\n   - Water test strips\n   - Oxidizing Shock\n   - Chlorine granulate \n   - PH Up \n   - PH Down \n   - Water clarifier \n   - Thermometer\n   - Kid-safe sealed bucket for chemicals\n   - Step-by-step tutorial \n\n📏 Dimensions:\n            77\"    x    77\"   x     38\" \n       (Length)x(Width)x(Height)\n\n⚡️ Electrical: 240v, 50A\n\n💲Discounts: As a small business, we’re able to offer discounted rates for customers who purchase BOTH a hot tub + an electrical installation through us! Message for more info!\n\n*** No holds. First come, first serve. ***','Matt is interested. No deposit collected yet. waiting to get pics of his electrical system before confirming prices - Matt never got back\n\n\n\n','Catalina',NULL,NULL,76.00,76.00,0.00,5,'2025-11-05 16:28:41','2025-12-02 17:47:47'),(383,'P-9388566084',25,273,'TSA8491L2JC067',NULL,'Jacuzzi Silver Shell',NULL,'Barbra interested. Has not paid the deposit yet','Jacuzzi','J355',NULL,84.00,91.00,0.00,6,'2025-11-05 22:16:25','2025-11-05 22:21:16'),(390,'P-6756275021',25,NULL,'TSA8484L1JC078',NULL,'Light Brown Jacuzzi J335','FREE DELIVERY & INSTALLATION INCLUDED\n\nThis is an excellent condition 50th Anniversary Edition Jacuzzi Hot Tub!\n\n✅ Included:\n  - BRAND NEW folding leather cover \n    (You pick the color!)\n  - 90-day warranty \n  - Hot water delivery (if requested)\n  - Again, FREE DELIVERY & INSTALLATION \n\n➕ Additional Accessories:\n   - Spa care kit $200\n   - Entry steps $100\n   - Cover Lifter $150\n  \n🧪 Spa-Care Package ($200):\n   - Skimmer net\n   - Water test strips\n   - Oxidizing Shock\n   - Chlorine granulate \n   - PH Up \n   - PH Down \n   - Water clarifier \n   - Thermometer\n   - Kid-safe sealed bucket for chemicals\n   - Step-by-step tutorial \n\n📏 Dimensions:\n            84\"    x    84\"   x     38\" \n       (Length)x(Width)x(Height)\n\n⚡️ Electrical: 240v, 50A\n\n💲Discounts: As a small business, we’re able to offer discounted rates for customers who purchase BOTH a hot tub + an electrical installation through us! Message for more info!\n\n*** No holds. First come, first serve. ***','','Jacuzzi','J335',NULL,84.00,84.00,0.00,7,'2025-11-07 15:35:29','2025-12-15 19:20:33'),(399,'P-0168938282',124,NULL,'4EWFASDFSDF',NULL,'',NULL,'',NULL,NULL,NULL,0.00,0.00,0.00,0,'2025-11-12 03:18:13','2025-11-12 03:18:13'),(430,'P-3830514431',25,4005,'TSA90100L2EL032',NULL,'Big Elite Spa From Pettis',NULL,'Needs parts installed \n\nThe customer is unhappy and left a bad review due to poor communication\nWe were supposed to install/give him parts and a cover\nHe is waiting for a new cover that was never ordered','Elite Spas',NULL,NULL,0.00,0.00,0.00,8,'2025-11-25 20:40:47','2025-11-25 20:47:16'),(448,'P-3210804179',136,4005,'1234512345',NULL,'Test Product','','Can I get a hell yeah Can I get a hell yeah Can I get a hell yeah Can I get a hell yeah Can I get a hell yeah Can I get a hell yeah Can I get a hell yeah Can I get a hell yeah Can I get a hell yeah Can I get a hell yeah Can I get a hell yeah Can I get a hell yeah Can I get a hell yeah ','',NULL,NULL,0.00,0.00,0.00,0,'2025-12-02 21:06:07','2025-12-03 05:55:32'),(452,'P-5371579840',136,NULL,'123412352134',NULL,'123451234',NULL,'1234',NULL,NULL,NULL,0.00,0.00,0.00,2,'2025-12-02 21:46:35','2025-12-03 06:02:48'),(453,'P-5950312032',25,296,'TSA8484N1MQ087',NULL,'Jared Coates Restoration',NULL,'','Marquise','',NULL,0.00,0.00,0.00,9,'2025-12-02 22:02:09','2025-12-02 22:02:09'),(454,'P-4007215702',25,4007,'TSA9090N2GN091',NULL,'Soloman Tam Restoration',NULL,'','Laguna bay spas ',NULL,NULL,90.00,90.00,34.00,10,'2025-12-02 22:08:00','2025-12-02 22:14:17'),(456,'P-4839502599',25,4009,'TSA90100L2HS090',NULL,'Paul Anastesia Restoration',NULL,'','Hot Springs','Grande',NULL,90.00,100.00,34.00,11,'2025-12-02 22:21:51','2025-12-02 22:21:51'),(457,'P-5905159069',25,NULL,'TSA9090N2SR001',NULL,'New Style Hot Springs Pearl White Shell',NULL,'','Sunrise',NULL,NULL,90.00,90.00,0.00,12,'2025-12-02 22:31:27','2025-12-02 22:34:08'),(459,'P-1554677931',25,NULL,'TSA9090L2SR000',NULL,'Black Sunrise With Brown Shell',NULL,'','Sunrise',NULL,NULL,90.00,90.00,34.00,13,'2025-12-02 22:35:56','2025-12-02 22:35:56'),(460,'P-7910743349',25,NULL,'TSA90100N1HS002',NULL,'Older Big Hot Springs','','','Hot Springs','Grande',NULL,0.00,0.00,0.00,14,'2025-12-02 22:37:16','2025-12-22 23:17:19'),(462,'P-0703677343',25,NULL,'TSA8484L1HT003',NULL,'Older Mid-Sized Hot Springs',NULL,'','Hot Springs',NULL,NULL,84.00,84.00,34.00,15,'2025-12-02 22:38:54','2025-12-02 22:39:11'),(465,'P-4045340792',25,NULL,'TSA8484L3JC004',NULL,'Cameo Shell Jacuzzi',NULL,'','Jacuzzi',NULL,NULL,84.00,84.00,34.00,16,'2025-12-02 22:39:55','2025-12-02 22:40:21'),(468,'P-3026258136',25,436,'TSA8484L2HP005',NULL,'Good Condiation Hot Spot',NULL,'','Hot Spot','Relay',NULL,84.00,84.00,34.00,17,'2025-12-02 22:41:34','2025-12-09 05:56:06'),(473,'P-0487228452',25,NULL,'TSA9199N3HS088',NULL,'Newer Silver Hot Springs Grande','','Dan Brake is interested in purchasing','Hot Springs','Grande',NULL,90.00,100.00,34.00,18,'2025-12-02 22:45:38','2026-01-11 06:05:56'),(476,'P-5505454294',136,NULL,'TESTAWERWR',NULL,'test',NULL,'',NULL,NULL,NULL,0.00,0.00,0.00,1,'2025-12-03 05:46:32','2025-12-03 05:55:32');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_integrations`
--

DROP TABLE IF EXISTS `project_integrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_integrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `integration_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `integration_key` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `integration_value` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `integration_id` (`integration_id`),
  UNIQUE KEY `uq_project_module` (`project_idx`,`integration_key`),
  CONSTRAINT `project_integrations_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_integrations`
--

LOCK TABLES `project_integrations` WRITE;
/*!40000 ALTER TABLE `project_integrations` DISABLE KEYS */;
INSERT INTO `project_integrations` VALUES (12,'I-4399925184',25,'GOOGLE_MAPS_API_KEY','U2FsdGVkX1+ammiudE6UPHcYnc23EEBrBRTQyezzpmPILI4ZPq44pb3Rz5E/erGJ+IZX2UksWK6J50Sr664Pfw==','2025-11-15 06:02:33','2025-11-15 06:02:33'),(13,'I-2094220214',25,'WIX_GENERATED_SECRET','U2FsdGVkX18PhcWN1J5P7S5iFX9VPqfRRgFLv08spOtBzOQShlcvZnb1s61hQowFEVl0Uf+0KD8/AVky7JuZTJmTJuZHXBvRBmmWHcgpmteFFMtNA3SO4Ud44iwrAwCk','2025-11-15 06:35:34','2025-11-15 06:35:34'),(14,'I-5307868029',25,'WIX_BACKEND_URL','U2FsdGVkX19PacMRAXPffIK5XeVVLZQ//XmCyYDhfZ9IiZ2aGCpK2wB32ST+lSbCvyKa9kAvKak3HkjgMd20npOQWZ4yeKPQafonnuvaUEI=','2025-11-15 06:35:41','2025-11-15 06:35:41'),(15,'I-2485151321',25,'GOOGLE_SERVICE_ACCOUNT_JSON','U2FsdGVkX1/FykkWxfyUohcK40CdPrxyebTftCVThSDVr8nNsZlbUdQuLJUQHnBBEcr+GW7Q+6HF7+YayBIKHmrWnN9FfdxclyjOCg1+vdF+I/q78FaU7DZBD6cDRodXmQBxaNWVVWb6Fquk2oSV36HOeUV87IAkFPVsDQAxl7dI7p8YgxLMSCLV6Iwe+dYdFbWveExzZAlBeR74sLqYw7l4CMDZENUZfPRN9ERV1ZMFE6qGNDYokOxxhvfvAytPyatkkL3/zmPNFcTjvvxhl/P4D65oW/XGZearkjC8YGkGpfUgsKb0UA1qV7MFuBiniNtiWJnq/AZ9IMpeBmA3IYPnmvE2n16qejEqZH3tHsPBwkFelcaLchexCYHEfaanQX2wtDq1ZmGXkjbW3iV//4jKJ11y5l6+IuTZAE3rkcoSUKYRA+JYAMLsg68X1+EkV1jR9P9KF8ka3zUdyxV3bWfUNuoCLA7VTHKXbYlwrl5XMNdItq+XOlXc7sMsHjceBgeMzB9DQUsqrFfN1aKH26fv1uvF1B2RV8/0yqzYhMzCEuYAoO+NVuR0ezjZsYT13Nm+HflYnsn2pu9jOWbk8VaCCqd0dhizI6ANqckAeO4Kjs4FDlpo1dnMDn/xpolIMYEM1+KQjjt/nTIPT7M440idKD4nbhgV1MCxL1XsKd9utQKk5hFnp0BsA7L5JEHMxdMvlhOYUYefTVpkFCEcy3BpNQ4xuHHy6za991Qc2k09WpmglxYYm0X3WBhy8odZf39T6iJUwvTPxnjUppQISXqRsRSuG9Kk261Xe4aVvcOdVwAqBzFtx5ctaD91y3J4BX85T8KZgFQ9jHMcIp5+SMtp8jB3pR9FDMn06E1bOX120eae47s/OfsKIcjMlQgxRf+Nqr+h4GGqsbbYZA7QGTi2euY0NQ2ln/8naDKswys0su+Y6/wLD+z1TsvrLLTRxS0AD8w4bC2ZEdTe4TIByrqYgN349lDEjyhFHsTmy+ug52M84Bwu45TYXAe8O7MJJ8GFxkt8zV69hNjdJBtn3n/evi4Y63l5n478dkZpfUh+rIWY09nc9jNVPdXr2D89/Sqs1odH0ExFCh/7RZnk3/wXCIgfGYRG4xt2ZHjJmmg2WYlsViMzFVNPfNVkCFaX8NnSTDyBkZaxkQrh6wIcqEVElto7ebovNUBeE0oIqOI6Wy3Phlcdw31j+VbzbA5tTlwn0V0GLQf3qb/19WwOTOSia21xgP1YflY27WwmmK9YOeJkY7mkGASUOd991hGXAAQjKhoVYzxgTdzg02NzeZReHsJ283dWrM1bIlFXGRZbPnXQM05HdMDOHUaDuxk2UqAP7EtOb4z2IwKBcZmcDoQMXzj3AFGGljOYQE9t2i68QKtG9rF78NHt3mlO1MCEB0PB2i+D9KZaHvUD1eA7Lh6Nm6s7WwvcF9rRcDdEoLZGbvBXmZNLB0yYxT526oGohMnclvEpagnZBmfZx2sBk3CBNp88pWb07MjbN3Pk4WEZ0HMVyVpeNKl3nIM6s4zTOdUpmzBsQ4khB8p87HmWhIuBWODjMv5DKZw46RvlUgi0b6qKfiN4Sqawe8A+dxSanzVU3P9nvxOD05yYOczhxE77DUxvUjMu5CTzsry5WQ8czwL2y57+Xq4tCYbFqZvb+9wOoJDG6i8wMPayyAHJkMV/eNr/KZRzD0TMPoUCIts98EGVRH+xHEnD1eTeCGs3R8BDpxRKPwVk4oxOBWBbegl7DplhrECizRTTdEvuhZ33I3mD/5DCIg7PSh04+zpfDnwbhD150tnTJlovmqfZpIoMtGBCYDEoWG1s7QRFMhhmkZ6xeMaO6NJ9gyrRXEVsEsogOyO7+8EWIcuV/nG+MJtQcKDzbagTz+6QncEdSP7lJaI1B7myEpTJezpGImh6RTAEJZcH+C8WrXlyb4SWxGZMxGEZexitl4I2OOIZZ86QpeUlbB4yiBYCD+ntsKfgSLJ2Yg0P760/sF6mragKSN00Bejs6aTdHmzbOI27YBOIC+953ZiS9/poxvuUdP75kQm+tyyeNkVwSmRf9FNdTpqYkoIKZc5AS4dJuJaAuV/9nnJ4rofTafB/h2EQq6icCit6fV2DdU8mi2IT+MjHuKNKhx+dkihlf5+J4sQgnGNvC4Cd/VA1LsLp1dfGcft0vnTvFhQYkImIP3Fe0/vp8ISq9RrrI2fmPJKGhHmE1qmEnAxtr3wVrVt6CEmMvqyjjJ+QbcMSEu2i7LOKfd8LTrPsiG3M1VQwD66+enmrK14+XtS9cWHt2eAo9zM3dTjia/sfm83R28rA9DGsJ9Yux/JoqW1QOKMnoeXogwvjJg29zOTLl7Fhjdp6wtTIVOX7zD65W3V3LS93mWeMWXAEEChknsTlVfyirV9k6e7leQNTqN3hwz02Bp0Y1d2uHVNjC5CyDOiLhYxX/ybh28pZfCGEBQOQyLKny/UZVnUkMBf4Ux5sjCmQ+XsUGritFw3RtsODMekkT6WWSfACWp1RkKOHxbJ0penkX4JeQbvCkvd56VPLPSnL4xs38Sz6iCVPIIlvDyINZNjJSdBAgAH3Yu+uQDEdQvQTNKwtoZ3eso7kas+ePOAo7e6QB+b42mjD/fafAAJi9C2id/Jv/OEhh0lHc935j6CdNBINDuI1EmSnPOdv8XSN4WM+4/rJ6EhR3GRNqpB1bFCBgNt+I94//b8YpZIEY7CDxvkmQIXDairXsVso8w4zp/6fVFzHyveznW7Fq1ahjP7Hc6Cg7c1Eu/pVKtfBg88QNyYZLaXR+h/I3MftJp6yUL4pVKCSrsp6oDCDMNDF7K0+F18+eCgqwQD5OfTpXk1OCMgfNf6yNNY9rxreeIZarCcMczN/6zSb1UTa4fSgFBsATb/iEFxBsOq0NkOXbIheMEJV5hZvMT6iP6XiY9msmHqVgNEsnh47ieWWSq3Y70lYP7OTc5SvFxnGWSxoYsVsNrsSxb+YqXAR1cLMTmcdnFYHgNM3RAshwq1dfxQU7VUEGSQuzUcarUV2QvqSmUJWcYEEpP0CPvFjBmuAAD/6jbPMAzzbAmsU5rvsloStkL8xti5ktL19K76ZduFJO/BzkmugsGt4I/DVYfuh3JW4q1xZ+k4Ib+NDDfReLQIGVUAVgKu9OcrT2BJDPE204NnQyi9+kMqzF4OQ7I4ZjLKupwYZa7gMA6UL','2025-11-15 06:35:57','2025-11-15 19:39:02'),(16,'I-9075894264',25,'GOOGLE_REFRESH_TOKEN_OBJECT','U2FsdGVkX18Ei6CIzz1EhyRBGIrVz1O/2oMjwDqwuCFf1fLC5BMjq1IPYADu6YiLlPD7+wEsyuCuYh6+DNuyx9vNUp83Minre/J/basB1wPIGw+37q6c3tV2sgbENCxueqeea3ywVRkN0nF73Utqbufi0enWbIzZagjiiArxTNxDYZ6lCZJe+mHmuCkn0H5i+2AY0EJsOa0Zj6iYI439VM9m9pw0SKbFSfuAY8XyRoZ3LlmZDGnzsH8YYz9M55njRc8j4TEta2f+FCNinDz8nhAGdtrCWyhFBOFIOfkwzpkEEjSjYGnciR27l3jJAlVrgzHbZHMPzIGKrCTFvqSZq9x3TpmbphmOPWsCBRLydzcize1IKXx3TueaVmfjT2c9TjprApUaEgcLGFqoU/tqJEPxtslTCVckDJgT3trdhxDo70uR7TG0mcAMlTnUDWT3lztlxAQ3CVYI27kCFLNVKYH45PMBsEJwOeiPAWcsYEZHTa/lF4+PbybqA36I3ghS6VEkfQBPBsmNnf7ZhCkaAbrGJYqorxm9qXOFjtHLzy1OQF9kRByiKtrySzy8Bixmg5+LcHRFZ3I8J3w1dA6/CZ1bBWKd31r/yPcHMIsSWUHkjU/lA3gjpGxbCAVKQLLCFAkhQVAhnfe0VaBV4BLfDeAoZM4PIGH3n6EB+g1BmztC4c/gtiO6/Ze5OIy7+4vMvLdGoHHm7B1n/NbU4jKrzQgpk1dPyAUnzDUt9w9cEZO0k6rMhLR0TrH1qOldshLVFfKj6vTe8VjoSLtMuHD5cGFxXm73vTmkCn8mICgNYopxfMAKg5qvfdZxoav63HQTM9lcQMDV3IlE5fbee2YToowIozjGRCFXcWpDqKkrC2q+n0phapI+YX/1YhTKTGOeAlGjQ2SFJCEq5HoK/9ExiRrtBFRhRIAoGbtU5bHSepzXPlbUW6T0pXZhX/FbS2dzv1wX9RsgsAhzSPXZBTObOJSru8LQjnUur2IGsvoF0zqC1HxPsUU7BM1e91PiMa/kE8vsP69agkxPKIHn70xRZP7CT+QiAcmeq7tyul4MOw4i61JKC8GZ56X0sOTSfmiB8Cam3jIdn6CLVCwWsqFL+WZUC8HD8DDINy0powvxbfvB2AAx5JxWMZRx+JFRLR8i/vNS7wtNevqSnMmo6Usd+RjMh+LD2Zpor1IgPPuP4gYF8ay+lTfD0dVw48JLDkHoE9shlswzGhKVT9JuiDNzMCW/G28KFxXkYJN40kVD2yJM84cc9s/kgapK6dG9l9T5ck71Q2kyeZK10cXXY5h2goikMlj7qIjFRLXd/Ars/pDZmqdvYA34Wi780glnH9Z3W+Y/5SLpzWeNJ4iE7si9pBBzUA9vVbnz1xvWScCIhQbVuH2Myv4pHONfi6TU+7jA32JoNpl25d5Q/Ti1mV2SZtbC4otV7PZljbaYQ34QxXVdrTorDvQZfruuuEUr08eEbDGrWccegUSh7jUjFMXNjoA/A7BjqXc/9TDB1stNrphiKQSKMoGSYRjJW3YnO40r7Jfhyt/92XzU9aOw9o5o9r8NIe6V7SCTT5OGslSL1MNU4kpNVRo5kq1h5qaKiS+0TKKjfHvGXaqVHq0avLF8AVp05owpHGK/BRUNzezo3J4nJBkwHNTr58M6mv/gL4LgcTa3kBCCG40eML+sbA3zXjLApNgqPhUBE+XphPHwbFRILjXjSiuFcRyUfzQyDRNqwBI1yYEkiMUpHFupqcOUB7pRr8dJYd3ndG8NLvg2CEJfTnyro9ftUojUX1/3/XXLDdS6na3iIEcDu8Qh/I0ArBxud0xaBXSXxpyYsJhvxeh+8/bfQ3vrNorTe8A8sPVwMBGdBMunTGJJA8MSXLJYvw/nsvmX6hJVQlC52+R7oM3uTcQSeN1mFfvnmjrHgrrOO7PGCH+mvtQz6+TpBOA0FVJLV04vrdELYPXxjN1+SxhU+Bn2fo9fTAVDmgdS4qNNR1ygzHTtX+iGWxlT6qwtZjaZzihnD/hCEJua8GuKCB0v0SrDGg5GBmyRLqa6wNnXVe5jBYB16YXR8URCR5FEWnxgxdHWaorupgax1YfH5YgMg+oZHDBHhORrRueLHM+3HGBeasAmLCAMw5/0NtVs/JmfFn6NcpI273glRMrMevcIIMFRgRqF8lFvfRe8pLSG5DP1RVuWvSFOkbMzG4G+6lsHhpM/xqAwcjtPUw/EJnUwQuH0qJRJT6nHyVfPD60sdYMrqdYAdoaMzRU5YSaulcOVSkPUAQrdsXzBm8bN/5JJ+vUT9zfLP33DZ25vqiojsA344U5C+X6BCKzMPjbAyuKnlXFSpfaa8BcMzZDaykGgII9t02LmOpYvkCuQ99UxA+/SqCTeDc7pjoOp5HJ1QB5cYxc4RjJYOFs66j4rdKRwmKf/6KjWHrSTXwil3VSAiBHlYDENof+Kjw2Ok/8W+2+bId/H67tLeel2mXR+uIHKL/BRH/ps/LKeJ/PW76dLjY6i+wzW2lEuxaG1n9ycFrSu8/B0a0JaUX8P6T+9l1/s8Dls9tMjIyXAtCSPD3ONDbXwVAtIYpS+2kh0lIYbkqU6hJQgwGR2c36chIUBU2L1D/Gvp7REKYXFriPUR3/gJdoIQEM0eTtpfWhmXw4fFg==','2025-11-15 06:36:12','2025-12-11 02:08:55'),(18,'I-0102549419',25,'GOOGLE_INVENTORY_SHEET_ID','U2FsdGVkX19xl/pJZWXoUPwLaaPNDYCHJFi9v89xhk8JULguGdSDkZ2JUJSGSz0ypTHmG/gZQmta7MKeLDB12Q==','2025-11-15 06:36:28','2025-11-15 06:56:04'),(19,'I-7731023618',25,'GOOGLE_CLIENT_SECRET_OBJECT','U2FsdGVkX1/nVjTWpuMjkhiaJkKk9/eufbToVvYOtkKuVzGPPQSdN4+6Y071cy8Zf5bwbbZWdVehJEE4e0t9Uy+2cH4lqx4a3V5fTsrMf0zV+Pluylx3eNLLKEepmYrPyT+eZeP/TCgljgTbUHGIkdnpEZ8JhU7Bm2WgEFCM074BRpd6/FAsuYYPTANb6xL2P53n20BAsKzI9fMFqvyrnqGWCCSvS/MLWKV5oUJzDHPRdbdsn4WX+Kh2/Srkj8RNLsHTyqFgTHpSOFEwr/HvGpu4sFwniVP/eAtwpvVyH9QOgh07eaSrzNevhM0UP1jpbt78G0hkT/gugsIFgIOufnyeK77a/+3BHGyKLj1p4hyYvO8i8FP0W63yweU6pdH8oZvDv6CXtgtZtoQb0MNVf+3+mmfMqigMDh3/yAoiDkgQx249nt95vTCCToyo/jPc3ygWg8jWsCLcPehtUNwFo9ttDeyUyohkaX3KbWvx6VezSenrCtjJd8yu7cXX+ozeefJk164v5Zgvk+4LPSt3zKWYq+uwmJ8aTrtHnt2sR8Jk1jtyFmC8rig4T2h8yoze','2025-11-15 06:36:38','2025-11-15 19:38:34'),(21,'I-0092252766',25,'GOOGLE_INVENTORY_TAB_GID','U2FsdGVkX18L0lvxyS4E8TJoFwBBnRbsSyhG6fNZRh8=','2025-11-15 07:10:54','2025-11-15 07:10:54'),(22,'I-7244279441',25,'WAVE_ACCESS_TOKEN','U2FsdGVkX193jmocF48GJDMs3hS6MsOgMKeZNeG4doJz8EyEo2rswl8hwovN8+Eb','2025-11-15 17:42:52','2025-11-15 17:42:52'),(23,'I-5968931265',25,'WAVE_BUSINESS_ID','U2FsdGVkX1+oP44fsOXP3wYOhFA+SbtWKRChGhFYpgCOZcXp8tMf4MX9Tijh7pxXlbUM4bVEkpnLordp1ja9AsUKWEfeKWFC5BUilriGl08=','2025-11-15 17:43:08','2025-11-15 17:43:08'),(27,'I-0098297216',124,'GOOGLE_ADS_CAMPAIGN_ID','U2FsdGVkX19ZoaxscCmCGr7fKWzw9PLV4G6VtlhX0UM=','2025-11-18 08:51:26','2025-11-18 08:51:26'),(28,'I-7388032951',124,'GOOGLE_ADS_CLIENT_ID','U2FsdGVkX19zQqnu1fPxS+cvegs6DFA5r6gR+O6zmb2HzXbaDfraa62WWbYnepeVvd8apQoR6w9VhBIAV851I1CYFJfIqItBOytIyVl9dYk25iZmCs9K51TiAmHHGnXZ','2025-11-18 08:51:38','2025-11-18 08:51:38'),(29,'I-8468990082',124,'GOOGLE_ADS_CLIENT_SECRET','U2FsdGVkX1+xAq/+zFCuTnOsVW/UFhjSaE1z7kUA3Q/nO7UuiBgekCx3JdTy3kyh7ASzhgktR5CYnpRLIaM0iA==','2025-11-18 08:51:47','2025-11-18 08:51:47'),(30,'I-1511570799',124,'GOOGLE_ADS_DEVELOPER_TOKEN','U2FsdGVkX18xNlvGeFOcyh93MquBR85/pIjK5adj4nPIri377hwrAqxmGLbWDMNu','2025-11-18 08:51:54','2025-11-18 08:51:54'),(31,'I-8675675412',124,'GOOGLE_ADS_REFRESH_TOKEN','U2FsdGVkX1+a4t5nyAs9artvOh7F4mmGKkxtsBl2xjheeBcT9PPKZdhZ+pf++gxoqHJ7dj5PmEGBe51/aS40/C4MIumDn0IWfwMRcYYziX65/hzWYpgZ/KzPo+lgXi/lmCSr/WhSv3hTsDAGgoJcpcEMivFD3HVjfLlWvZKLfjw=','2025-11-18 08:52:03','2025-11-18 08:52:03'),(32,'I-4025563607',124,'GOOGLE_ADS_CUSTOMER_ID','U2FsdGVkX18I4fPSWxZq9DcL0rdMFLpaQHT+qT477Fg=','2025-11-18 08:52:09','2025-11-18 21:39:53'),(41,'I-9432654248',25,'AWS_REGION','U2FsdGVkX18llyDitMDoZR2ydgv24RtFV5vSYdhYTXw=','2025-11-22 21:35:56','2025-11-22 21:39:16'),(42,'I-6993319914',25,'AWS_S3_MEDIA_BUCKET','U2FsdGVkX186i7C7ZCIiPKV5iXGnKPDYq4/Gmuy2Xkg=','2025-11-22 21:36:29','2025-11-27 18:55:37'),(43,'I-9024999840',25,'AWS_ACCESS_KEY_ID','U2FsdGVkX1/2S300rEXboKHOfzptv7SfBmQLX/Fx8hD9sC4wJtclvVZQgMU7A8n5','2025-11-22 21:36:48','2025-11-22 21:36:48'),(44,'I-7298655920',25,'AWS_SECRET_ACCESS_KEY','U2FsdGVkX1/1dr+3p88/nfvp+IS6XqrJXQNLS9FcG6OyyBcSCVjJwhwfFAacp9eB+ZviP0K6gjCWUUjywV5HGA==','2025-11-22 21:37:00','2025-11-22 21:37:00'),(47,'I-5510003732',136,'AWS_SECRET_ACCESS_KEY','U2FsdGVkX19Lot8cigsmWGJzFTUUU0RzOePRsbg1s6MRHON0z82yTnVBb02tURT5AHNGp5yS6BaHGM6hA5+BOw==','2025-12-02 22:11:47','2025-12-02 22:19:54'),(48,'I-1855556969',136,'AWS_ACCESS_KEY_ID','U2FsdGVkX19ks73zVZMbp2uegbH6mSnWwZ3JZVndpc7RIarWYKrEu7S/egEOZCkS','2025-12-02 22:12:04','2025-12-02 22:19:34'),(49,'I-5384474602',136,'AWS_REGION','U2FsdGVkX18T8IPXy3nDdJvJsS8VqrwXtOsfTg1OY6k=','2025-12-02 22:13:06','2025-12-02 22:13:06'),(50,'I-8526623211',136,'AWS_S3_MEDIA_BUCKET','U2FsdGVkX18kdpo/rbaRtLJDeV5l838kn4vEAofAoSmcuIotgEg2wsEspGMiFRjx','2025-12-02 22:13:17','2025-12-02 22:13:17'),(54,'I-7355641085',25,'GOOGLE_ADS_DEVELOPER_TOKEN','U2FsdGVkX18CIuY6N5kZRPfgJSEJjAZUiXwNyUqSyvV1Z52Xcj1KpAOcg8B80sJG','2025-12-16 23:43:58','2025-12-16 23:43:58'),(55,'I-4730184218',25,'GOOGLE_ADS_CAMPAIGN_ID','U2FsdGVkX19/ZgHuqAojHkO3/Pdru1ypgUFkzkfzr+w=','2025-12-16 23:47:43','2025-12-16 23:47:43'),(56,'I-5705089327',25,'GOOGLE_ADS_CUSTOMER_ID','U2FsdGVkX1+fJCZi46ZfIDe8/msAtBqpz3IA76DL/uY=','2025-12-16 23:47:50','2025-12-17 00:26:44'),(58,'INT-01KEBJ1SBAWP0NNTQ5EBY8Z51G',25,'GOOGLE_CALENDAR_ID','U2FsdGVkX1+TxKtuRmbvVnnr+Vx0k2B2YeFyXShZCrrtOo4OmSmW2tYInwV4BTFmWtmysDweJTRYmTPB2smiuqodIT04kNNTkhldocllH8Yd8Sz1hF/m9pydXbhCzmheMkGDmFfHeZXPnUeyDfV48w==','2026-01-07 06:24:34','2026-01-07 20:37:23'),(60,'INT-01KEZSJH1QJPAGH8RHBDG2FQX5',139,'AWS_S3_MEDIA_BUCKET','U2FsdGVkX18Iu3naZXhiLU+qdHKVQ3L+m87ZIKyNRFStUtNxESZVBhBmel5yWpOr','2026-01-15 03:00:51','2026-01-15 04:08:17'),(61,'INT-01KEZSK4TWFAGRJT8R6YZC5JWG',139,'AWS_REGION','U2FsdGVkX1/Qjw8UfXWB9VIlS8uu4J1iKetGPqwjCs0=','2026-01-15 03:01:11','2026-01-15 03:01:11'),(62,'INT-01KEZSQPWQVAEQ2DRJ0ZPMZEH4',139,'AWS_ACCESS_KEY_ID','U2FsdGVkX19YL+QV4L60pFayWhMqmC4nxD655kdwSOK5/gfnseRpwrE6t4ZbbEoA','2026-01-15 03:03:41','2026-01-15 03:03:41'),(63,'INT-01KEZSREQ5YK3P4VDPQDYBQ1PN',139,'AWS_SECRET_ACCESS_KEY','U2FsdGVkX195+9XqbdD/tVqAzKsN7ctRk5XFotxWMBRT3sBvfZNFnLAin5xWHCZ1A0Dm8pOYJSw4VXZpwaQjrg==','2026-01-15 03:04:05','2026-01-15 03:04:05'),(65,'INT-01KF4AXJQ95E2AHKNPAY880Z4X',132,'AWS_REGION','U2FsdGVkX1+MFIMOlB9Ug1K/TEqIt9XefFk72roN5Ik=','2026-01-16 21:20:57','2026-01-16 21:20:57'),(66,'INT-01KF4AXWYKMN2JA49C4DSPRB02',132,'AWS_ACCESS_KEY_ID','U2FsdGVkX19Z6S5W/Fj7m5ePRqxXc+cCSh3S5xPwcANh1+WIYc2BBUE6PLEX+/Or','2026-01-16 21:21:07','2026-01-16 21:21:07'),(67,'INT-01KF4AY5F8QCR7PFMKMA33Q8JB',132,'AWS_SECRET_ACCESS_KEY','U2FsdGVkX19qUcvojrj6wlwawC5yTiiKuQLi/7kJsnsu6YmaYP+quVYUy1fQWAkifDomZ5t4cpuVOdwPbU9Guw==','2026-01-16 21:21:16','2026-01-16 21:21:16'),(68,'INT-01KF4AYD3CGGV0RQJCNEPGYH9R',132,'AWS_S3_MEDIA_BUCKET','U2FsdGVkX19e3cYgB8c/hMfcMElVFlAGseqdq8f6+NIOfjHIV12G9MsN021oCktl','2026-01-16 21:21:24','2026-01-16 21:21:24');
/*!40000 ALTER TABLE `project_integrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_invitations`
--

DROP TABLE IF EXISTS `project_invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_invitations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `token` char(64) COLLATE utf8mb4_general_ci NOT NULL,
  `clearance` decimal(4,2) NOT NULL DEFAULT '1.00',
  `created_by` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NOT NULL,
  `accepted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  UNIQUE KEY `uniq_project_email` (`project_idx`,`email`),
  KEY `idx_created_by` (`created_by`),
  CONSTRAINT `fk_project_invitations_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_project_invitations_project` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_invitations`
--

LOCK TABLES `project_invitations` WRITE;
/*!40000 ALTER TABLE `project_invitations` DISABLE KEYS */;
INSERT INTO `project_invitations` VALUES (1,25,'walletrodger@gmail.com','c1ea6a49d5639a4e2123955293e22ec056e690a9e2bdbee03c32ae28299f6906',3.00,'aa575ab285f793e2c90c3aa0aba675','2026-01-16 15:48:28','2026-01-16 16:42:48','2026-01-23 16:42:48',NULL),(5,25,'joeygoff10@gmail.com','fba1039a7ee2c61692e522be05d0d3793f07448c8cc27f16a31c185f9421da63',8.00,'aa575ab285f793e2c90c3aa0aba675','2026-01-16 16:24:09',NULL,'2026-01-23 16:24:09',NULL),(6,25,'joeygoff9@gmail.com','de72d0d204de6b7248cba43b0e29ca0dfb7245eccca69dce5ad888cf2af48b5a',3.00,'aa575ab285f793e2c90c3aa0aba675','2026-01-16 16:25:10',NULL,'2026-01-23 16:25:10',NULL),(7,25,'infinityslide03@gmail.com','0e568b03d30870cfc884fb38be32d06840088bda650690ef98ca482c0173bf08',3.00,'aa575ab285f793e2c90c3aa0aba675','2026-01-16 16:26:45','2026-01-16 16:28:09','2026-01-23 16:28:09','2026-01-16 16:28:54'),(9,25,'infinityslide01@gmail.com','cb0aac8d71a6f2bca885ed7683a9d6cb0342aeb5609845b4f04f82c304ad00b7',3.00,'aa575ab285f793e2c90c3aa0aba675','2026-01-16 16:40:59',NULL,'2026-01-23 16:40:59','2026-01-16 16:41:44');
/*!40000 ALTER TABLE `project_invitations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_modules`
--

DROP TABLE IF EXISTS `project_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_modules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `module_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `module_identifier` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `settings` json DEFAULT NULL,
  `required_access` decimal(4,2) NOT NULL DEFAULT '1.00',
  `frontend_visible` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `module_id` (`module_id`),
  UNIQUE KEY `unique_project_idx_module_identifier` (`project_idx`,`module_identifier`),
  KEY `idx_project_idx` (`project_idx`),
  CONSTRAINT `project_modules_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_modules`
--

LOCK TABLES `project_modules` WRITE;
/*!40000 ALTER TABLE `project_modules` DISABLE KEYS */;
INSERT INTO `project_modules` VALUES (7,'M-6701354551','employees-module',25,'[]',1.00,1),(13,'M-6745899459','media-module',25,'[]',1.00,1),(21,'M-4123526402','customer-products-google-sheets-module',25,'[]',1.00,1),(22,'M-6804606366','customer-products-wix-sync-module',25,'[]',1.00,1),(23,'M-4954926823','google-module',25,'[]',1.00,1),(24,'M-7481788209','google-maps-api-module',25,'[]',1.00,1),(35,'M-4611457451','dashboard-module',25,'[]',1.00,1),(56,'M-5939305747','customer-products-module',25,'[]',1.00,1),(58,'M-1290498079','global-media-module',25,'[]',1.00,1),(59,'M-0950679887','pages-module',25,'[]',1.00,1),(62,'M-7404568025','customer-google-wave-sync-module',25,'[]',1.00,1),(63,'M-5835086121','customers-module',25,'[]',1.00,1),(64,'M-7818172343','google-ads-api-module',25,'[]',1.00,1),(65,'M-8244838421','media-module',124,'[]',1.00,1),(66,'M-5331469198','google-module',124,'[]',1.00,1),(67,'M-0198153017','dashboard-module',124,'[]',1.00,1),(68,'M-9983212730','google-ads-api-module',124,'[]',1.00,1),(71,'M-9222878192','google-gmail-module',25,'[]',1.00,1),(72,'M-0185814284','customers-module',136,'[]',1.00,1),(73,'M-1410107891','customer-products-module',136,'[]',1.00,1),(74,'M-8626170465','media-module',136,'[]',1.00,1),(75,'M-5439273707','global-media-module',136,'[]',1.00,1),(76,'M-4375107658','employees-module',136,'[]',1.00,1),(77,'M-7066721070','google-calendar-module',25,'[]',1.00,1),(79,'MOD-01KEZSG07N1SYD32C6VP9VJXSG','media-module',139,'[]',1.00,1),(80,'MOD-01KEZSGAVWGQXQ1WMMKTT9J726','global-media-module',139,'[]',1.00,1),(81,'MOD-01KEZSGWTXASJBQJGG2YXK2T7M','pages-module',139,'[]',1.00,1),(82,'MOD-01KF4ASGVRPQ7RZY77HT3QA8WS','media-module',132,'[]',1.00,1),(83,'MOD-01KF4ASMBQZFVPP3VFCS4J7760','global-media-module',132,'[]',1.00,1),(84,'MOD-01KF4ASR95X2H4FG4R7J4G9ZGB','pages-module',132,'[]',1.00,1),(88,'MOD-01KF4VWYBB27RVRY5DB7D32BQR','customer-leads-module',25,'[]',1.00,1),(89,'MOD-01KF4VWZ9S813DT61WDXZ56KGH','customer-schedule-requests-module',25,'[]',1.00,1);
/*!40000 ALTER TABLE `project_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_pages`
--

DROP TABLE IF EXISTS `project_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_pages` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `page_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `parent_page_id` bigint DEFAULT NULL,
  `definition_id` bigint DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `ordinal` int NOT NULL DEFAULT '0',
  `seo_title` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8mb4_general_ci,
  `seo_keywords` json DEFAULT (json_array()),
  `template` varchar(100) COLLATE utf8mb4_general_ci DEFAULT 'default',
  `published` tinyint(1) DEFAULT '1',
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `page_id` (`page_id`),
  UNIQUE KEY `uq_project_slug` (`project_idx`,`slug`),
  KEY `parent_page_id` (`parent_page_id`),
  KEY `definition_id` (`definition_id`),
  CONSTRAINT `project_pages_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `project_pages_ibfk_2` FOREIGN KEY (`parent_page_id`) REFERENCES `project_pages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `project_pages_ibfk_3` FOREIGN KEY (`definition_id`) REFERENCES `page_definitions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_pages`
--

LOCK TABLES `project_pages` WRITE;
/*!40000 ALTER TABLE `project_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_sections`
--

DROP TABLE IF EXISTS `project_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_sections` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `section_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `parent_section_id` bigint DEFAULT NULL,
  `project_page_id` bigint NOT NULL,
  `definition_id` bigint DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `config` json DEFAULT (json_object()),
  `ordinal` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_id` (`section_id`),
  KEY `project_idx` (`project_idx`),
  KEY `project_page_id` (`project_page_id`),
  KEY `definition_id` (`definition_id`),
  CONSTRAINT `project_sections_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `project_sections_ibfk_2` FOREIGN KEY (`project_page_id`) REFERENCES `project_pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `project_sections_ibfk_3` FOREIGN KEY (`definition_id`) REFERENCES `section_definitions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_sections`
--

LOCK TABLES `project_sections` WRITE;
/*!40000 ALTER TABLE `project_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_themes`
--

DROP TABLE IF EXISTS `project_themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_themes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_id` bigint NOT NULL,
  `theme_id` bigint NOT NULL,
  `applied_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_id` (`project_id`),
  KEY `theme_id` (`theme_id`),
  CONSTRAINT `project_themes_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `project_themes_ibfk_2` FOREIGN KEY (`theme_id`) REFERENCES `themes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_themes`
--

LOCK TABLES `project_themes` WRITE;
/*!40000 ALTER TABLE `project_themes` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_users`
--

DROP TABLE IF EXISTS `project_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `clearance` decimal(4,2) NOT NULL DEFAULT '1.00',
  `invited_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_idx` (`project_idx`,`email`),
  CONSTRAINT `project_users_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_users`
--

LOCK TABLES `project_users` WRITE;
/*!40000 ALTER TABLE `project_users` DISABLE KEYS */;
INSERT INTO `project_users` VALUES (16,'opendreamstudios@gmail.com',25,9.00,'2025-08-27 10:54:27'),(67,'tannyspaacquisitions@gmail.com',25,8.00,'2025-11-03 22:25:49'),(70,'opendreamstudios@gmail.com',124,9.00,'2025-11-12 03:10:26'),(71,'opendreamstudios@gmail.com',132,9.00,'2025-11-20 09:45:32'),(72,'opendreamstudios@gmail.com',136,9.00,'2025-12-02 21:03:37'),(76,'opendreamstudios@gmail.com',139,9.00,'2026-01-15 02:59:11');
/*!40000 ALTER TABLE `project_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `short_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `domain` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `backend_domain` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `brand` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `numbers` json DEFAULT NULL,
  `logo_media_id` varchar(35) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `logo_dark_media_id` varchar(35) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `logo_light_media_id` varchar(35) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_id` (`project_id`),
  KEY `fk_projects_logo_media` (`logo_media_id`),
  KEY `fk_projects_logo_dark_media` (`logo_dark_media_id`),
  KEY `fk_projects_logo_light_media` (`logo_light_media_id`),
  CONSTRAINT `fk_projects_logo_dark_media` FOREIGN KEY (`logo_dark_media_id`) REFERENCES `media` (`media_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_projects_logo_light_media` FOREIGN KEY (`logo_light_media_id`) REFERENCES `media` (`media_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_projects_logo_media` FOREIGN KEY (`logo_media_id`) REFERENCES `media` (`media_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (25,'PROJ-90959de1e1d','TSA Backend','TSA','tannyspaacquisitions.com','https://tannyspaacquisitions.shop','Tanny Spa Acquisition','[9843588401]','MEDIA-4251442848','MEDIA-0048045745','MEDIA-8270842633','2025-08-27 10:54:27'),(124,'PROJ-6182098829','River Aware App','RiverAware',NULL,NULL,'RiverAware',NULL,NULL,NULL,NULL,'2025-11-12 03:10:26'),(132,'PROJ-3133159650','Tri Cities','Tri Cities','https://tricitiesremodelingco.com/','https://tricitiesremodeling.shop','Tri Cities',NULL,'MEDIA-01KF54FFSZWP4CZ52VFQNZRRYY',NULL,NULL,'2025-11-20 09:45:32'),(136,'PROJ-3070432425','Test',NULL,'test',NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-02 21:03:37'),(139,'PROJ-01KEZSFF4BGT67PQ7YJAR6DAM7','Slate & Glass','SAV','sngluxury.com',NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-15 02:59:11');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_requests`
--

DROP TABLE IF EXISTS `schedule_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule_requests` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `schedule_request_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `customer_id` varchar(35) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `job_id` varchar(35) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `source_type` enum('customer','internal','ai','public') COLLATE utf8mb4_general_ci NOT NULL,
  `source_user_id` varchar(35) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `request_type` enum('create','update','delete') COLLATE utf8mb4_general_ci NOT NULL,
  `calendar_event_id` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `event_title` text COLLATE utf8mb4_general_ci,
  `event_description` text COLLATE utf8mb4_general_ci,
  `metadata` json DEFAULT NULL,
  `proposed_start` datetime DEFAULT NULL,
  `proposed_end` datetime DEFAULT NULL,
  `proposed_reschedule_start` datetime DEFAULT NULL,
  `proposed_reschedule_end` datetime DEFAULT NULL,
  `proposed_location` text COLLATE utf8mb4_general_ci,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'pending',
  `ai_reasoning` text COLLATE utf8mb4_general_ci,
  `confirmation_sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `resolved_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `schedule_request_id` (`schedule_request_id`),
  KEY `project_idx` (`project_idx`),
  KEY `customer_id` (`customer_id`),
  KEY `job_id` (`job_id`),
  CONSTRAINT `schedule_requests_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `schedule_requests_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE SET NULL,
  CONSTRAINT `schedule_requests_ibfk_3` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`job_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_requests`
--

LOCK TABLES `schedule_requests` WRITE;
/*!40000 ALTER TABLE `schedule_requests` DISABLE KEYS */;
INSERT INTO `schedule_requests` VALUES (8,'SREQ-01KEAQT7F8BC8WM0JFYQYJXSQ4',25,NULL,NULL,'public',NULL,'create','ij2kl8udmbqk6d21pp51e4cj7s','Booked Service','Hot tub not heating','{\"product\": {\"make\": \"Strong Spa\", \"year\": \"2022\", \"model\": \"Madrid 60\"}, \"customer\": {\"name\": \"Kristen Fox\", \"email\": \"obrn9377@gmail.com\", \"phone\": \"3154141949\", \"address\": \"9377 Tosch Road, Wolcott, NY 14590\"}}','2026-01-07 11:00:00','2026-01-07 14:00:00',NULL,NULL,'9377 Tosch Road, Wolcott, NY 14590','rejected',NULL,'2026-01-07 19:20:45','2026-01-06 22:46:03','2026-01-08 22:24:26','2026-01-08 22:24:26'),(43,'SREQ-01KECVDS7K09A0NFNWPV13P8GM',25,NULL,NULL,'public',NULL,'create','oqhapmbnmaslt5v2kbgvej37mc','Booked Service','Hot tub only heating some','{\"product\": {\"make\": \"SurfWave\", \"year\": \"2020\", \"model\": \"22 SG\"}, \"customer\": {\"name\": \"Joseph Goff\", \"email\": \"joeygoff13@gmail.com\", \"phone\": \"6037276737\", \"address\": \"42 Rennie Road, Hanover, NH 03755\"}}','2026-01-09 08:00:00','2026-01-09 09:00:00','2026-01-09 13:00:00','2026-01-09 14:30:00','42 Rennie Road, Hanover, NH 03755','approved',NULL,'2026-01-08 19:55:22','2026-01-07 18:27:38','2026-01-08 19:55:22','2026-01-08 19:55:18'),(61,'SREQ-01KED1T34ZK5E99JJTW28DF929',25,NULL,NULL,'public',NULL,'create','lifa8sakcqevuai06j5f82g74g','Booked Service','Hot tub leaking a little','{\"product\": {\"make\": \"Wave22\", \"year\": \"2020\", \"model\": \"234\"}, \"customer\": {\"name\": \"Joey Goff\", \"email\": \"joeygoff13@gmail.com\", \"phone\": \"6037276737\", \"address\": \"42 Rennie Road, Hanover, NH 03755\"}}','2026-01-08 14:00:00','2026-01-08 17:00:00',NULL,NULL,'42 Rennie Road, Hanover, NH 03755','rejected',NULL,'2026-01-09 03:19:06','2026-01-07 20:19:13','2026-01-09 03:19:58','2026-01-09 03:19:58'),(129,'SREQ-01KEGD3963PAQ9NZB3CGV64SKE',25,NULL,NULL,'public',NULL,'create',NULL,'Booked Service','Hot tub leaking a lot','{\"product\": {\"make\": \"jgf\", \"year\": \"hgf\", \"model\": \"hgfh\"}, \"customer\": {\"name\": \"hgfd\", \"email\": \"jv@gmail.com\", \"phone\": \"7654\", \"address\": \", ,\"}}','2026-01-13 09:00:00','2026-01-13 11:00:00',NULL,NULL,', ,','rejected',NULL,NULL,'2026-01-09 03:34:12','2026-01-09 07:58:09','2026-01-09 07:58:09'),(131,'SREQ-01KESTE3QKDVG9AV3VWESVT55Y',25,NULL,NULL,'public',NULL,'create',NULL,'Booked Service','Hot tub only heating some','{\"product\": {\"make\": \"a\", \"year\": \"a\", \"model\": \"a\"}, \"customer\": {\"name\": \"Jo\", \"email\": \"joeygoff13@gmail.com\", \"phone\": \"6037276737\", \"address\": \"42 Rennie Road, Hanover, NH 03755\"}}','2026-01-14 09:00:00','2026-01-14 11:00:00',NULL,NULL,'42 Rennie Road, Hanover, NH 03755','rejected',NULL,NULL,'2026-01-12 19:20:28','2026-01-12 19:20:47','2026-01-12 19:20:47');
/*!40000 ALTER TABLE `schedule_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `section_definitions`
--

DROP TABLE IF EXISTS `section_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `section_definitions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `section_definition_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `identifier` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `parent_section_definition_id` bigint DEFAULT NULL,
  `allowed_elements` json DEFAULT (json_array()),
  `config_schema` json DEFAULT (json_object()),
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_definition_id` (`section_definition_id`),
  KEY `fk_section_definitions_parent` (`parent_section_definition_id`),
  CONSTRAINT `fk_section_definitions_parent` FOREIGN KEY (`parent_section_definition_id`) REFERENCES `section_definitions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section_definitions`
--

LOCK TABLES `section_definitions` WRITE;
/*!40000 ALTER TABLE `section_definitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `section_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `task_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `job_id` bigint DEFAULT NULL,
  `status` enum('waiting_work','waiting_parts','waiting_customer','complete','cancelled') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'waiting_work',
  `priority` enum('low','medium','high','urgent') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'medium',
  `scheduled_start_date` datetime DEFAULT NULL,
  `completed_date` datetime DEFAULT NULL,
  `task` text COLLATE utf8mb4_general_ci,
  `description` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_id` (`task_id`),
  KEY `project_idx` (`project_idx`),
  KEY `job_id` (`job_id`),
  CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tasks_ibfk_2` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3765 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` VALUES (1,'T-8871644771',25,NULL,'waiting_customer','low','2025-11-01 16:00:00',NULL,'blurred','blurred description','2025-09-20 00:23:22','2025-09-20 03:18:19'),(21,'T-6645762078',25,NULL,'waiting_work','medium','2025-09-20 02:54:58',NULL,NULL,NULL,'2025-09-20 02:54:58','2025-09-20 02:54:58'),(22,'T-6287357386',25,NULL,'waiting_work','medium','2025-09-20 02:56:00',NULL,NULL,NULL,'2025-09-20 02:56:00','2025-09-20 02:56:00'),(25,'T-7459029606',25,NULL,'complete','medium','2025-09-26 16:00:00',NULL,NULL,NULL,'2025-09-20 03:20:04','2025-09-20 03:20:25'),(29,'T-8584079177',25,NULL,'cancelled','medium','2025-09-20 03:27:33',NULL,'fjf jadsklfjas dfjasdf','asdasdf klasdjfk ajskdfasdasfd','2025-09-20 03:27:33','2025-09-20 03:57:49'),(48,'T-2033398800',25,NULL,'waiting_parts','urgent','2025-09-24 16:00:00',NULL,'testtt ','test 99','2025-09-20 04:02:28','2025-09-20 14:22:35'),(3369,'T-8038312328',25,NULL,'waiting_parts','medium','2025-09-19 21:50:10',NULL,NULL,NULL,'2025-09-20 21:50:10','2025-09-20 23:11:16'),(3395,'T-2992522073',25,10699,'complete','urgent','2025-09-17 16:35:13',NULL,'task for this day 2221',NULL,'2025-09-21 04:35:13','2025-09-22 22:44:45'),(3405,'T-0661674860',25,11292,'complete','medium','2025-09-21 14:16:34',NULL,NULL,'jkljkl','2025-09-21 22:16:34','2025-09-21 22:17:10'),(3412,'T-8294336944',25,11310,'complete','medium','2025-09-21 13:42:54',NULL,NULL,NULL,'2025-09-22 05:42:55','2025-09-22 18:54:47'),(3418,'T-0049794234',25,10699,'complete','medium','2025-09-21 12:25:58',NULL,'Get the water out',NULL,'2025-09-22 16:25:58','2025-09-22 22:07:09'),(3419,'T-1965096348',25,10699,'complete','medium','2025-09-21 20:26:00',NULL,'Run 100 miles',NULL,'2025-09-22 16:26:00','2025-09-22 19:11:47'),(3456,'T-1665666167',25,11378,'cancelled','medium','2025-09-22 10:44:47',NULL,NULL,'1234','2025-09-22 22:44:47','2025-09-22 23:15:31'),(3461,'T-7340791523',25,NULL,'waiting_work','high','2025-09-22 12:58:41',NULL,'Replace Spa Pack',NULL,'2025-09-23 00:58:41','2025-09-23 01:00:18'),(3464,'T-3248109094',25,NULL,'waiting_work','medium','2025-09-22 12:59:06',NULL,'Replace Left Side Panel',NULL,'2025-09-23 00:59:06','2025-09-23 01:00:18'),(3466,'T-7446057811',25,NULL,'waiting_work','medium','2025-09-22 12:59:29',NULL,'Scrub inside and power wash','Deep clean inside','2025-09-23 00:59:29','2025-09-23 01:00:18'),(3476,'T-3492602909',25,NULL,'cancelled','medium','2025-09-22 13:00:33',NULL,'Replace Broken Wiring',NULL,'2025-09-23 01:00:33','2025-09-23 03:03:15'),(3481,'T-4040632594',25,NULL,'cancelled','medium','2025-09-22 13:01:07',NULL,'Fix pump #3',NULL,'2025-09-23 01:01:08','2025-09-23 03:03:16'),(3484,'T-0846307826',25,NULL,'cancelled','medium','2025-09-22 13:01:33',NULL,'Deep Clean',NULL,'2025-09-23 01:01:33','2025-09-23 03:03:18'),(3489,'T-5987979072',25,11389,'complete','high','2025-09-22 13:02:20',NULL,'Retake Photos',NULL,'2025-09-23 01:02:20','2025-09-23 02:40:33'),(3491,'T-6942418300',25,11389,'complete','medium','2025-09-22 01:02:32',NULL,'125','Lower listing222','2025-09-23 01:02:32','2025-10-22 05:55:02'),(3495,'T-1510107546',25,11394,'waiting_work','medium','2025-09-22 17:02:50',NULL,'Routine Maintenance',NULL,'2025-09-23 01:02:50','2025-09-23 01:02:58'),(3498,'T-1067146813',25,11397,'waiting_work','medium','2025-09-22 21:03:13',NULL,NULL,NULL,'2025-09-23 01:03:13','2025-09-23 01:03:13'),(3499,'T-7232511547',25,NULL,'complete','urgent','2025-09-22 09:48:33',NULL,'Replace jet number 6','f','2025-09-23 01:48:33','2025-10-22 02:54:20'),(3508,'T-9970477989',25,NULL,'complete','high','2025-09-24 12:00:00',NULL,'3332','23234','2025-09-23 17:13:48','2025-09-23 17:15:41'),(3513,'T-4636108331',25,11449,'waiting_work','medium','2025-09-23 01:48:00',NULL,NULL,'jjjnjljkl','2025-09-23 17:48:00','2025-09-24 06:59:40'),(3518,'T-7536541938',25,11449,'waiting_customer','medium','2025-09-23 10:01:18',NULL,NULL,NULL,'2025-09-23 18:01:18','2025-09-25 20:16:26'),(3519,'T-5848530814',25,11449,'waiting_work','medium','2025-09-23 14:01:19',NULL,NULL,NULL,'2025-09-23 18:01:19','2025-09-23 18:01:19'),(3534,'T-8238115249',25,11389,'complete','medium','2025-10-21 13:54:34',NULL,'3','31234','2025-10-22 05:54:34','2025-10-22 05:55:25'),(3535,'T-4550256466',25,11389,'waiting_work','medium','2025-10-22 01:54:36',NULL,NULL,NULL,'2025-10-22 05:54:36','2025-10-22 05:54:36'),(3536,'T-4228873083',25,11389,'waiting_work','medium','2025-10-22 01:54:37',NULL,NULL,NULL,'2025-10-22 05:54:37','2025-10-22 05:54:37'),(3537,'T-1657710988',25,11389,'waiting_work','medium','2025-10-22 01:54:38',NULL,NULL,NULL,'2025-10-22 05:54:38','2025-10-22 05:54:38'),(3547,'T-7565486808',25,11788,'waiting_work','medium','2025-10-22 14:43:03',NULL,NULL,NULL,'2025-10-22 18:43:03','2025-10-22 18:43:03'),(3548,'T-1997773484',25,11867,'waiting_customer','high','2025-10-30 12:00:00',NULL,NULL,NULL,'2025-10-26 10:35:40','2025-10-26 10:35:57'),(3552,'T-2046810699',25,11864,'complete','high','2025-10-26 03:15:02',NULL,'Deep Clean','kk','2025-10-26 11:15:02','2025-10-26 11:15:18'),(3561,'T-0304603638',25,11892,'complete','urgent','2025-10-31 08:21:44',NULL,'plumbing','fix leaks','2025-10-31 20:21:44','2025-11-03 22:36:16'),(3569,'T-5237105127',25,11892,'waiting_work','medium','2025-11-03 17:34:55',NULL,NULL,NULL,'2025-11-03 22:34:56','2025-11-03 22:34:56'),(3576,'T-4713919051',25,11904,'waiting_work','medium','2025-11-03 18:41:42',NULL,NULL,NULL,'2025-11-03 23:41:42','2025-11-03 23:41:42'),(3577,'T-6173575164',25,NULL,'waiting_work','medium','2025-11-04 11:41:25',NULL,NULL,'Fix leak','2025-11-04 21:41:25','2025-11-04 21:42:49'),(3579,'T-5810103042',25,NULL,'waiting_work','medium','2025-11-04 11:42:12',NULL,NULL,'Fix FLO code','2025-11-04 21:42:13','2025-11-04 21:42:49'),(3585,'T-0433325488',25,11986,'complete','medium','2025-11-11 18:56:57',NULL,NULL,NULL,'2025-11-12 19:56:57','2025-11-17 19:21:08'),(3590,'T-7631104588',25,12046,'waiting_work','urgent','2025-12-02 16:00:00',NULL,'Install Waterfalls',NULL,'2025-11-25 20:47:37','2025-12-10 17:30:41'),(3595,'T-9793937077',25,12046,'waiting_work','urgent','2025-11-23 23:51:54',NULL,'Update Ken with situation',NULL,'2025-11-25 20:51:55','2025-12-10 17:30:41'),(3600,'T-9055200375',25,12046,'waiting_work','urgent','2025-11-24 04:53:43',NULL,'Order Waterfall and Cover',NULL,'2025-11-25 20:53:44','2025-12-10 17:30:41'),(3604,'T-9197877367',25,12004,'waiting_work','medium','2025-11-23 09:12:14',NULL,NULL,'fasdfasdf\nasdfasd\n\n\nkjlj jkjlkj','2025-11-26 17:12:14','2025-12-10 02:55:46'),(3632,'T-5496719116',25,12071,'waiting_work','medium','2025-12-01 06:42:02',NULL,'Put down and test for leaks',NULL,'2025-12-02 17:42:02','2025-12-22 17:58:21'),(3634,'T-0178430366',25,12071,'waiting_work','medium','2025-12-01 21:42:28',NULL,'Fix all issues and run for 48 hours',NULL,'2025-12-02 17:42:28','2025-12-22 17:58:21'),(3636,'T-3508672292',25,12071,'waiting_work','medium','2025-12-01 01:42:54',NULL,'Take new listing media and post for sale',NULL,'2025-12-02 17:42:54','2025-12-22 17:58:21'),(3645,'T-5501540662',25,11986,'waiting_work','urgent','2025-12-02 02:45:03',NULL,'Find buyer',NULL,'2025-12-02 17:45:03','2025-12-02 17:45:20'),(3648,'T-1577724853',25,11993,'waiting_work','urgent','2025-12-01 06:46:49',NULL,'Find Buyer',NULL,'2025-12-02 17:46:50','2025-12-19 16:38:06'),(3657,'T-0325121942',25,12126,'waiting_work','urgent','2025-12-01 21:02:22',NULL,'Set down and asses',NULL,'2025-12-02 22:02:22','2025-12-02 22:05:01'),(3662,'T-2887350048',25,12128,'waiting_work','urgent','2025-12-02 07:14:44',NULL,'Set down and asses ',NULL,'2025-12-02 22:14:45','2025-12-02 22:14:57'),(3665,'T-1796696036',25,12130,'waiting_work','urgent','2025-12-02 07:22:09',NULL,'Set down and assess',NULL,'2025-12-02 22:22:09','2025-12-02 22:22:23'),(3668,'T-8850594181',25,12154,'waiting_work','high','2025-12-01 06:46:56',NULL,'Install new heat jet',NULL,'2025-12-02 22:46:56','2026-01-11 05:44:07'),(3671,'T-1344964986',136,12090,'complete','low','2025-12-26 22:00:00',NULL,'999999','77788','2025-12-03 04:23:45','2025-12-03 05:35:23'),(3731,'T-2512488422',25,11987,'waiting_work','urgent','2025-12-11 02:00:00',NULL,'Deliver tub to Todd','Deliver tub and move electrical disconnect box over so it isnt as close to the tub.\nBring cover lifter that is currently attached to tub and spa care kit','2025-12-05 19:55:59','2026-01-13 22:49:29'),(3741,'T-4360023955',25,11987,'waiting_work','urgent','2025-12-11 02:00:00',NULL,'Deliver tub to Todd','Deliver tub and move electrical disconnect box over so it isnt as close to the tub.\nBring cover lifter that is currently attached to tub and spa care kit','2025-12-08 16:22:40','2026-01-13 22:49:29');
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `themes`
--

DROP TABLE IF EXISTS `themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `themes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `config` json NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `themes`
--

LOCK TABLES `themes` WRITE;
/*!40000 ALTER TABLE `themes` DISABLE KEYS */;
/*!40000 ALTER TABLE `themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `twilio_apps`
--

DROP TABLE IF EXISTS `twilio_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `twilio_apps` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `numbers` json DEFAULT NULL,
  `connected_numbers` json DEFAULT NULL,
  `account_sid` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `auth_token` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `api_key` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `api_secret` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `twiml_app_sid` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `project_idx` (`project_idx`),
  CONSTRAINT `twilio_apps_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `twilio_apps`
--

LOCK TABLES `twilio_apps` WRITE;
/*!40000 ALTER TABLE `twilio_apps` DISABLE KEYS */;
INSERT INTO `twilio_apps` VALUES (1,25,'[2319772866]','[5555555555]','AC1e9b18783f8c5979d852d4f7c483535d','6d2703bac920551eb6d2a930619d5daa','SK8d7be33a280a57200e6523d3e73ac06d','M8kNMT9MVCCTsyPux4kFEibqeUyd0Fow','AP3d9642cc096ac1058867c490faf273c4','2025-09-24 19:18:28');
/*!40000 ALTER TABLE `twilio_apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `updates`
--

DROP TABLE IF EXISTS `updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `updates` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `update_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `requested_by` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `assignee` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` enum('requested','upcoming','in_progress','completed') COLLATE utf8mb4_general_ci DEFAULT 'requested',
  `priority` enum('low','medium','high') COLLATE utf8mb4_general_ci DEFAULT 'medium',
  `created_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `update_id` (`update_id`),
  KEY `project_idx` (`project_idx`),
  CONSTRAINT `updates_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `updates`
--

LOCK TABLES `updates` WRITE;
/*!40000 ALTER TABLE `updates` DISABLE KEYS */;
INSERT INTO `updates` VALUES (2,'UPD-3971916912',136,'test5','test5','test',NULL,'in_progress','medium','2025-12-03 09:28:36',NULL);
/*!40000 ALTER TABLE `updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(35) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(200) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `type` enum('internal','external') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'external',
  `first_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `profile_img_src` text COLLATE utf8mb4_general_ci,
  `theme` enum('light','dark') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'dark',
  `auth_provider` enum('google','facebook','discord','local') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'local',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `password_reset` varchar(6) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password_reset_timestamp` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=534 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (505,'aa575ab285f793e2c90c3aa0aba675','opendreamstudios@gmail.com',NULL,1,'internal','Open','Dream','https://lh3.googleusercontent.com/a/ACg8ocLQ1SpRJ3iL9bKeqTyDRLVrBwV-_EG2BfjGosZdVZEZE5LcpFg=s96-c','dark','google','2025-08-23 17:13:30',NULL,NULL),(515,'30b909a2823e7a6dac6839cdcfab9d','tannyspaacquisitions@gmail.com',NULL,0,'internal','Tanny','Spa Acquisitions','https://lh3.googleusercontent.com/a/ACg8ocLapr65yPV_chL_g-CPEhSchwkcxi9Mi--Ie8No_Vh5AvfoFw=s96-c','dark','google','2025-11-03 22:30:07',NULL,NULL),(528,'786e761e2e6716d4f9151a34a4bb96','joeygoff13@gmail.com','$2a$10$1G.DsqFAawS39MgCNHq2uuo17RevhhjtUnFXcmb6vaC.s7G50ZPk2',0,'internal','Test','Test',NULL,'dark','local','2025-12-16 06:58:45',NULL,NULL),(530,'USER-01KED1JSKJAD7QGJNFZKRNYZ1Z','joeygoff10@gmail.com',NULL,0,'external','Joe','Goff','https://lh3.googleusercontent.com/a/ACg8ocLhHPTPpkqnby4ebHxPTg_jTBzWDwZq2dDrkWWckCdSNGMSOQ=s96-c','dark','google','2026-01-07 20:15:14',NULL,NULL),(531,'USER-01KF3RJG1RCHTYC5YNAPQ58HVY','walletrodger@gmail.com',NULL,0,'internal','Rodger','Thoms','https://lh3.googleusercontent.com/a/ACg8ocLygnkWUekYfi53ozqEq-JVKFSJV4Rpo8NxTFaAO6pa-wMlcQ=s96-c','dark','google','2026-01-16 16:00:19',NULL,NULL),(532,'USER-01KF3T6V15A2JV5782DCKAENCX','infinityslide03@gmail.com',NULL,0,'internal','Infinity','Slide','https://lh3.googleusercontent.com/a/ACg8ocKf49XhE8QxQ11AyzgIEaOI0Xo2FZdGovEGC4MtqOfY7Oa3nA=s96-c','dark','google','2026-01-16 16:28:54',NULL,NULL),(533,'USER-01KF3TYAC666HMFJ5XD8M5ER27','infinityslide01@gmail.com',NULL,0,'internal','Infinity','Live','https://lh3.googleusercontent.com/a/ACg8ocKhI5Ap3CyAdSOEb601fgRuE61fKV_tosYMls-b6l68rLMZJg=s96-c','dark','google','2026-01-16 16:41:44',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wix_hourly_traffic`
--

DROP TABLE IF EXISTS `wix_hourly_traffic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wix_hourly_traffic` (
  `id` int NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `unique_visitors` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_timestamp` (`timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=955 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wix_hourly_traffic`
--

LOCK TABLES `wix_hourly_traffic` WRITE;
/*!40000 ALTER TABLE `wix_hourly_traffic` DISABLE KEYS */;
INSERT INTO `wix_hourly_traffic` VALUES (197,'2025-12-19 01:32:04',0),(198,'2025-12-19 02:32:04',0),(199,'2025-12-19 03:32:04',0),(200,'2025-12-19 04:32:04',0),(201,'2025-12-19 05:32:04',0),(202,'2025-12-19 06:32:04',0),(203,'2025-12-19 07:32:04',0),(204,'2025-12-19 08:32:04',0),(205,'2025-12-19 09:32:04',0),(206,'2025-12-19 10:32:04',0),(207,'2025-12-19 11:32:04',0),(208,'2025-12-19 12:32:04',0),(209,'2025-12-19 13:32:04',0),(210,'2025-12-19 14:32:04',0),(211,'2025-12-19 15:32:04',0),(212,'2025-12-19 16:32:04',0),(213,'2025-12-19 17:32:04',0),(214,'2025-12-19 18:32:04',0),(215,'2025-12-19 19:32:04',0),(216,'2025-12-19 20:32:04',0),(217,'2025-12-19 21:32:04',0),(218,'2025-12-19 22:32:04',0),(219,'2025-12-19 23:32:04',0),(220,'2025-12-20 00:32:04',0),(221,'2025-12-20 01:32:04',0),(222,'2025-12-20 02:32:04',0),(223,'2025-12-20 03:32:04',0),(224,'2025-12-20 04:32:04',0),(225,'2025-12-20 05:32:04',0),(226,'2025-12-20 06:32:04',0),(227,'2025-12-20 07:32:04',0),(228,'2025-12-20 08:32:04',0),(229,'2025-12-20 09:32:04',0),(230,'2025-12-20 10:32:04',0),(231,'2025-12-20 11:32:04',0),(232,'2025-12-20 12:32:04',0),(233,'2025-12-20 13:32:04',0),(234,'2025-12-20 14:32:04',0),(235,'2025-12-20 15:32:04',0),(236,'2025-12-20 16:32:04',0),(237,'2025-12-20 17:32:04',0),(238,'2025-12-20 18:32:04',0),(239,'2025-12-20 19:32:04',0),(240,'2025-12-20 20:32:04',0),(241,'2025-12-20 21:32:04',0),(242,'2025-12-20 22:32:04',0),(243,'2025-12-20 23:32:05',0),(244,'2025-12-21 00:32:05',0),(245,'2025-12-21 01:32:05',0),(246,'2025-12-21 02:32:05',0),(247,'2025-12-21 03:32:05',0),(248,'2025-12-21 04:32:05',0),(249,'2025-12-21 05:32:05',0),(250,'2025-12-21 06:32:05',0),(251,'2025-12-21 07:32:05',0),(252,'2025-12-21 08:32:05',0),(253,'2025-12-21 09:32:05',0),(254,'2025-12-21 10:32:05',0),(255,'2025-12-21 11:32:05',0),(256,'2025-12-21 12:32:05',0),(257,'2025-12-21 13:32:05',0),(258,'2025-12-21 14:32:05',0),(259,'2025-12-21 15:32:05',0),(260,'2025-12-21 16:32:05',0),(261,'2025-12-21 17:32:05',0),(262,'2025-12-21 18:32:05',0),(263,'2025-12-21 19:32:05',0),(264,'2025-12-21 20:32:05',0),(265,'2025-12-21 21:32:05',0),(266,'2025-12-21 22:32:05',0),(267,'2025-12-21 23:32:05',0),(268,'2025-12-22 00:32:05',0),(269,'2025-12-22 01:32:05',0),(270,'2025-12-22 02:32:05',0),(271,'2025-12-22 03:32:05',0),(272,'2025-12-22 04:32:05',0),(273,'2025-12-22 05:32:05',0),(274,'2025-12-22 06:32:05',0),(275,'2025-12-22 07:32:05',0),(276,'2025-12-22 08:32:05',0),(277,'2025-12-22 09:32:05',0),(278,'2025-12-22 10:32:05',1),(279,'2025-12-22 11:32:05',0),(280,'2025-12-22 12:32:05',0),(281,'2025-12-22 13:32:05',0),(282,'2025-12-22 14:32:05',0),(283,'2025-12-22 15:32:05',0),(284,'2025-12-22 16:32:05',0),(285,'2025-12-22 17:32:05',0),(286,'2025-12-22 18:32:05',0),(287,'2025-12-22 19:32:05',0),(288,'2025-12-22 20:32:05',0),(289,'2025-12-22 21:09:46',0),(290,'2025-12-22 21:32:05',5),(291,'2025-12-22 22:09:46',0),(292,'2025-12-22 22:32:05',0),(293,'2025-12-22 23:58:38',0),(294,'2025-12-23 00:58:38',0),(295,'2025-12-23 01:58:38',0),(296,'2025-12-23 02:58:38',0),(297,'2025-12-23 03:58:38',0),(298,'2025-12-23 04:58:38',0),(299,'2025-12-23 05:58:38',0),(300,'2025-12-23 06:58:38',0),(301,'2025-12-23 07:19:39',0),(302,'2025-12-23 07:58:38',0),(303,'2025-12-23 08:58:38',0),(304,'2025-12-23 09:58:38',0),(305,'2025-12-23 10:41:39',0),(306,'2025-12-23 10:58:38',0),(307,'2025-12-23 11:58:38',0),(308,'2025-12-23 12:58:38',0),(309,'2025-12-23 13:10:48',0),(310,'2025-12-23 13:58:38',0),(311,'2025-12-23 14:58:38',0),(312,'2025-12-23 15:42:34',0),(313,'2025-12-23 15:58:38',0),(314,'2025-12-23 16:58:38',0),(315,'2025-12-23 17:58:38',0),(316,'2025-12-23 18:58:38',0),(317,'2025-12-23 19:58:38',0),(318,'2025-12-23 20:58:38',0),(319,'2025-12-23 21:58:38',0),(320,'2025-12-23 22:58:38',0),(321,'2025-12-23 23:58:38',0),(322,'2025-12-24 00:58:38',0),(323,'2025-12-24 01:58:38',0),(324,'2025-12-24 02:58:39',0),(325,'2025-12-24 03:58:39',0),(326,'2025-12-24 04:58:39',0),(327,'2025-12-24 05:58:39',0),(328,'2025-12-24 06:58:39',0),(329,'2025-12-24 07:58:39',0),(330,'2025-12-24 08:58:39',0),(331,'2025-12-24 09:58:39',0),(332,'2025-12-24 10:58:39',0),(333,'2025-12-24 11:58:39',0),(334,'2025-12-24 12:58:39',0),(335,'2025-12-24 13:58:39',0),(336,'2025-12-24 14:58:39',0),(337,'2025-12-24 15:58:39',0),(338,'2025-12-24 16:58:39',1),(339,'2025-12-24 17:58:39',0),(340,'2025-12-24 18:58:39',0),(341,'2025-12-24 19:58:39',0),(342,'2025-12-24 20:58:39',0),(343,'2025-12-24 21:58:39',0),(344,'2025-12-24 22:58:39',0),(345,'2025-12-24 23:58:39',0),(346,'2025-12-25 00:58:39',0),(347,'2025-12-25 01:58:39',0),(348,'2025-12-25 02:58:39',0),(349,'2025-12-25 03:58:39',0),(350,'2025-12-25 04:58:39',0),(351,'2025-12-25 05:58:39',0),(352,'2025-12-25 06:58:39',0),(353,'2025-12-25 07:58:39',0),(354,'2025-12-25 08:58:39',0),(355,'2025-12-25 09:58:39',0),(356,'2025-12-25 10:58:39',0),(357,'2025-12-25 11:58:39',0),(358,'2025-12-25 12:58:39',0),(359,'2025-12-25 13:58:39',0),(360,'2025-12-25 14:58:39',0),(361,'2025-12-25 15:58:39',0),(362,'2025-12-25 16:58:39',0),(363,'2025-12-25 17:58:39',0),(364,'2025-12-25 18:58:39',0),(365,'2025-12-25 19:58:39',0),(366,'2025-12-25 20:58:39',0),(367,'2025-12-25 21:58:39',0),(368,'2025-12-25 22:58:39',0),(369,'2025-12-25 23:58:39',0),(370,'2025-12-26 00:58:39',0),(371,'2025-12-26 01:58:39',0),(372,'2025-12-26 02:58:39',0),(373,'2025-12-26 03:58:39',0),(374,'2025-12-26 04:58:39',0),(375,'2025-12-26 05:58:39',0),(376,'2025-12-26 06:58:39',0),(377,'2025-12-26 07:58:39',0),(378,'2025-12-26 08:58:39',0),(379,'2025-12-26 09:58:39',0),(380,'2025-12-26 10:58:39',0),(381,'2025-12-26 11:58:39',0),(382,'2025-12-26 12:58:39',0),(383,'2025-12-26 13:58:39',0),(384,'2025-12-26 14:58:39',0),(385,'2025-12-26 15:58:39',0),(386,'2025-12-26 16:58:39',0),(387,'2025-12-26 17:58:39',0),(388,'2025-12-26 18:58:39',0),(389,'2025-12-26 19:58:39',0),(390,'2025-12-26 20:58:39',0),(391,'2025-12-26 21:58:39',0),(392,'2025-12-26 22:58:40',0),(393,'2025-12-26 23:58:40',0),(394,'2025-12-27 00:58:40',0),(395,'2025-12-27 01:58:40',0),(396,'2025-12-27 02:58:40',0),(397,'2025-12-27 03:58:40',0),(398,'2025-12-27 04:58:40',0),(399,'2025-12-27 05:58:40',0),(400,'2025-12-27 06:58:40',0),(401,'2025-12-27 07:58:40',0),(402,'2025-12-27 08:58:40',0),(403,'2025-12-27 09:58:40',0),(404,'2025-12-27 10:58:40',0),(405,'2025-12-27 11:58:40',0),(406,'2025-12-27 12:58:40',0),(407,'2025-12-27 13:58:40',0),(408,'2025-12-27 14:58:40',0),(409,'2025-12-27 15:58:40',0),(410,'2025-12-27 16:58:40',1),(411,'2025-12-27 17:58:40',0),(412,'2025-12-27 18:58:40',0),(413,'2025-12-27 19:58:40',0),(414,'2025-12-27 20:58:40',0),(415,'2025-12-27 21:58:40',0),(416,'2025-12-27 22:58:40',0),(417,'2025-12-27 23:58:40',0),(418,'2025-12-28 00:58:40',0),(419,'2025-12-28 01:58:40',0),(420,'2025-12-28 02:58:40',0),(421,'2025-12-28 03:58:40',0),(422,'2025-12-28 04:58:40',0),(423,'2025-12-28 05:58:40',0),(424,'2025-12-28 06:58:40',0),(425,'2025-12-28 07:58:40',0),(426,'2025-12-28 08:58:40',0),(427,'2025-12-28 09:58:40',0),(428,'2025-12-28 10:58:40',0),(429,'2025-12-28 11:58:40',0),(430,'2025-12-28 12:58:40',0),(431,'2025-12-28 13:58:40',0),(432,'2025-12-28 14:58:40',0),(433,'2025-12-28 15:58:40',0),(434,'2025-12-28 16:58:40',0),(435,'2025-12-28 17:58:40',0),(436,'2025-12-28 18:58:40',0),(437,'2025-12-28 19:58:40',0),(438,'2025-12-28 20:58:40',0),(439,'2025-12-28 21:58:40',0),(440,'2025-12-28 22:58:40',1),(441,'2025-12-28 23:58:40',0),(442,'2025-12-29 00:58:40',0),(443,'2025-12-29 01:58:40',0),(444,'2025-12-29 02:58:40',0),(445,'2025-12-29 03:58:40',0),(446,'2025-12-29 04:58:40',0),(447,'2025-12-29 05:58:40',0),(448,'2025-12-29 06:58:40',0),(449,'2025-12-29 07:58:40',0),(450,'2025-12-29 08:58:40',0),(451,'2025-12-29 09:58:40',0),(452,'2025-12-29 10:58:40',0),(453,'2025-12-29 11:58:40',0),(454,'2025-12-29 12:58:40',0),(455,'2025-12-29 13:58:40',0),(456,'2025-12-29 14:58:40',0),(457,'2025-12-29 15:58:40',0),(458,'2025-12-29 16:58:40',0),(459,'2025-12-29 17:58:40',0),(460,'2025-12-29 18:58:40',0),(461,'2025-12-29 19:58:40',0),(462,'2025-12-29 20:58:40',0),(463,'2025-12-29 21:58:40',0),(464,'2025-12-29 22:58:40',0),(465,'2025-12-29 23:58:41',0),(466,'2025-12-30 00:58:41',0),(467,'2025-12-30 01:58:41',0),(468,'2025-12-30 02:58:41',0),(469,'2025-12-30 03:58:41',0),(470,'2025-12-30 04:58:41',0),(471,'2025-12-30 05:58:41',0),(472,'2025-12-30 06:58:41',0),(473,'2025-12-30 07:58:41',0),(474,'2025-12-30 08:58:41',0),(475,'2025-12-30 09:58:41',0),(476,'2025-12-30 10:58:41',0),(477,'2025-12-30 11:58:41',0),(478,'2025-12-30 12:58:41',0),(479,'2025-12-30 13:58:41',0),(480,'2025-12-30 14:58:41',0),(481,'2025-12-30 15:58:41',0),(482,'2025-12-30 16:58:41',0),(483,'2025-12-30 17:58:41',0),(484,'2025-12-30 18:58:41',0),(485,'2025-12-30 19:58:41',0),(486,'2025-12-30 20:58:41',0),(487,'2025-12-30 21:58:41',0),(488,'2025-12-30 22:58:41',0),(489,'2025-12-30 23:58:41',0),(490,'2025-12-31 00:58:41',0),(491,'2025-12-31 01:58:41',0),(492,'2025-12-31 02:58:41',0),(493,'2025-12-31 03:58:41',0),(494,'2025-12-31 04:58:41',0),(495,'2025-12-31 05:58:41',0),(496,'2025-12-31 06:58:41',0),(497,'2025-12-31 07:58:41',0),(498,'2025-12-31 08:58:41',0),(499,'2025-12-31 09:58:41',0),(500,'2025-12-31 10:58:41',0),(501,'2025-12-31 11:58:41',0),(502,'2025-12-31 12:58:41',0),(503,'2025-12-31 13:58:41',0),(504,'2025-12-31 14:58:41',0),(505,'2025-12-31 15:58:41',0),(506,'2025-12-31 16:58:41',0),(507,'2025-12-31 17:58:41',0),(508,'2025-12-31 18:58:41',0),(509,'2025-12-31 19:58:41',0),(510,'2025-12-31 20:58:41',0),(511,'2025-12-31 21:58:41',0),(512,'2025-12-31 22:58:41',0),(513,'2025-12-31 23:58:41',0),(514,'2026-01-01 00:58:41',0),(515,'2026-01-01 01:58:41',0),(516,'2026-01-01 02:58:41',0),(517,'2026-01-01 03:58:41',0),(518,'2026-01-01 04:58:41',0),(519,'2026-01-01 05:58:41',0),(520,'2026-01-01 06:58:41',0),(521,'2026-01-01 07:58:41',0),(522,'2026-01-01 08:58:41',0),(523,'2026-01-01 09:58:41',0),(524,'2026-01-01 10:58:41',0),(525,'2026-01-01 11:58:41',0),(526,'2026-01-01 12:58:41',0),(527,'2026-01-01 13:58:41',0),(528,'2026-01-01 14:58:41',0),(529,'2026-01-01 15:58:41',0),(530,'2026-01-01 16:58:41',0),(531,'2026-01-01 17:58:41',0),(532,'2026-01-01 18:58:41',0),(533,'2026-01-01 19:58:41',0),(534,'2026-01-01 20:58:41',0),(535,'2026-01-01 21:58:41',0),(536,'2026-01-01 22:58:41',0),(537,'2026-01-01 23:58:41',0),(538,'2026-01-02 00:58:41',0),(539,'2026-01-02 01:58:41',0),(540,'2026-01-02 02:58:42',1),(541,'2026-01-02 03:58:42',0),(542,'2026-01-02 04:58:42',0),(543,'2026-01-02 05:58:42',0),(544,'2026-01-02 06:58:42',0),(545,'2026-01-02 07:58:42',0),(546,'2026-01-02 08:58:42',0),(547,'2026-01-02 09:58:42',0),(548,'2026-01-02 10:58:42',0),(549,'2026-01-02 11:58:42',0),(550,'2026-01-02 12:58:42',0),(551,'2026-01-02 13:58:42',0),(552,'2026-01-02 14:58:42',0),(553,'2026-01-02 15:58:42',0),(554,'2026-01-02 16:58:42',0),(555,'2026-01-02 17:58:42',0),(556,'2026-01-02 18:58:42',0),(557,'2026-01-02 19:58:42',0),(558,'2026-01-02 20:58:42',0),(559,'2026-01-02 21:58:42',0),(560,'2026-01-02 22:58:42',0),(561,'2026-01-02 23:58:42',0),(562,'2026-01-03 00:58:42',0),(563,'2026-01-03 01:58:42',0),(564,'2026-01-03 02:58:42',0),(565,'2026-01-03 03:58:42',0),(566,'2026-01-03 04:58:42',0),(567,'2026-01-03 05:58:42',0),(568,'2026-01-03 06:58:42',0),(569,'2026-01-03 07:58:42',0),(570,'2026-01-03 08:58:42',0),(571,'2026-01-03 09:58:42',0),(572,'2026-01-03 10:58:42',0),(573,'2026-01-03 11:58:42',0),(574,'2026-01-03 12:58:42',0),(575,'2026-01-03 13:58:42',0),(576,'2026-01-03 14:58:42',0),(577,'2026-01-03 15:58:42',0),(578,'2026-01-03 16:58:42',0),(579,'2026-01-03 17:58:42',0),(580,'2026-01-03 18:58:42',0),(581,'2026-01-03 19:58:42',0),(582,'2026-01-03 20:58:42',0),(583,'2026-01-03 21:58:42',0),(584,'2026-01-03 22:58:42',0),(585,'2026-01-03 23:58:42',0),(586,'2026-01-04 00:58:42',0),(587,'2026-01-04 01:58:42',0),(588,'2026-01-04 02:58:42',0),(589,'2026-01-04 03:58:42',0),(590,'2026-01-04 04:58:42',0),(591,'2026-01-04 05:58:42',0),(592,'2026-01-04 06:58:42',0),(593,'2026-01-04 07:58:42',0),(594,'2026-01-04 08:58:42',0),(595,'2026-01-04 09:58:42',0),(596,'2026-01-04 10:58:42',0),(597,'2026-01-04 11:58:42',0),(598,'2026-01-04 12:58:42',0),(599,'2026-01-04 13:58:42',0),(600,'2026-01-04 14:58:42',0),(601,'2026-01-04 15:58:42',0),(602,'2026-01-04 16:58:42',0),(603,'2026-01-04 17:58:42',0),(604,'2026-01-04 18:58:42',0),(605,'2026-01-04 19:58:42',0),(606,'2026-01-04 20:58:42',0),(607,'2026-01-04 21:58:42',0),(608,'2026-01-04 22:58:42',0),(609,'2026-01-04 23:58:42',0),(610,'2026-01-05 00:58:42',0),(611,'2026-01-05 01:58:42',0),(612,'2026-01-05 02:58:42',0),(613,'2026-01-05 03:58:42',0),(614,'2026-01-05 04:58:42',0),(615,'2026-01-05 05:58:43',0),(616,'2026-01-05 06:58:43',0),(617,'2026-01-05 07:58:43',0),(618,'2026-01-05 08:58:43',0),(619,'2026-01-05 09:58:43',0),(620,'2026-01-05 10:58:43',0),(621,'2026-01-05 11:58:43',0),(622,'2026-01-05 12:58:43',0),(623,'2026-01-05 13:58:43',0),(624,'2026-01-05 14:58:43',0),(625,'2026-01-05 15:58:43',0),(626,'2026-01-05 16:58:43',0),(627,'2026-01-05 17:58:43',0),(628,'2026-01-05 22:47:53',0),(629,'2026-01-05 23:47:53',0),(630,'2026-01-06 00:47:53',0),(631,'2026-01-06 01:47:53',0),(632,'2026-01-06 02:47:53',0),(633,'2026-01-06 03:47:53',0),(634,'2026-01-06 04:47:53',0),(635,'2026-01-06 05:47:53',1),(636,'2026-01-06 06:47:53',0),(637,'2026-01-06 07:47:53',0),(638,'2026-01-06 08:47:53',0),(639,'2026-01-06 09:47:53',0),(640,'2026-01-06 10:47:53',0),(641,'2026-01-06 11:47:53',1),(642,'2026-01-06 13:30:54',0),(643,'2026-01-06 14:30:54',0),(644,'2026-01-06 15:30:54',0),(645,'2026-01-06 16:30:54',0),(646,'2026-01-06 17:30:54',0),(647,'2026-01-06 18:30:54',0),(648,'2026-01-06 19:30:54',0),(649,'2026-01-06 20:30:54',0),(650,'2026-01-06 21:30:54',0),(651,'2026-01-06 22:30:54',0),(652,'2026-01-06 23:32:21',2),(653,'2026-01-07 00:32:21',0),(654,'2026-01-07 01:32:21',0),(655,'2026-01-07 02:32:21',0),(656,'2026-01-07 03:32:21',0),(657,'2026-01-07 04:53:32',0),(658,'2026-01-07 07:58:03',0),(659,'2026-01-07 08:02:50',0),(660,'2026-01-07 08:58:03',0),(661,'2026-01-07 09:02:50',0),(662,'2026-01-07 09:58:03',0),(663,'2026-01-07 10:02:50',0),(664,'2026-01-07 11:02:50',0),(665,'2026-01-07 12:02:50',0),(666,'2026-01-07 13:02:50',0),(667,'2026-01-07 14:02:50',0),(668,'2026-01-07 15:02:50',0),(669,'2026-01-07 16:02:50',0),(670,'2026-01-07 17:02:50',0),(671,'2026-01-07 18:02:50',0),(672,'2026-01-07 19:02:50',0),(673,'2026-01-07 19:57:36',0),(674,'2026-01-07 20:02:50',0),(675,'2026-01-07 20:57:36',0),(676,'2026-01-07 21:02:50',1),(677,'2026-01-07 22:02:50',6),(678,'2026-01-07 23:02:50',0),(679,'2026-01-07 23:06:26',0),(680,'2026-01-08 00:02:50',0),(681,'2026-01-08 00:25:41',0),(682,'2026-01-08 01:02:50',0),(683,'2026-01-08 01:25:41',0),(684,'2026-01-08 02:45:41',0),(685,'2026-01-08 02:49:54',0),(686,'2026-01-08 03:49:54',0),(687,'2026-01-08 04:40:38',0),(688,'2026-01-08 04:49:54',0),(689,'2026-01-08 05:40:38',0),(690,'2026-01-08 05:49:54',0),(691,'2026-01-08 06:49:54',0),(692,'2026-01-08 07:49:54',0),(693,'2026-01-08 08:49:54',0),(694,'2026-01-08 09:49:54',0),(695,'2026-01-08 10:49:54',0),(696,'2026-01-08 11:49:54',0),(697,'2026-01-08 12:49:54',0),(698,'2026-01-08 13:49:54',0),(699,'2026-01-08 14:49:54',0),(700,'2026-01-08 15:22:15',0),(701,'2026-01-08 15:49:54',0),(702,'2026-01-08 16:49:54',0),(703,'2026-01-08 17:46:20',0),(704,'2026-01-08 17:49:54',0),(705,'2026-01-08 18:46:20',0),(706,'2026-01-08 18:49:54',0),(707,'2026-01-08 19:49:54',3),(708,'2026-01-08 19:59:02',0),(709,'2026-01-08 20:49:54',0),(710,'2026-01-08 21:49:54',0),(711,'2026-01-08 22:49:54',0),(712,'2026-01-08 23:00:45',0),(713,'2026-01-08 23:49:54',0),(714,'2026-01-09 00:00:44',0),(715,'2026-01-09 00:49:54',0),(716,'2026-01-09 01:00:44',0),(717,'2026-01-09 01:49:54',0),(718,'2026-01-09 02:49:54',0),(719,'2026-01-09 03:08:40',0),(720,'2026-01-09 03:49:54',0),(721,'2026-01-09 04:49:54',0),(722,'2026-01-09 05:49:54',0),(723,'2026-01-09 06:49:54',0),(724,'2026-01-09 07:46:20',0),(725,'2026-01-09 07:49:54',0),(726,'2026-01-09 08:49:13',0),(727,'2026-01-09 08:59:07',0),(728,'2026-01-09 09:49:13',0),(729,'2026-01-09 09:59:07',0),(730,'2026-01-09 10:59:07',0),(731,'2026-01-09 11:59:07',0),(732,'2026-01-09 12:49:13',0),(733,'2026-01-09 12:59:07',0),(734,'2026-01-09 13:49:13',0),(735,'2026-01-09 13:59:07',0),(736,'2026-01-09 14:49:13',0),(737,'2026-01-09 14:59:07',0),(738,'2026-01-09 15:49:13',0),(739,'2026-01-09 15:59:07',0),(740,'2026-01-09 16:49:13',0),(741,'2026-01-09 16:59:07',0),(742,'2026-01-09 17:59:08',0),(743,'2026-01-09 18:59:08',0),(744,'2026-01-09 19:09:30',0),(745,'2026-01-09 19:59:08',0),(746,'2026-01-09 20:17:24',0),(747,'2026-01-09 20:59:08',0),(748,'2026-01-09 21:59:08',0),(749,'2026-01-09 22:59:08',0),(750,'2026-01-09 23:03:39',0),(751,'2026-01-09 23:59:08',0),(752,'2026-01-10 00:59:08',0),(753,'2026-01-10 01:59:08',0),(754,'2026-01-10 02:59:08',0),(755,'2026-01-10 03:59:08',0),(756,'2026-01-10 04:59:08',0),(757,'2026-01-10 05:59:08',0),(758,'2026-01-10 06:59:08',0),(759,'2026-01-10 07:59:08',0),(760,'2026-01-10 08:59:08',0),(761,'2026-01-10 09:59:08',0),(762,'2026-01-10 10:17:54',0),(763,'2026-01-10 10:59:08',0),(764,'2026-01-10 11:59:08',0),(765,'2026-01-10 12:17:54',0),(766,'2026-01-10 12:59:08',0),(767,'2026-01-10 13:17:54',0),(768,'2026-01-10 13:59:08',0),(769,'2026-01-10 14:17:54',0),(770,'2026-01-10 14:59:08',0),(771,'2026-01-10 15:17:54',0),(772,'2026-01-10 15:59:08',0),(773,'2026-01-10 16:17:54',0),(774,'2026-01-10 16:59:08',0),(775,'2026-01-10 17:59:08',0),(776,'2026-01-10 18:59:08',0),(777,'2026-01-10 19:59:08',0),(778,'2026-01-10 20:59:08',0),(779,'2026-01-10 21:59:08',0),(780,'2026-01-10 22:01:49',0),(781,'2026-01-10 22:59:08',0),(782,'2026-01-10 23:59:08',0),(783,'2026-01-11 00:59:08',0),(784,'2026-01-11 01:59:08',0),(785,'2026-01-11 02:59:08',0),(786,'2026-01-11 03:59:08',0),(787,'2026-01-11 04:24:45',0),(788,'2026-01-11 04:59:08',0),(789,'2026-01-11 05:59:08',0),(790,'2026-01-11 06:22:59',0),(791,'2026-01-11 06:59:08',0),(792,'2026-01-11 07:59:08',0),(793,'2026-01-11 08:13:27',0),(794,'2026-01-11 09:34:26',0),(795,'2026-01-11 10:34:26',0),(796,'2026-01-11 11:34:26',0),(797,'2026-01-11 12:34:26',0),(798,'2026-01-11 13:34:26',0),(799,'2026-01-11 14:34:26',0),(800,'2026-01-11 15:34:26',0),(801,'2026-01-11 16:34:26',0),(802,'2026-01-11 17:25:07',0),(803,'2026-01-11 17:34:26',0),(804,'2026-01-11 18:34:26',0),(805,'2026-01-11 19:34:26',0),(806,'2026-01-11 20:34:26',0),(807,'2026-01-11 21:34:26',0),(808,'2026-01-11 22:34:26',0),(809,'2026-01-11 23:34:26',0),(810,'2026-01-12 00:34:26',1),(811,'2026-01-12 01:34:26',0),(812,'2026-01-12 02:34:26',0),(813,'2026-01-12 03:34:26',0),(814,'2026-01-12 04:34:26',0),(815,'2026-01-12 05:34:26',0),(816,'2026-01-12 06:34:26',0),(817,'2026-01-12 07:34:26',0),(818,'2026-01-12 08:34:26',0),(819,'2026-01-12 09:34:26',0),(820,'2026-01-12 10:34:26',0),(821,'2026-01-12 11:34:26',0),(822,'2026-01-12 12:34:26',0),(823,'2026-01-12 13:34:26',0),(824,'2026-01-12 14:34:26',0),(825,'2026-01-12 15:34:26',0),(826,'2026-01-12 16:34:26',0),(827,'2026-01-12 17:34:26',0),(828,'2026-01-12 18:34:26',0),(829,'2026-01-12 19:34:26',0),(830,'2026-01-12 20:34:26',0),(831,'2026-01-12 21:34:26',0),(832,'2026-01-12 22:34:26',0),(833,'2026-01-12 23:34:26',0),(834,'2026-01-13 00:34:26',0),(835,'2026-01-13 01:34:26',0),(836,'2026-01-13 02:34:26',0),(837,'2026-01-13 03:34:26',0),(838,'2026-01-13 04:34:26',0),(839,'2026-01-13 05:34:26',0),(840,'2026-01-13 06:34:26',0),(841,'2026-01-13 07:34:26',0),(842,'2026-01-13 08:34:26',0),(843,'2026-01-13 09:34:26',0),(844,'2026-01-13 10:34:26',0),(845,'2026-01-13 11:34:26',0),(846,'2026-01-13 12:34:26',0),(847,'2026-01-13 13:34:26',0),(848,'2026-01-13 14:34:26',0),(849,'2026-01-13 15:34:26',0),(850,'2026-01-13 16:34:26',1),(851,'2026-01-13 17:34:26',1),(852,'2026-01-13 18:34:26',0),(853,'2026-01-13 19:34:26',0),(854,'2026-01-13 20:34:26',0),(855,'2026-01-13 21:34:26',0),(856,'2026-01-13 22:34:26',0),(857,'2026-01-13 23:34:26',0),(858,'2026-01-14 00:34:26',1),(859,'2026-01-14 01:34:26',0),(860,'2026-01-14 02:34:26',0),(861,'2026-01-14 03:34:26',0),(862,'2026-01-14 04:34:26',0),(863,'2026-01-14 05:34:26',0),(864,'2026-01-14 06:34:26',0),(865,'2026-01-14 07:34:26',0),(866,'2026-01-14 08:34:26',0),(867,'2026-01-14 09:34:26',0),(868,'2026-01-14 10:34:26',0),(869,'2026-01-14 11:34:26',0),(870,'2026-01-14 12:34:26',0),(871,'2026-01-14 13:34:26',0),(872,'2026-01-14 14:34:26',0),(873,'2026-01-14 15:34:26',0),(874,'2026-01-14 16:34:26',0),(875,'2026-01-14 17:34:26',0),(876,'2026-01-14 18:34:26',0),(877,'2026-01-14 19:34:26',0),(878,'2026-01-14 20:34:26',0),(879,'2026-01-14 21:34:26',0),(880,'2026-01-14 22:34:26',0),(881,'2026-01-14 23:34:27',0),(882,'2026-01-15 00:34:27',1),(883,'2026-01-15 01:34:27',0),(884,'2026-01-15 02:34:27',0),(885,'2026-01-15 03:34:27',0),(886,'2026-01-15 05:27:24',0),(887,'2026-01-15 06:27:24',0),(888,'2026-01-15 07:27:24',0),(889,'2026-01-15 08:27:24',0),(890,'2026-01-15 09:27:24',0),(891,'2026-01-15 10:27:24',0),(892,'2026-01-15 11:27:24',0),(893,'2026-01-15 12:27:24',0),(894,'2026-01-15 13:27:24',0),(895,'2026-01-15 14:27:24',0),(896,'2026-01-15 15:56:15',0),(897,'2026-01-15 16:56:15',0),(898,'2026-01-15 17:56:15',0),(899,'2026-01-15 18:56:15',0),(900,'2026-01-15 19:56:15',0),(901,'2026-01-15 20:56:15',0),(902,'2026-01-15 21:56:15',0),(903,'2026-01-15 22:56:15',0),(904,'2026-01-15 23:56:15',0),(905,'2026-01-16 00:56:15',0),(906,'2026-01-16 01:56:15',0),(907,'2026-01-16 02:56:15',0),(908,'2026-01-16 03:56:15',0),(909,'2026-01-16 04:56:15',0),(910,'2026-01-16 05:56:15',0),(911,'2026-01-16 06:56:15',0),(912,'2026-01-16 07:56:15',0),(913,'2026-01-16 08:56:15',0),(914,'2026-01-16 09:56:15',0),(915,'2026-01-16 10:56:15',0),(916,'2026-01-16 11:56:15',0),(917,'2026-01-16 12:56:15',0),(918,'2026-01-16 13:56:15',0),(919,'2026-01-16 14:56:15',0),(920,'2026-01-16 15:56:15',0),(921,'2026-01-16 17:39:39',0),(922,'2026-01-16 18:39:39',0),(923,'2026-01-16 19:39:39',0),(924,'2026-01-16 20:39:39',0),(925,'2026-01-16 21:39:39',0),(926,'2026-01-16 22:39:39',0),(927,'2026-01-16 23:39:39',0),(928,'2026-01-17 00:39:39',0),(929,'2026-01-17 01:39:39',0),(930,'2026-01-17 03:21:46',0),(931,'2026-01-17 04:21:46',0),(932,'2026-01-17 05:21:46',0),(933,'2026-01-17 06:21:46',0),(934,'2026-01-17 07:21:46',0),(935,'2026-01-17 08:21:46',0),(936,'2026-01-17 09:21:46',0),(937,'2026-01-17 10:21:46',0),(938,'2026-01-17 11:21:46',0),(939,'2026-01-17 12:21:46',0),(940,'2026-01-17 13:21:46',0),(941,'2026-01-17 14:21:46',0),(942,'2026-01-17 15:21:46',0),(943,'2026-01-17 16:21:46',0),(944,'2026-01-17 17:21:46',0),(945,'2026-01-17 18:21:46',1),(946,'2026-01-17 19:01:22',0),(947,'2026-01-17 19:21:46',0),(948,'2026-01-17 20:01:22',0),(949,'2026-01-17 20:21:46',0),(950,'2026-01-17 21:21:46',0),(951,'2026-01-17 22:21:46',0),(952,'2026-01-17 23:21:46',0),(953,'2026-01-18 00:21:46',0),(954,'2026-01-18 01:21:46',0);
/*!40000 ALTER TABLE `wix_hourly_traffic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'cms'
--

--
-- Dumping routines for database 'cms'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-17 21:19:21

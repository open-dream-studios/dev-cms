-- MySQL dump 10.13  Distrib 9.3.0, for macos14.7 (arm64)
--
-- Host: gondola.proxy.rlwy.net    Database: cms
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assignments`
--

DROP TABLE IF EXISTS `assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assignments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `employee_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `task_id` char(16) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `job_id` char(16) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_employee_task` (`employee_id`,`project_idx`,`task_id`),
  UNIQUE KEY `uq_employee_job` (`employee_id`,`project_idx`,`job_id`),
  KEY `project_idx` (`project_idx`),
  KEY `task_id` (`task_id`),
  KEY `job_id` (`job_id`),
  CONSTRAINT `assignments_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assignments_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE,
  CONSTRAINT `assignments_ibfk_3` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`task_id`) ON DELETE CASCADE,
  CONSTRAINT `assignments_ibfk_4` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`job_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_only_one` CHECK ((((`task_id` is not null) and (`job_id` is null)) or ((`task_id` is null) and (`job_id` is not null))))
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignments`
--

LOCK TABLES `assignments` WRITE;
/*!40000 ALTER TABLE `assignments` DISABLE KEYS */;
INSERT INTO `assignments` VALUES (2,25,'E-6303779525','T-2992522073',NULL,'2025-09-22 19:35:27'),(3,25,'E-6789064209','T-7340791523',NULL,'2025-09-23 00:58:54'),(5,25,'E-6263820295','T-7446057811',NULL,'2025-09-23 00:59:42'),(7,25,'E-6789064209','T-3492602909',NULL,'2025-09-23 01:00:59'),(11,25,'E-6263820295','T-5987979072',NULL,'2025-09-23 02:40:28'),(12,25,'E-6303779525','T-9970477989',NULL,'2025-09-23 17:14:00'),(13,25,'E-6303779525','T-4636108331',NULL,'2025-09-23 17:51:25'),(16,25,'E-6263820295',NULL,'J-7496083178','2025-09-27 23:21:17'),(20,25,'E-6303779525','T-7232511547',NULL,'2025-09-28 00:25:40'),(24,25,'E-6303779525','T-1997773484',NULL,'2025-10-26 10:35:49'),(25,25,'E-6263820295','T-2046810699',NULL,'2025-10-26 11:15:14'),(28,25,'E-6263820295',NULL,'J-3046793295','2025-11-03 23:41:38'),(30,25,'E-6263820295','T-4713919051',NULL,'2025-11-03 23:41:44'),(31,25,'E-6303779525','T-4713919051',NULL,'2025-11-03 23:41:44'),(32,25,'E-0306494859','T-6173575164',NULL,'2025-11-04 21:42:07'),(33,25,'E-6263820295','T-5810103042',NULL,'2025-11-04 21:42:31');
/*!40000 ALTER TABLE `assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `customer_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address_line1` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address_line2` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `state` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `zip` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_id` (`customer_id`),
  KEY `project_idx` (`project_idx`),
  CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=276 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (267,25,'C-3271831449','Scott','Johnson','calvin8@aol.com','3153741369','7001 Bayview Drive','','Sodus Point','New York','14555',NULL,'2025-11-04 15:13:56','2025-11-04 15:49:19'),(270,25,'C-8223585718','Dave','Anderson','dganders@gmail.com','5858571443','1080 Willits Road','','Ontario','New York','14519','','2025-11-04 21:26:48','2025-11-05 00:51:20'),(272,25,'C-1008185348','Matt','Vancuran','','5854023186','2733 Pre Emption Street','','Geneva','New York','14456',NULL,'2025-11-05 17:22:12','2025-11-05 17:22:12'),(273,25,'C-9105548245','Barbra','Strother',NULL,NULL,NULL,NULL,'',NULL,NULL,'Interested in hot tub #67','2025-11-05 22:17:15','2025-11-05 22:18:08'),(275,25,'C-7572301199','Matt','Lance','','7162900829',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-07 16:00:57','2025-11-07 16:00:57');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `employee_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address_line1` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address_line2` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `state` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `zip` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `position` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `department` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `hire_date` datetime DEFAULT NULL,
  `termination_date` datetime DEFAULT NULL,
  `notes` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employee_id` (`employee_id`),
  KEY `project_idx` (`project_idx`),
  CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=194 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (115,25,'E-6263820295','Paul','Tanny','paultanny@gmail.com','1425342342','','','','','','CEO BITCH YUHHHHHHHH','Service',NULL,NULL,'','2025-09-22 10:54:33','2025-11-12 19:44:52'),(130,25,'E-6789064209','Brandon','Tanny','brandontanny@gmail.com','1384824232','','','','','','Owner & CEO','',NULL,NULL,'','2025-09-22 10:59:11','2025-11-12 19:44:14'),(133,25,'E-6303779525','Joey','Goff','joeygoff13@gmail.com','6037276444','','','','','07112','Type Shit','Aaah',NULL,NULL,'','2025-09-22 10:59:29','2025-11-12 19:44:43'),(185,25,'E-0306494859','James','Ludwig','','5853513662','','','','','','Shop Technician','Work Shop',NULL,NULL,'','2025-11-03 23:33:22','2025-11-03 23:33:36'),(188,25,'E-8101316451','Roger','Thomas','','3157054864','','','','','','','',NULL,NULL,'','2025-11-03 23:34:09','2025-11-03 23:34:09');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_definitions`
--

DROP TABLE IF EXISTS `job_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_definitions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_definition_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_definition_id` (`job_definition_id`),
  KEY `project_idx` (`project_idx`),
  CONSTRAINT `job_definitions_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_definitions`
--

LOCK TABLES `job_definitions` WRITE;
/*!40000 ALTER TABLE `job_definitions` DISABLE KEYS */;
INSERT INTO `job_definitions` VALUES (3,'ceafbe9ab524f622',25,'Sale','Acquire and resell a hot tub','2025-09-17 18:13:35','2025-11-05 00:55:20'),(4,'96b8b901175a8492',25,'Refurbishment','Customer tub refurbishment','2025-09-17 18:20:37','2025-09-17 18:20:37'),(5,'644b82387191f696',25,'Service','Customer tub service job','2025-09-17 18:20:55','2025-09-17 18:20:55'),(8,'17a315bf52274b31',124,'Sale','Sale','2025-11-12 07:43:59','2025-11-12 07:43:59');
/*!40000 ALTER TABLE `job_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `job_definition_id` bigint DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `customer_id` bigint DEFAULT NULL,
  `valuation` decimal(10,2) DEFAULT NULL,
  `status` enum('waiting_diagnosis','waiting_work','waiting_parts','waiting_listing','listed','waiting_customer','waiting_delivery','complete','delivered','cancelled') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'waiting_work',
  `priority` enum('low','medium','high','urgent') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'medium',
  `scheduled_start_date` datetime DEFAULT NULL,
  `completed_date` datetime DEFAULT NULL,
  `notes` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_id` (`job_id`),
  KEY `project_idx` (`project_idx`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `job_definition_id` (`job_definition_id`),
  CONSTRAINT `jobs_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `jobs_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `jobs_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `jobs_ibfk_4` FOREIGN KEY (`job_definition_id`) REFERENCES `job_definitions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12027 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (10699,'J-7777109774',25,4,NULL,NULL,0.00,'waiting_parts','high','2025-10-16 04:00:00','2025-10-30 23:30:00','Job description','2025-09-20 23:11:52','2025-09-22 22:07:19'),(11292,'J-0466133491',25,5,NULL,NULL,0.00,'complete','urgent','2025-09-17 05:00:00','2025-09-18 04:00:00',NULL,'2025-09-21 22:09:41','2025-09-21 22:18:00'),(11310,'J-8354539608',25,4,NULL,NULL,0.00,'delivered','high','2025-09-16 04:00:00','2025-09-22 04:00:00',NULL,'2025-09-21 23:11:29','2025-09-22 19:12:48'),(11378,'J-3046026214',25,3,NULL,NULL,NULL,'waiting_work','medium',NULL,NULL,NULL,'2025-09-22 22:41:59','2025-09-22 22:41:59'),(11389,'J-5646467867',25,3,NULL,NULL,339.00,'delivered','high','2025-09-03 04:00:00','2025-09-10 04:00:00',NULL,'2025-09-23 01:02:01','2025-10-22 18:24:56'),(11394,'J-5061611354',25,5,NULL,NULL,0.00,'waiting_work','medium',NULL,NULL,NULL,'2025-09-23 01:02:45','2025-09-23 01:02:58'),(11397,'J-5592745445',25,4,NULL,NULL,NULL,'waiting_work','medium',NULL,NULL,NULL,'2025-09-23 01:03:06','2025-09-23 01:03:06'),(11449,'J-7496083178',25,5,NULL,NULL,0.00,'complete','medium','2025-09-25 04:00:00','2025-10-01 04:00:00',NULL,'2025-09-23 17:15:47','2025-10-20 17:19:27'),(11788,'J-8199885383',25,4,NULL,NULL,0.00,'delivered','medium','2025-10-08 04:00:00','2025-10-10 04:00:00','12342342','2025-10-22 18:42:34','2025-10-22 18:50:07'),(11794,'J-9946270990',25,5,NULL,NULL,NULL,'waiting_work','medium',NULL,NULL,NULL,'2025-10-22 23:46:52','2025-10-22 23:46:52'),(11795,'J-5414692569',25,4,NULL,NULL,0.00,'waiting_work','medium','2025-10-15 04:00:00','2025-10-16 15:30:00','hello!!!','2025-10-25 02:30:06','2025-10-25 07:27:22'),(11797,'J-8323419864',25,4,NULL,NULL,0.00,'waiting_work','medium','2025-11-13 05:00:00','2025-11-18 05:00:00',NULL,'2025-10-25 02:39:08','2025-10-25 23:16:18'),(11864,'J-3076511985',25,4,NULL,NULL,0.00,'delivered','medium','2025-10-02 04:00:00','2025-10-03 04:00:00',NULL,'2025-10-26 10:34:09','2025-10-29 06:20:15'),(11867,'J-9833765612',25,5,NULL,NULL,33.00,'waiting_work','medium',NULL,NULL,NULL,'2025-10-26 10:35:21','2025-10-29 23:08:48'),(11880,'J-5680526789',25,3,NULL,NULL,33.42,'cancelled','medium','2025-10-31 04:00:00','2025-11-02 04:00:00',NULL,'2025-10-29 23:07:22','2025-10-30 04:20:24'),(11892,'J-9453891954',25,5,NULL,NULL,0.00,'waiting_work','urgent','2025-10-09 04:00:00','2025-10-31 20:45:00',NULL,'2025-10-30 04:45:42','2025-11-03 23:11:32'),(11904,'J-3046793295',25,3,NULL,NULL,4650.00,'waiting_work','medium',NULL,NULL,NULL,'2025-11-03 23:22:04','2025-11-03 23:26:14'),(11978,'J-2390119693',25,5,369,NULL,0.00,'complete','medium','2025-11-04 05:00:00','2025-11-04 06:00:00','Drain + clean of swim spa\nFull winterization \nStart: 10:30am \nEnd: 2:30pm\n\nWinterization: 750\nClean: 500','2025-11-05 15:58:02','2025-11-05 16:10:05'),(11986,'J-8262245758',25,3,368,NULL,0.00,'listed','urgent',NULL,NULL,NULL,'2025-11-05 16:25:11','2025-11-12 20:05:54'),(11987,'J-0304529701',25,3,372,NULL,2650.00,'listed','urgent',NULL,NULL,NULL,'2025-11-05 16:25:22','2025-11-07 17:43:32'),(11988,'J-3069170594',25,3,366,270,0.00,'delivered','medium',NULL,NULL,NULL,'2025-11-05 16:25:43','2025-11-05 16:26:38'),(11993,'J-6698749251',25,3,373,NULL,2650.00,'listed','urgent',NULL,NULL,NULL,'2025-11-05 16:28:49','2025-11-05 17:19:52'),(12004,'J-6668891028',25,3,390,275,2650.00,'listed','urgent',NULL,NULL,NULL,'2025-11-07 15:35:34','2025-11-12 03:09:51'),(12024,'J-3600230389',124,8,399,NULL,NULL,'waiting_work','medium',NULL,NULL,NULL,'2025-11-12 07:44:00','2025-11-12 07:44:00');
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `media_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `folder_id` bigint DEFAULT NULL,
  `public_id` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `type` enum('image','video','file') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'image',
  `url` text COLLATE utf8mb4_general_ci NOT NULL,
  `alt_text` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `width` int DEFAULT NULL,
  `height` int DEFAULT NULL,
  `size` bigint DEFAULT NULL,
  `tags` json DEFAULT (json_array()),
  `ordinal` int NOT NULL DEFAULT '0',
  `originalName` text COLLATE utf8mb4_general_ci,
  `s3Key` text COLLATE utf8mb4_general_ci,
  `bucket` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `extension` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mimeType` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `transformed` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_id` (`media_id`),
  KEY `project_idx` (`project_idx`),
  KEY `folder_id` (`folder_id`),
  CONSTRAINT `media_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `media_ibfk_2` FOREIGN KEY (`folder_id`) REFERENCES `media_folders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=793 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (728,'MEDIA-9662044530',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F5578f476-3678-4d8e-bb9f-16f0638299b0.webp','',NULL,NULL,NULL,NULL,NULL,0,'2025-11-11-18-49-57-140--ggoxmytol1y0urv8yz65_webp.webp','prod/PROJ-90959de1e1d/5578f476-3678-4d8e-bb9f-16f0638299b0.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:49:58','2025-11-11 23:49:58'),(729,'MEDIA-7390429334',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F079f60ec-bba8-4af4-9f54-1b57f5109f7d.webp','',NULL,NULL,NULL,NULL,NULL,1,'2025-11-11-18-49-57-140--gsloejvdzovkwrdvogf1_webp.webp','prod/PROJ-90959de1e1d/079f60ec-bba8-4af4-9f54-1b57f5109f7d.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:49:58','2025-11-11 23:49:58'),(730,'MEDIA-0202122880',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F0b2b09b7-fcd6-4bdb-b166-c599a3d442e1.webp','',NULL,NULL,NULL,NULL,NULL,2,'2025-11-11-18-49-57-140--i11b6e5qjvv2asvlcvwn_webp.webp','prod/PROJ-90959de1e1d/0b2b09b7-fcd6-4bdb-b166-c599a3d442e1.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:49:58','2025-11-11 23:49:58'),(731,'MEDIA-8748462023',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F75fde21d-e445-457a-87f7-801e1ac3b127.webp','',NULL,NULL,NULL,NULL,NULL,3,'2025-11-11-18-49-57-140--kuf94iwi76c7ewpkirjl_webp.webp','prod/PROJ-90959de1e1d/75fde21d-e445-457a-87f7-801e1ac3b127.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:49:58','2025-11-11 23:49:58'),(732,'MEDIA-9623159786',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F406e75c4-d76f-4db4-92e6-90a3cea61249.webp','',NULL,NULL,NULL,NULL,NULL,5,'2025-11-11-18-49-57-140--nmn3e8c8wmw33rwsbm2h_webp.webp','prod/PROJ-90959de1e1d/406e75c4-d76f-4db4-92e6-90a3cea61249.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:49:58','2025-11-12 19:56:15'),(733,'MEDIA-1477009469',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F0a80f4bb-55df-491a-9a25-3d92a69ba140.webp','',NULL,NULL,NULL,NULL,NULL,4,'2025-11-11-18-49-57-140--pm1shjbupny49fqjpaxo_webp.webp','prod/PROJ-90959de1e1d/0a80f4bb-55df-491a-9a25-3d92a69ba140.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:49:58','2025-11-12 19:56:15'),(734,'MEDIA-1886282550',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fe925cdcc-c827-4b59-b232-30837c7783c4.webp','',NULL,NULL,NULL,NULL,NULL,6,'2025-11-11-18-49-57-140--whz5kgleueldtoulhvut_webp.webp','prod/PROJ-90959de1e1d/e925cdcc-c827-4b59-b232-30837c7783c4.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:49:58','2025-11-11 23:49:58'),(735,'MEDIA-9944328510',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F2a0ba0c5-fdda-4591-af7e-6eea5fb24bb3.webp','',NULL,NULL,NULL,NULL,NULL,7,'2025-11-11-18-49-57-140--yscmeamwdqnh3cpjrbhh_webp.webp','prod/PROJ-90959de1e1d/2a0ba0c5-fdda-4591-af7e-6eea5fb24bb3.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:49:58','2025-11-11 23:49:58'),(736,'MEDIA-5735592662',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F25e31375-1967-4827-8c54-b8fff0e1f987.webp','',NULL,NULL,NULL,NULL,NULL,8,'2025-11-11-18-50-32-842--bjtloupjplmh9zxp1hqp_webp.webp','prod/PROJ-90959de1e1d/25e31375-1967-4827-8c54-b8fff0e1f987.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-11 23:50:34'),(737,'MEDIA-4428080733',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fb5463c45-0a53-4552-9a75-f84240826a9e.webp','',NULL,NULL,NULL,NULL,NULL,9,'2025-11-11-18-50-32-842--jrzdlc5izcl9tf1ogmax_webp.webp','prod/PROJ-90959de1e1d/b5463c45-0a53-4552-9a75-f84240826a9e.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-11 23:50:34'),(738,'MEDIA-3073924498',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F181e3f69-88cf-429e-82fd-eeef27a37085.webp','',NULL,NULL,NULL,NULL,NULL,10,'2025-11-11-18-50-32-842--ldloubbiltkfs4iw4y5s_webp.webp','prod/PROJ-90959de1e1d/181e3f69-88cf-429e-82fd-eeef27a37085.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-11 23:50:34'),(739,'MEDIA-2778362769',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F4fabaf4f-ef7a-4a9d-a793-ea558ae389c0.webp','',NULL,NULL,NULL,NULL,NULL,11,'2025-11-11-18-50-32-842--mlf3xq1q2bvbyecxtfza_webp.webp','prod/PROJ-90959de1e1d/4fabaf4f-ef7a-4a9d-a793-ea558ae389c0.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-11 23:50:34'),(740,'MEDIA-7317459535',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fe4cee457-f179-4194-9c2b-1a7d206117c7.webp','',NULL,NULL,NULL,NULL,NULL,12,'2025-11-11-18-50-32-842--otaqvfpkjl7pygw4pfsr_webp.webp','prod/PROJ-90959de1e1d/e4cee457-f179-4194-9c2b-1a7d206117c7.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-11 23:50:34'),(741,'MEDIA-0193729226',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F2c0689f0-ed5d-43c8-aa4c-9afafd82396e.webp','',NULL,NULL,NULL,NULL,NULL,13,'2025-11-11-18-50-32-842--ruv7tbt3hskjdrjndxmb_webp.webp','prod/PROJ-90959de1e1d/2c0689f0-ed5d-43c8-aa4c-9afafd82396e.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-11 23:50:34'),(742,'MEDIA-9299595616',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fa9d65053-7216-4157-81ad-3e0ce6203217.webp','',NULL,NULL,NULL,NULL,NULL,14,'2025-11-11-18-50-32-842--tcrmnu9ii9uivrpu2c7z_webp.webp','prod/PROJ-90959de1e1d/a9d65053-7216-4157-81ad-3e0ce6203217.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-11 23:50:34'),(743,'MEDIA-4966922788',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F6903d2c1-9828-4b2b-acbd-2bac16d06171.webp','',NULL,NULL,NULL,NULL,NULL,15,'2025-11-11-18-50-32-842--umaqojubqbflujijvioa_webp.webp','prod/PROJ-90959de1e1d/6903d2c1-9828-4b2b-acbd-2bac16d06171.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-11 23:50:34'),(744,'MEDIA-7371759684',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F4234af70-96e0-445b-a127-5520b80b5d75.webp','',NULL,NULL,NULL,NULL,NULL,16,'2025-11-11-18-50-32-842--wq9pivaaynb58jk7iupa_webp.webp','prod/PROJ-90959de1e1d/4234af70-96e0-445b-a127-5520b80b5d75.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-11 23:50:34'),(745,'MEDIA-2389102154',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fbf2f293c-24c3-409f-b7d2-624880cdc768.webp','',NULL,NULL,NULL,NULL,NULL,17,'2025-11-11-18-50-32-842--ylwqmai04bojyjkhqakf_webp.webp','prod/PROJ-90959de1e1d/bf2f293c-24c3-409f-b7d2-624880cdc768.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:34','2025-11-11 23:50:34'),(746,'MEDIA-8901569610',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F91108393-1623-4413-8b4d-3db3eb36593e.webp','',NULL,NULL,NULL,NULL,NULL,18,'2025-11-11-18-50-58-231--a0pntij35ukgbfvkst3q_webp.webp','prod/PROJ-90959de1e1d/91108393-1623-4413-8b4d-3db3eb36593e.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:59','2025-11-11 23:50:59'),(747,'MEDIA-6497647025',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F458acc0c-fd3b-417c-abbe-1f635d43a1f6.webp','',NULL,NULL,NULL,NULL,NULL,19,'2025-11-11-18-50-58-231--eyptkkmjjffo8vnun8wl_webp.webp','prod/PROJ-90959de1e1d/458acc0c-fd3b-417c-abbe-1f635d43a1f6.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:59','2025-11-11 23:50:59'),(748,'MEDIA-3319376154',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fcee60f50-81fb-4e72-8362-6ff44b2e09f5.webp','',NULL,NULL,NULL,NULL,NULL,20,'2025-11-11-18-50-58-231--fmn2qnyf81dx3okbtq4d_webp.webp','prod/PROJ-90959de1e1d/cee60f50-81fb-4e72-8362-6ff44b2e09f5.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:59','2025-11-11 23:50:59'),(749,'MEDIA-0360391895',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F42b527e0-63bf-498c-a0c4-13811d2c3d99.webp','',NULL,NULL,NULL,NULL,NULL,21,'2025-11-11-18-50-58-231--ilxxzfqmho23qrff0obc_webp.webp','prod/PROJ-90959de1e1d/42b527e0-63bf-498c-a0c4-13811d2c3d99.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:59','2025-11-11 23:50:59'),(750,'MEDIA-4088598714',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F0d0f1a5c-9f0c-4365-bb6b-47c40d18b38d.webp','',NULL,NULL,NULL,NULL,NULL,22,'2025-11-11-18-50-58-231--wpmqoxrowqxyfphyefh0_webp.webp','prod/PROJ-90959de1e1d/0d0f1a5c-9f0c-4365-bb6b-47c40d18b38d.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:59','2025-11-11 23:50:59'),(751,'MEDIA-7352061585',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F51367de4-b5aa-4403-9e17-6a67a793d3ed.webp','',NULL,NULL,NULL,NULL,NULL,23,'2025-11-11-18-50-58-231--zjq2u1trrrnkit2hai3w_webp.webp','prod/PROJ-90959de1e1d/51367de4-b5aa-4403-9e17-6a67a793d3ed.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:50:59','2025-11-11 23:50:59'),(752,'MEDIA-0995568397',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Ff59cf54e-6b59-437f-bb02-70fac105b20d.webp','',NULL,NULL,NULL,NULL,NULL,24,'2025-11-11-18-51-17-266--ao9s5f10cuk2rbpnerua_webp.webp','prod/PROJ-90959de1e1d/f59cf54e-6b59-437f-bb02-70fac105b20d.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-11 23:51:20'),(753,'MEDIA-7602481629',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Feaf58992-3d54-4c3a-8258-a00236dca221.webp','',NULL,NULL,NULL,NULL,NULL,25,'2025-11-11-18-51-17-266--ftcl0iomsmvveo7el42o_webp.webp','prod/PROJ-90959de1e1d/eaf58992-3d54-4c3a-8258-a00236dca221.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-11 23:51:20'),(754,'MEDIA-7547150141',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F2afb98a2-1391-4163-b90a-12ebcac49513.webp','',NULL,NULL,NULL,NULL,NULL,26,'2025-11-11-18-51-17-266--hnjyjxxkjvhncbefx8gv_webp.webp','prod/PROJ-90959de1e1d/2afb98a2-1391-4163-b90a-12ebcac49513.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-11 23:51:20'),(755,'MEDIA-1105641631',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F5e8fc2c3-4242-4a13-a430-034f8de61c21.webp','',NULL,NULL,NULL,NULL,NULL,27,'2025-11-11-18-51-17-266--pl9ksg3claaugiyyqsn0_webp.webp','prod/PROJ-90959de1e1d/5e8fc2c3-4242-4a13-a430-034f8de61c21.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-11 23:51:20'),(756,'MEDIA-5735775865',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F5a4219ff-005f-469c-a069-3e9fb328c480.webp','',NULL,NULL,NULL,NULL,NULL,28,'2025-11-11-18-51-17-266--s5mxdu4xwx3r7egeaagh_webp.webp','prod/PROJ-90959de1e1d/5a4219ff-005f-469c-a069-3e9fb328c480.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-11 23:51:20'),(757,'MEDIA-5972975382',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fd85f0080-78ff-41a4-8cb8-ffb32b0f6781.webp','',NULL,NULL,NULL,NULL,NULL,29,'2025-11-11-18-51-17-266--t3ruymdm3hq5iwniwpas_webp.webp','prod/PROJ-90959de1e1d/d85f0080-78ff-41a4-8cb8-ffb32b0f6781.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-11 23:51:20'),(758,'MEDIA-5036328663',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fe70e7182-959e-48b0-bf10-7c9a5aa0acf2.webp','',NULL,NULL,NULL,NULL,NULL,30,'2025-11-11-18-51-17-266--tkhjlryc2klruypjsyat_webp.webp','prod/PROJ-90959de1e1d/e70e7182-959e-48b0-bf10-7c9a5aa0acf2.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-11 23:51:20'),(759,'MEDIA-2849564603',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F6be23be6-8b30-42ca-b4b9-475e0eeb1b95.webp','',NULL,NULL,NULL,NULL,NULL,31,'2025-11-11-18-51-17-266--tl4pbzmxwjbhzzg5xy0n_webp.webp','prod/PROJ-90959de1e1d/6be23be6-8b30-42ca-b4b9-475e0eeb1b95.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-11 23:51:20'),(760,'MEDIA-6585884698',25,NULL,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2Fa512cb7b-f340-4740-8c64-35321560b256.webp','',NULL,NULL,NULL,NULL,NULL,32,'2025-11-11-18-51-17-266--z1wpzuuhuvej7l9yvivh_webp.webp','prod/PROJ-90959de1e1d/a512cb7b-f340-4740-8c64-35321560b256.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-11 23:51:20','2025-11-11 23:51:20'),(761,'MEDIA-8933929142',25,438,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F20119955-c59f-4a15-9f33-3ac3cbcbecfe.webp','',NULL,NULL,NULL,NULL,NULL,0,'2025-11-11-22-29-44-536--logo_png.png','prod/PROJ-90959de1e1d/20119955-c59f-4a15-9f33-3ac3cbcbecfe.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-12 03:29:45','2025-11-12 06:56:59'),(763,'MEDIA-1130735691',25,438,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F85223ee8-409d-47d8-a0cd-4b071edebf87.webp','',NULL,NULL,NULL,NULL,NULL,2,'2025-11-11-22-33-48-607--logo_light3_png.png','prod/PROJ-90959de1e1d/85223ee8-409d-47d8-a0cd-4b071edebf87.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-12 03:33:49','2025-11-12 10:39:18'),(769,'MEDIA-4489828454',25,438,'','image','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F7bbe59f8-f78d-4a9c-91e9-4468d38dcb0e.webp','',NULL,NULL,NULL,NULL,NULL,1,'2025-11-11-22-41-26-569--logo_light2_png.png','prod/PROJ-90959de1e1d/7bbe59f8-f78d-4a9c-91e9-4468d38dcb0e.webp','dev-cms-project-media','webp','image/webp',1,'2025-11-12 03:41:26','2025-11-12 10:39:18');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_folders`
--

DROP TABLE IF EXISTS `media_folders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_folders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `folder_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `parent_folder_id` bigint DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `ordinal` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `folder_id` (`folder_id`),
  KEY `project_idx` (`project_idx`),
  KEY `parent_folder_id` (`parent_folder_id`),
  CONSTRAINT `media_folders_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `media_folders_ibfk_2` FOREIGN KEY (`parent_folder_id`) REFERENCES `media_folders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=441 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_folders`
--

LOCK TABLES `media_folders` WRITE;
/*!40000 ALTER TABLE `media_folders` DISABLE KEYS */;
INSERT INTO `media_folders` VALUES (438,'F-1898140772',25,NULL,'Brand',0,'2025-11-12 03:34:15','2025-11-12 03:34:25'),(440,'F-8495246956',25,438,'iihioh',0,'2025-11-12 19:56:08','2025-11-12 19:56:08');
/*!40000 ALTER TABLE `media_folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_link`
--

DROP TABLE IF EXISTS `media_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_link` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `entity_type` enum('product','page','module','job') COLLATE utf8mb4_general_ci NOT NULL,
  `entity_id` bigint NOT NULL,
  `media_id` bigint NOT NULL,
  `ordinal` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `entity_type` (`entity_type`,`entity_id`,`media_id`),
  KEY `media_id` (`media_id`),
  CONSTRAINT `media_link_ibfk_1` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=341 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_link`
--

LOCK TABLES `media_link` WRITE;
/*!40000 ALTER TABLE `media_link` DISABLE KEYS */;
INSERT INTO `media_link` VALUES (270,'product',373,733,0),(271,'product',373,731,1),(272,'product',373,732,2),(273,'product',373,735,3),(274,'product',373,728,4),(275,'product',373,730,5),(276,'product',373,729,6),(277,'product',373,734,7),(278,'product',372,742,0),(279,'product',372,739,1),(280,'product',372,740,2),(281,'product',372,738,3),(282,'product',372,736,4),(283,'product',372,737,5),(284,'product',372,741,7),(285,'product',372,744,8),(286,'product',372,745,9),(287,'product',372,743,6),(288,'product',390,750,0),(289,'product',390,747,1),(290,'product',390,749,2),(291,'product',390,746,3),(292,'product',390,748,4),(293,'product',390,751,5),(294,'product',368,760,0),(295,'product',368,754,1),(296,'product',368,755,2),(297,'product',368,756,3),(298,'product',368,753,4),(299,'product',368,757,5),(300,'product',368,752,6),(301,'product',368,758,7),(302,'product',368,759,8);
/*!40000 ALTER TABLE `media_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module_definitions`
--

DROP TABLE IF EXISTS `module_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `module_definitions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `identifier` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `config_schema` json DEFAULT (json_array()),
  `parent_module_id` bigint DEFAULT NULL,
  `module_definition_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `module_definition_id` (`module_definition_id`),
  KEY `fk_modules_parent` (`parent_module_id`),
  CONSTRAINT `fk_modules_parent` FOREIGN KEY (`parent_module_id`) REFERENCES `module_definitions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `module_definitions_ibfk_1` FOREIGN KEY (`parent_module_id`) REFERENCES `module_definitions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module_definitions`
--

LOCK TABLES `module_definitions` WRITE;
/*!40000 ALTER TABLE `module_definitions` DISABLE KEYS */;
INSERT INTO `module_definitions` VALUES (74,'Dashboard','dashboard-module','Site dashboard display','[]',NULL,'3155639165'),(75,'Pages','pages-module','Pages Module','[]',NULL,'9613306093'),(76,'Media','media-module','Media Module','[]',NULL,'8599613279'),(77,'Global Media','global-media-module','Global Media Module','[]',76,'4158148424'),(78,'Customers','customers-module','Track customers','[\"1234\"]',NULL,'4991902592'),(80,'Employees','employees-module','Employee Management','[]',NULL,'2485067995'),(81,'Customer Products','customer-products-module','Customer based products','[]',78,'7449632508'),(82,'Tasks','tasks-module','Manage Employee Tasks','[]',80,'9792958861'),(97,'Wix Sync','customer-products-wix-sync-module','Sync products to Wix','[\"WIX_BACKEND_URL\", \"WIX_GENERATED_SECRET\"]',81,'MD-9948987248'),(98,'Google Sheets Export','customer-products-google-sheets-module','Export products to google sheet table','[\"sheetId\", \"sheetName\", \"serviceAccountJson\"]',81,'MD-4725318659'),(101,'Google','google-module','Google Modules','[]',NULL,'MD-1644714768'),(102,'Google Maps API','google-maps-api-module','Google Maps API','[\"GOOGLE_API_KEY\"]',101,'MD-9718951397');
/*!40000 ALTER TABLE `module_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_definitions`
--

DROP TABLE IF EXISTS `page_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `page_definitions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `page_definition_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `identifier` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `parent_page_definition_id` bigint DEFAULT NULL,
  `allowed_sections` json DEFAULT (json_array()),
  `config_schema` json DEFAULT (json_object()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `page_definition_id` (`page_definition_id`),
  KEY `fk_page_definitions_parent` (`parent_page_definition_id`),
  CONSTRAINT `fk_page_definitions_parent` FOREIGN KEY (`parent_page_definition_id`) REFERENCES `page_definitions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_definitions`
--

LOCK TABLES `page_definitions` WRITE;
/*!40000 ALTER TABLE `page_definitions` DISABLE KEYS */;
INSERT INTO `page_definitions` VALUES (1,'PD-4473478327','Page 1','page-1',NULL,'[]','{}'),(2,'PD-7661298906','Page 1 IN','page-1-in',1,'[\"Home\", \"Nav\"]','{}');
/*!40000 ALTER TABLE `page_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `customer_id` bigint DEFAULT NULL,
  `serial_number` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `highlight` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` text COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `note` text COLLATE utf8mb4_general_ci,
  `make` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `model` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `type` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `length` decimal(6,2) DEFAULT NULL,
  `width` decimal(6,2) DEFAULT NULL,
  `height` decimal(6,2) DEFAULT NULL,
  `ordinal` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`),
  UNIQUE KEY `unique_project_serial` (`project_idx`,`serial_number`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=408 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (363,'P-1472922937',25,270,'TSA8490NJC006',NULL,'Green Jacuzzi',NULL,'','Jacuzzi',NULL,NULL,84.00,90.00,0.00,0,'2025-11-04 21:28:01','2025-11-12 04:24:23'),(366,'P-3834929730',25,270,'TSA8787L2MX038',NULL,'Brown MAAX Spa',NULL,'','MAAX','',NULL,87.00,87.00,34.00,1,'2025-11-04 21:43:31','2025-11-06 01:00:57'),(368,'P-1586806747',25,NULL,'TSA7777N2SR045',NULL,'Small Gray Sunrise Hot Tub','','','Sunrise','',NULL,77.00,77.00,0.00,2,'2025-11-05 15:55:31','2025-11-12 20:05:49'),(369,'P-8047394352',25,267,'SCOTTJOHNSONSWIMSPA',NULL,'Scott Johnson Service Call','Scott Johnson Swim Spa ','',NULL,NULL,NULL,0.00,0.00,0.00,3,'2025-11-05 15:57:38','2025-11-05 16:15:57'),(372,'P-4956068717',25,NULL,'TSA8483L2JC080',NULL,'Jacuzzi White Marble Shell','FREE DELIVERY & INSTALLATION INCLUDED\n\nThis is an excellent condition Jacuzzi Hot Tub\n\n✅ Included:\n  - BRAND NEW folding leather cover \n    (You pick the color!)\n  - 90-day warranty \n  - Hot water delivery (if requested)\n  - Again, FREE DELIVERY & INSTALLATION \n\n➕ Additional Accessories:\n   - Spa care kit $200\n   - Entry steps $100\n   - Cover Lifter $150\n  \n🧪 Spa-Care Package ($200):\n   - Skimmer net\n   - Water test strips\n   - Oxidizing Shock\n   - Chlorine granulate \n   - PH Up \n   - PH Down \n   - Water clarifier \n   - Thermometer\n   - Kid-safe sealed bucket for chemicals\n   - Step-by-step tutorial \n\n📏 Dimensions:\n            83\"    x    91\"   x     38\" \n       (Length)x(Width)x(Height)\n\n⚡️ Electrical: 240v, 50A\n\n💲Discounts: As a small business, we’re able to offer discounted rates for customers who purchase BOTH a hot tub + an electrical installation through us! Message for more info!\n\n*** No holds. First come, first serve. ***','','Jacuzzi','J330',NULL,84.00,84.00,0.00,4,'2025-11-05 16:24:41','2025-11-12 02:53:01'),(373,'P-5297536816',25,272,'TSA7676N1CT053',NULL,'Small Dark Brown Catalina','FREE DELIVERY & INSTALLATION INCLUDED\n\nThis is an excellent condition Sunrise Odyssey Hot Tub. \n\n✅ Included:\n  - BRAND NEW folding leather cover \n    (You pick the color!)\n  - 90-day warranty \n  - Hot water delivery (if requested)\n  - Again, FREE DELIVERY & INSTALLATION \n\n➕ Additional Accessories:\n   - Spa care kit $200\n   - Entry steps $100\n   - Cover Lifter $150\n  \n🧪 Spa-Care Package ($200):\n   - Skimmer net\n   - Water test strips\n   - Oxidizing Shock\n   - Chlorine granulate \n   - PH Up \n   - PH Down \n   - Water clarifier \n   - Thermometer\n   - Kid-safe sealed bucket for chemicals\n   - Step-by-step tutorial \n\n📏 Dimensions:\n            77\"    x    77\"   x     38\" \n       (Length)x(Width)x(Height)\n\n⚡️ Electrical: 240v, 50A\n\n💲Discounts: As a small business, we’re able to offer discounted rates for customers who purchase BOTH a hot tub + an electrical installation through us! Message for more info!\n\n*** No holds. First come, first serve. ***','Matt is interested. No deposit collected yet. waiting to get pics of his electrical system before confirming prices','Catalina',NULL,NULL,76.00,76.00,0.00,5,'2025-11-05 16:28:41','2025-11-11 23:50:18'),(383,'P-9388566084',25,273,'TSA8491L2JC067',NULL,'Jacuzzi Silver Shell',NULL,'Barbra interested. Has not paid the deposit yet','Jacuzzi','J355',NULL,84.00,91.00,0.00,6,'2025-11-05 22:16:25','2025-11-05 22:21:16'),(390,'P-6756275021',25,275,'TSA8484L1JC078',NULL,'Light Brown Jacuzzi J335','FREE DELIVERY & INSTALLATION INCLUDED\n\nThis is an excellent condition 50th Anniversary Edition Jacuzzi Hot Tub!\n\n✅ Included:\n  - BRAND NEW folding leather cover \n    (You pick the color!)\n  - 90-day warranty \n  - Hot water delivery (if requested)\n  - Again, FREE DELIVERY & INSTALLATION \n\n➕ Additional Accessories:\n   - Spa care kit $200\n   - Entry steps $100\n   - Cover Lifter $150\n  \n🧪 Spa-Care Package ($200):\n   - Skimmer net\n   - Water test strips\n   - Oxidizing Shock\n   - Chlorine granulate \n   - PH Up \n   - PH Down \n   - Water clarifier \n   - Thermometer\n   - Kid-safe sealed bucket for chemicals\n   - Step-by-step tutorial \n\n📏 Dimensions:\n            84\"    x    84\"   x     38\" \n       (Length)x(Width)x(Height)\n\n⚡️ Electrical: 240v, 50A\n\n💲Discounts: As a small business, we’re able to offer discounted rates for customers who purchase BOTH a hot tub + an electrical installation through us! Message for more info!\n\n*** No holds. First come, first serve. ***','Matt Lance interested in picking up tub from shop with no warranty $2500. no deposit yet. inform him if others are interested','Jacuzzi','J335',NULL,84.00,84.00,0.00,7,'2025-11-07 15:35:29','2025-11-12 03:49:58'),(399,'P-0168938282',124,NULL,'4EWFASDFSDF',NULL,'',NULL,'',NULL,NULL,NULL,0.00,0.00,0.00,0,'2025-11-12 03:18:13','2025-11-12 03:18:13');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_integrations`
--

DROP TABLE IF EXISTS `project_integrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_integrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `integration_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `module_id` bigint NOT NULL,
  `integration_key` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `integration_value` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `integration_id` (`integration_id`),
  UNIQUE KEY `uq_project_module` (`project_idx`,`module_id`,`integration_key`),
  KEY `module_id` (`module_id`),
  CONSTRAINT `project_integrations_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `project_integrations_ibfk_2` FOREIGN KEY (`module_id`) REFERENCES `project_modules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_integrations`
--

LOCK TABLES `project_integrations` WRITE;
/*!40000 ALTER TABLE `project_integrations` DISABLE KEYS */;
INSERT INTO `project_integrations` VALUES (16,'I-1984375322',25,21,'sheetName','U2FsdGVkX19Eo/UqMDJJKL59ktA6eJBsaBFUrdWPiKQ=','2025-10-29 20:58:40','2025-10-29 20:58:40'),(17,'I-7120018554',25,21,'sheetId','U2FsdGVkX19pT3aJyyzzWZnv/zu8E6THNbgGu7U2PhvkXei/tZMTO8Zw4a6qv78WuME24oD4LFYFC3cIsk+7uw==','2025-10-29 20:58:50','2025-10-29 20:58:50'),(18,'I-0425702969',25,21,'serviceAccountJson','U2FsdGVkX1/cZ5JLVdO2NtCuwsDHYuIdtQqBGWtjJOCUL3MxA81dXv16rhFNvFA/gHlZZJ3dp8oOsjDAyzuY6bHU414bNf9tXk1dvg7+k3axP8BSrpFZtJ5uqoc5eqPvLV2M5QzBH3VG7TvYMHtXqvZBZDHazC89vv+erWviE0b7dpXk5/XvsgYdDOJB3oC62C1JPYeNeNTfRUWUzT1K5mJJA76ISZs6smIWnugjgXOp90p+LrrGHSrzqVWQQg6kt6EiMcxnJBOwHvo/XK0A1BNA7WZc2TRnvqKCktHlBSRsYbXsMZjeSWJSkNsItwXjvsCnizLzv8VKaFYN3OT/1XBG4WQ/PNiBZf/WrY1i2JAgavF0vY7N73YYewHSeGPMzEyjdIbLcL0mTnEDYpkrHv7/5wjvSxtz99Ovn7Oi6mQtpLuxN/Q07Q9X5khbuad1WJ/dlXldYFwTDNWvvN1TXTKOT82haVsfacazBvCVLJo01kYvAzD6FH83SzClCIk2xbcXyGDSK9T+hmzsKFdXKTBitVip7RHSVPOpRIpp7Y32K+BhO654ZMxxnlRAAifmtgE4By3xg+jam5chyoQPmxByShlHaha1Z56tZ6SzWpVvP516FXsmDhquXiy/CvkEtpzz1wnmXyJFNP3qfXS83M6hY4QFOZI6C5o1zpbEFeRsrfj6gpHXorHvyfrxfWwTiDRH/bgN42uOokK73K0wfYk3lsqCnpv2dgV58k/BIC+gqah/ZE7oFuYSdCXkpB3TReCzay8rGUIjtIs1iG9gKtM+2WPst1Iz+HRldUwpNqbYJN7A6X5own1wAonakjb6E/ihiku3q3ZI7s23HSdv7J2KySXz4zumVIXI9mRiIeaHhjeA8eETxgl79FHEPy2kxeDBu21v9syibQoEgdGdHvsjq/GhW1oKVEfg8S3fOFz2/oP+31QsCsDjwS3Ifv8MKAhn2JDaH/+QEE3CGUjTvmaKUIM+QwB+clLr+4EhxAVGCKGMR+oPYEeo/XUCjDyi7BDRHersYPWmqno6QxVOGpo2nJbQ0WMZL+3aw4BdmSgjF6WqWgTaDOLWBVsIcOzQUMBcRdiRL4xQgMYp2X95T5w0Tv33RqZAUDl58d1E+M9BBs9VU/b/BtfsscFOBfVFCv/FsNeiuj2FdV636I7k6Emy+FsdYuzxcjt9FL4WAmi/HcIpopitwYirSGw9U1pjSeTdm0gv/8W3gFOkAtjOQcBTmrZgARhLohBowOyNo36GFd380j329l/0OvHWvwqkmyirJWuaH8yGp+fFY6AZLVXjPZpqcdLqMxBCqcfNsdC9Pt0wSTzEkfdtLz9xyVHL9xGkGvVz8FDV4uXoQyz34hi/yDEVoNqoooarFKQIVd3hUHRVOWL4CH7X//q8HJ5jEhu0RDraFSbyWmn8XZio7G2M2yQTad7q2FTKEYvnk0VQzVbTDkm2i1PnaZcot/oQ51afX9G7Mg4ncO1QMkBgdSxax2sfejgw+2/jV18yA66Up6vn8Xgfo3SD0GyWFEpG+qc9cR2o7SKHmTdljhtNnSd0I0NRm+SQP351WT0deOvjVhExvumKHTntytGeTE0oJXuBnEQ1ihnRFRlLglfHUMLluMkFD5OELYSWmJftiN01WlBhu5JJkYmdlPiJptpaJaOdvspTB9OmZ8knHphsPtQqBHkm8TMGaqpnxXSxKCvN+IoG2Oha6nw2oGqq4Ja63fT/VgfAwJk6qNSvwRXi5XbrCPhBMSE7igGJsTzLht1+07iBXBn/6d6ys5wbWucFjQUIBHQ6JeuL09fVWLYDrwNNnBbJBggb37yziof/7JBsG5jurqi2pxA5E6WdRp84Hcg1rOOxza21ZDgUZ5gJueSYy8NOMsmVLQf3bIUlNh+fmIIzxIYHR4K87+33PBn680Czq+MOX92zuUgbgeJY6TjDGQNU6igUMwJg2Vt8TBCCnXSXwOm86RMp4N3Z4GTMkp55MH03H+XaVLZcduGDTW9H5UeMOOGPJfDeExr8y7LeUlZ3kCD3fWfgZ/JPz5M1Y+HtTTfMZz1+W4Ddgqh90oCFPBOAgCSPXUCg5dMqefetLiQQfinFaguWCNXSNIauKlhxsXEg6pLwExR/FlgwdoGSex4ONx5p+JQFmyhGxHhPmdKx2sPvunoislpU877ifAwQObd2alNRO3o/v08TE/AblDlOWtgq/XsqjmcOreRMIgk2xCLKQZ+DfncPpcQYConXtvAv++3u4zYJymD+06SlA/0YyRODI+xQWlSEO0RkwDzCWHPBoRi4mZ/BPU55tKS/e0dH1xhm03HGY8LwP80ca0ikUv5cbxKIy8EUIZQ1MTjKKp9a4QRzD4NkVVhVX3YJHxs6W4EfGSYFvb8YSvu0Y88Vs7rXgv5e9/TOW1XLmMHIcX8T08UJofYmWK+vsbJTvJ+P9+PezH0tnkwQ/Q9bdPmzXbw5QOjDTIvvRbkHp/prKYDwDfMdT6VDR/E+DJhjFJiJMjCnAx/XdfAXAhBvXn28eT3SLnXqqazrQOUhc09Xqx1Ia+h2UHen4bgekpYnNmLzmG4fSA6hPBVQCdTQYyP/nEZhNiL4p0liB60PT+OUhgDWP4CRXNMjJYL6Y66dkRsfHercUGyjRsKfxEpLMLMhoyWnW3DKPo+sjI4fvV4aNMSWGLuITeBnStMyg6DCVnVOQhWpX/aJ4YQkNEEBwz9MSRLLnqOGvnEmKF/ItqNBuAN1wwXnuNrrzYTPF18uTmEgVE1jtVRPkHlCKh6Z1MFt9lqG4+o1Bp7zIaH1OrKiiwKfKIbRmfiUcilIq1WFzRliBnmHlXGUxkP6SxTQnj06/TZtxVv6IsGmdJqcXb1GsY/m9UKdLXvFK1KTWoxN333+GywDJmvwFh1wapZ0qg9rBCOKkEzTUnXlrsaSsk2j84Mm3fiwqK6dF/0DAHn4LKD+LDv+Ndoy3+/xiCxiHcxgbK2nxZ9g0qWmTkq42u/zd/0TGmQYPrkqpWXcAx67JIobmgAY+8Y14zPqqwy2ZcgvOcI2vFlOTqB+Ru/ktHawVWX1LilFLRoDLT/KGxKomhuUq8lzlirdpvG1SKwqZ0keMAJdRJ3PC4Djb5I9UEaoxMhRHXl6MrSgpHw5ALKpLwlzEbj/Em6EETcAL1JqiFcebSlMo18o4q0Y3N4TBVBX+XXr1cvkb8x9kCSD','2025-10-29 20:59:54','2025-10-29 20:59:54'),(19,'I-5014159387',25,22,'WIX_BACKEND_URL','U2FsdGVkX19DYnF8MLy2mN1vDwlmG4uFtcKGeyvOTAC4l1Y+WPUYbbO7xAg+O/8aZgq5x2EXjQf9zEh3zZidbhYytD2Deqv9bIGi010iY+s=','2025-10-29 21:00:10','2025-10-29 21:00:10'),(20,'I-2947685782',25,22,'WIX_GENERATED_SECRET','U2FsdGVkX1+xub1rI3IRh704hskJMqad89GyTTVIM0P5r4ZaKyYRpzvt2TwnVMvAdjhAHz0KjRok7GBufJC4YdAMUcIgDpJQ85TIu4MhkYOoy/59szpqKhqA1bIzxnVg','2025-10-29 21:00:22','2025-10-29 21:00:22'),(21,'I-2104746727',25,24,'GOOGLE_API_KEY','U2FsdGVkX18LCOMQeudBSJa+dkDr0eC+slWNg6L2cU2ff45kG+Y0VIssYIN/yAZIUpoWnoOIS6M70SD6owroLA==','2025-10-31 02:18:30','2025-10-31 02:18:30');
/*!40000 ALTER TABLE `project_integrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_modules`
--

DROP TABLE IF EXISTS `project_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_modules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `module_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `module_definition_id` bigint NOT NULL,
  `project_idx` bigint NOT NULL,
  `settings` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `module_id` (`module_id`),
  UNIQUE KEY `project_idx` (`project_idx`,`module_definition_id`),
  KEY `module_definition_id` (`module_definition_id`),
  CONSTRAINT `project_modules_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `project_modules_ibfk_2` FOREIGN KEY (`module_definition_id`) REFERENCES `module_definitions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_modules`
--

LOCK TABLES `project_modules` WRITE;
/*!40000 ALTER TABLE `project_modules` DISABLE KEYS */;
INSERT INTO `project_modules` VALUES (3,'M-1379961207',75,25,'[]'),(7,'M-6701354551',80,25,'[]'),(11,'M-0263543395',81,25,'[]'),(13,'M-6745899459',76,25,'[]'),(14,'M-2073371590',77,25,'[]'),(20,'M-5478898918',78,25,'[]'),(21,'M-4123526402',98,25,'[]'),(22,'M-6804606366',97,25,'[]'),(23,'M-4954926823',101,25,'[]'),(24,'M-7481788209',102,25,'[]'),(25,'M-0628380453',74,25,'[]'),(26,'M-3334930878',74,124,'[]'),(27,'M-0673905819',75,124,'[]'),(28,'M-7252935464',76,124,'[]'),(29,'M-9051324835',78,124,'[]'),(30,'M-9165606157',80,124,'[]'),(31,'M-7567759094',101,124,'[]'),(32,'M-7110248237',81,124,'[]'),(33,'M-3556027771',77,124,'[]'),(34,'M-5506903374',102,124,'[]');
/*!40000 ALTER TABLE `project_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_pages`
--

DROP TABLE IF EXISTS `project_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_pages` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `page_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `parent_page_id` bigint DEFAULT NULL,
  `definition_id` bigint DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `ordinal` int NOT NULL DEFAULT '0',
  `seo_title` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8mb4_general_ci,
  `seo_keywords` json DEFAULT (json_array()),
  `template` varchar(100) COLLATE utf8mb4_general_ci DEFAULT 'default',
  `published` tinyint(1) DEFAULT '1',
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `page_id` (`page_id`),
  UNIQUE KEY `uq_project_slug` (`project_idx`,`slug`),
  KEY `parent_page_id` (`parent_page_id`),
  KEY `definition_id` (`definition_id`),
  CONSTRAINT `project_pages_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `project_pages_ibfk_2` FOREIGN KEY (`parent_page_id`) REFERENCES `project_pages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `project_pages_ibfk_3` FOREIGN KEY (`definition_id`) REFERENCES `page_definitions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_pages`
--

LOCK TABLES `project_pages` WRITE;
/*!40000 ALTER TABLE `project_pages` DISABLE KEYS */;
INSERT INTO `project_pages` VALUES (18,25,'P-2623065033',NULL,1,'Home','/',0,NULL,NULL,'[]',NULL,0,NULL,'2025-10-20 05:52:56',NULL),(37,25,'P-3369613688',NULL,1,'Services','/services',1,NULL,NULL,'[]',NULL,0,NULL,'2025-10-29 05:27:32','2025-10-29 09:41:05');
/*!40000 ALTER TABLE `project_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_sections`
--

DROP TABLE IF EXISTS `project_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_sections` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `section_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `parent_section_id` bigint DEFAULT NULL,
  `project_page_id` bigint NOT NULL,
  `definition_id` bigint DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `config` json DEFAULT (json_object()),
  `ordinal` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_id` (`section_id`),
  KEY `project_idx` (`project_idx`),
  KEY `project_page_id` (`project_page_id`),
  KEY `definition_id` (`definition_id`),
  CONSTRAINT `project_sections_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `project_sections_ibfk_2` FOREIGN KEY (`project_page_id`) REFERENCES `project_pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `project_sections_ibfk_3` FOREIGN KEY (`definition_id`) REFERENCES `section_definitions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_sections`
--

LOCK TABLES `project_sections` WRITE;
/*!40000 ALTER TABLE `project_sections` DISABLE KEYS */;
INSERT INTO `project_sections` VALUES (1,25,'PS-3886425456',NULL,18,1,'1','{\"text1\": \"12345679\"}',0,'2025-10-20 15:32:55','2025-10-30 04:20:05'),(3,25,'PS-2708413707',NULL,18,1,'2','{\"text1\": \"1252\"}',1,'2025-10-20 15:38:35','2025-10-30 04:20:05');
/*!40000 ALTER TABLE `project_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_themes`
--

DROP TABLE IF EXISTS `project_themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_themes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_id` bigint NOT NULL,
  `theme_id` bigint NOT NULL,
  `applied_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_id` (`project_id`),
  KEY `theme_id` (`theme_id`),
  CONSTRAINT `project_themes_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `project_themes_ibfk_2` FOREIGN KEY (`theme_id`) REFERENCES `themes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_themes`
--

LOCK TABLES `project_themes` WRITE;
/*!40000 ALTER TABLE `project_themes` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_users`
--

DROP TABLE IF EXISTS `project_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `clearance` decimal(4,2) NOT NULL DEFAULT '1.00',
  `invited_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_idx` (`project_idx`,`email`),
  CONSTRAINT `project_users_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_users`
--

LOCK TABLES `project_users` WRITE;
/*!40000 ALTER TABLE `project_users` DISABLE KEYS */;
INSERT INTO `project_users` VALUES (16,'opendreamstudios@gmail.com',25,9.00,'2025-08-27 10:54:27'),(67,'tannyspaacquisitions@gmail.com',25,8.00,'2025-11-03 22:25:49'),(70,'opendreamstudios@gmail.com',124,9.00,'2025-11-12 03:10:26');
/*!40000 ALTER TABLE `project_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `short_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `domain` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `backend_domain` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `brand` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `logo` text COLLATE utf8mb4_general_ci,
  `logo_light` text COLLATE utf8mb4_general_ci,
  `logo_dark` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (25,'PROJ-90959de1e1d','TSA Backend','TSA','tannyspaacquisitions.com','https://tannyspaacquisitions.shop','Tanny Spa Acquisition','https://dev-cms-project-media.s3.us-east-1.amazonaws.com/prod%2FPROJ-90959de1e1d%2F20119955-c59f-4a15-9f33-3ac3cbcbecfe.webp',NULL,NULL,'2025-08-27 10:54:27'),(124,'PROJ-6182098829','Project 2','Project 2','project 2',NULL,'TEST',NULL,NULL,NULL,'2025-11-12 03:10:26');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `section_definitions`
--

DROP TABLE IF EXISTS `section_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `section_definitions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `section_definition_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `identifier` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `parent_section_definition_id` bigint DEFAULT NULL,
  `allowed_elements` json DEFAULT (json_array()),
  `config_schema` json DEFAULT (json_object()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_definition_id` (`section_definition_id`),
  KEY `fk_section_definitions_parent` (`parent_section_definition_id`),
  CONSTRAINT `fk_section_definitions_parent` FOREIGN KEY (`parent_section_definition_id`) REFERENCES `section_definitions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section_definitions`
--

LOCK TABLES `section_definitions` WRITE;
/*!40000 ALTER TABLE `section_definitions` DISABLE KEYS */;
INSERT INTO `section_definitions` VALUES (1,'PSD-4713237590','Section 1','section-1',NULL,'[]','{\"fields\": [{\"key\": \"text1\", \"help\": \"\", \"type\": \"string\", \"label\": \"\", \"required\": true}]}'),(2,'PSD-2815477625','Section 1 IN','section-1',1,'[]','{\"fields\": []}');
/*!40000 ALTER TABLE `section_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `task_id` char(16) COLLATE utf8mb4_general_ci NOT NULL,
  `project_idx` bigint NOT NULL,
  `job_id` bigint DEFAULT NULL,
  `status` enum('waiting_work','waiting_parts','waiting_customer','complete','cancelled') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'waiting_work',
  `priority` enum('low','medium','high','urgent') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'medium',
  `scheduled_start_date` datetime DEFAULT NULL,
  `completed_date` datetime DEFAULT NULL,
  `task` text COLLATE utf8mb4_general_ci,
  `description` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_id` (`task_id`),
  KEY `project_idx` (`project_idx`),
  KEY `job_id` (`job_id`),
  CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tasks_ibfk_2` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3586 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` VALUES (1,'T-8871644771',25,NULL,'waiting_customer','low','2025-11-01 16:00:00',NULL,'blurred','blurred description','2025-09-20 00:23:22','2025-09-20 03:18:19'),(21,'T-6645762078',25,NULL,'waiting_work','medium','2025-09-20 02:54:58',NULL,NULL,NULL,'2025-09-20 02:54:58','2025-09-20 02:54:58'),(22,'T-6287357386',25,NULL,'waiting_work','medium','2025-09-20 02:56:00',NULL,NULL,NULL,'2025-09-20 02:56:00','2025-09-20 02:56:00'),(25,'T-7459029606',25,NULL,'complete','medium','2025-09-26 16:00:00',NULL,NULL,NULL,'2025-09-20 03:20:04','2025-09-20 03:20:25'),(29,'T-8584079177',25,NULL,'cancelled','medium','2025-09-20 03:27:33',NULL,'fjf jadsklfjas dfjasdf','asdasdf klasdjfk ajskdfasdasfd','2025-09-20 03:27:33','2025-09-20 03:57:49'),(48,'T-2033398800',25,NULL,'waiting_parts','urgent','2025-09-24 16:00:00',NULL,'testtt ','test 99','2025-09-20 04:02:28','2025-09-20 14:22:35'),(3369,'T-8038312328',25,NULL,'waiting_parts','medium','2025-09-19 21:50:10',NULL,NULL,NULL,'2025-09-20 21:50:10','2025-09-20 23:11:16'),(3395,'T-2992522073',25,10699,'complete','urgent','2025-09-17 16:35:13',NULL,'task for this day 2221',NULL,'2025-09-21 04:35:13','2025-09-22 22:44:45'),(3405,'T-0661674860',25,11292,'complete','medium','2025-09-21 14:16:34',NULL,NULL,'jkljkl','2025-09-21 22:16:34','2025-09-21 22:17:10'),(3412,'T-8294336944',25,11310,'complete','medium','2025-09-21 13:42:54',NULL,NULL,NULL,'2025-09-22 05:42:55','2025-09-22 18:54:47'),(3418,'T-0049794234',25,10699,'complete','medium','2025-09-21 12:25:58',NULL,'Get the water out',NULL,'2025-09-22 16:25:58','2025-09-22 22:07:09'),(3419,'T-1965096348',25,10699,'complete','medium','2025-09-21 20:26:00',NULL,'Run 100 miles',NULL,'2025-09-22 16:26:00','2025-09-22 19:11:47'),(3456,'T-1665666167',25,11378,'cancelled','medium','2025-09-22 10:44:47',NULL,NULL,'1234','2025-09-22 22:44:47','2025-09-22 23:15:31'),(3461,'T-7340791523',25,NULL,'waiting_work','high','2025-09-22 12:58:41',NULL,'Replace Spa Pack',NULL,'2025-09-23 00:58:41','2025-09-23 01:00:18'),(3464,'T-3248109094',25,NULL,'waiting_work','medium','2025-09-22 12:59:06',NULL,'Replace Left Side Panel',NULL,'2025-09-23 00:59:06','2025-09-23 01:00:18'),(3466,'T-7446057811',25,NULL,'waiting_work','medium','2025-09-22 12:59:29',NULL,'Scrub inside and power wash','Deep clean inside','2025-09-23 00:59:29','2025-09-23 01:00:18'),(3476,'T-3492602909',25,NULL,'cancelled','medium','2025-09-22 13:00:33',NULL,'Replace Broken Wiring',NULL,'2025-09-23 01:00:33','2025-09-23 03:03:15'),(3481,'T-4040632594',25,NULL,'cancelled','medium','2025-09-22 13:01:07',NULL,'Fix pump #3',NULL,'2025-09-23 01:01:08','2025-09-23 03:03:16'),(3484,'T-0846307826',25,NULL,'cancelled','medium','2025-09-22 13:01:33',NULL,'Deep Clean',NULL,'2025-09-23 01:01:33','2025-09-23 03:03:18'),(3489,'T-5987979072',25,11389,'complete','high','2025-09-22 13:02:20',NULL,'Retake Photos',NULL,'2025-09-23 01:02:20','2025-09-23 02:40:33'),(3491,'T-6942418300',25,11389,'complete','medium','2025-09-22 01:02:32',NULL,'125','Lower listing222','2025-09-23 01:02:32','2025-10-22 05:55:02'),(3495,'T-1510107546',25,11394,'waiting_work','medium','2025-09-22 17:02:50',NULL,'Routine Maintenance',NULL,'2025-09-23 01:02:50','2025-09-23 01:02:58'),(3498,'T-1067146813',25,11397,'waiting_work','medium','2025-09-22 21:03:13',NULL,NULL,NULL,'2025-09-23 01:03:13','2025-09-23 01:03:13'),(3499,'T-7232511547',25,NULL,'complete','urgent','2025-09-22 09:48:33',NULL,'Replace jet number 6','f','2025-09-23 01:48:33','2025-10-22 02:54:20'),(3508,'T-9970477989',25,NULL,'complete','high','2025-09-24 12:00:00',NULL,'3332','23234','2025-09-23 17:13:48','2025-09-23 17:15:41'),(3513,'T-4636108331',25,11449,'waiting_work','medium','2025-09-23 01:48:00',NULL,NULL,'jjjnjljkl','2025-09-23 17:48:00','2025-09-24 06:59:40'),(3518,'T-7536541938',25,11449,'waiting_customer','medium','2025-09-23 10:01:18',NULL,NULL,NULL,'2025-09-23 18:01:18','2025-09-25 20:16:26'),(3519,'T-5848530814',25,11449,'waiting_work','medium','2025-09-23 14:01:19',NULL,NULL,NULL,'2025-09-23 18:01:19','2025-09-23 18:01:19'),(3534,'T-8238115249',25,11389,'complete','medium','2025-10-21 13:54:34',NULL,'3','31234','2025-10-22 05:54:34','2025-10-22 05:55:25'),(3535,'T-4550256466',25,11389,'waiting_work','medium','2025-10-22 01:54:36',NULL,NULL,NULL,'2025-10-22 05:54:36','2025-10-22 05:54:36'),(3536,'T-4228873083',25,11389,'waiting_work','medium','2025-10-22 01:54:37',NULL,NULL,NULL,'2025-10-22 05:54:37','2025-10-22 05:54:37'),(3537,'T-1657710988',25,11389,'waiting_work','medium','2025-10-22 01:54:38',NULL,NULL,NULL,'2025-10-22 05:54:38','2025-10-22 05:54:38'),(3547,'T-7565486808',25,11788,'waiting_work','medium','2025-10-22 14:43:03',NULL,NULL,NULL,'2025-10-22 18:43:03','2025-10-22 18:43:03'),(3548,'T-1997773484',25,11867,'waiting_customer','high','2025-10-30 12:00:00',NULL,NULL,NULL,'2025-10-26 10:35:40','2025-10-26 10:35:57'),(3552,'T-2046810699',25,11864,'complete','high','2025-10-26 03:15:02',NULL,'Deep Clean','kk','2025-10-26 11:15:02','2025-10-26 11:15:18'),(3561,'T-0304603638',25,11892,'complete','urgent','2025-10-31 08:21:44',NULL,'plumbing','fix leaks','2025-10-31 20:21:44','2025-11-03 22:36:16'),(3569,'T-5237105127',25,11892,'waiting_work','medium','2025-11-03 17:34:55',NULL,NULL,NULL,'2025-11-03 22:34:56','2025-11-03 22:34:56'),(3576,'T-4713919051',25,11904,'waiting_work','medium','2025-11-03 18:41:42',NULL,NULL,NULL,'2025-11-03 23:41:42','2025-11-03 23:41:42'),(3577,'T-6173575164',25,NULL,'waiting_work','medium','2025-11-04 11:41:25',NULL,NULL,'Fix leak','2025-11-04 21:41:25','2025-11-04 21:42:49'),(3579,'T-5810103042',25,NULL,'waiting_work','medium','2025-11-04 11:42:12',NULL,NULL,'Fix FLO code','2025-11-04 21:42:13','2025-11-04 21:42:49'),(3583,'T-7651541395',25,12004,'waiting_work','medium','2025-11-11 22:08:26',NULL,NULL,NULL,'2025-11-12 03:08:27','2025-11-12 03:08:27'),(3585,'T-0433325488',25,11986,'waiting_work','medium','2025-11-12 14:56:57',NULL,NULL,NULL,'2025-11-12 19:56:57','2025-11-12 19:56:57');
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `themes`
--

DROP TABLE IF EXISTS `themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `themes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `config` json NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `themes`
--

LOCK TABLES `themes` WRITE;
/*!40000 ALTER TABLE `themes` DISABLE KEYS */;
/*!40000 ALTER TABLE `themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `twilio_apps`
--

DROP TABLE IF EXISTS `twilio_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `twilio_apps` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_idx` bigint NOT NULL,
  `numbers` json DEFAULT NULL,
  `connected_numbers` json DEFAULT NULL,
  `account_sid` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `auth_token` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `api_key` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `api_secret` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `twiml_app_sid` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `project_idx` (`project_idx`),
  CONSTRAINT `twilio_apps_ibfk_1` FOREIGN KEY (`project_idx`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `twilio_apps`
--

LOCK TABLES `twilio_apps` WRITE;
/*!40000 ALTER TABLE `twilio_apps` DISABLE KEYS */;
INSERT INTO `twilio_apps` VALUES (1,25,'[2319772866]','[5555555555]','AC1e9b18783f8c5979d852d4f7c483535d','6d2703bac920551eb6d2a930619d5daa','SK8d7be33a280a57200e6523d3e73ac06d','M8kNMT9MVCCTsyPux4kFEibqeUyd0Fow','AP3d9642cc096ac1058867c490faf273c4','2025-09-24 19:18:28');
/*!40000 ALTER TABLE `twilio_apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(200) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `first_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `profile_img_src` text COLLATE utf8mb4_general_ci,
  `theme` enum('light','dark') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'dark',
  `auth_provider` enum('google','facebook','discord','local') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'local',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `password_reset` varchar(6) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password_reset_timestamp` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=516 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (505,'aa575ab285f793e2c90c3aa0aba675','opendreamstudios@gmail.com',NULL,1,'Open','Dream','https://lh3.googleusercontent.com/a/ACg8ocLQ1SpRJ3iL9bKeqTyDRLVrBwV-_EG2BfjGosZdVZEZE5LcpFg=s96-c','dark','google','2025-08-23 17:13:30',NULL,NULL),(506,'cf529e7f470b9f8e028a0623758fe2','joeygoff9@gmail.com',NULL,0,'Joseph','Goff','https://lh3.googleusercontent.com/a/ACg8ocJMBGdEobMVL6BENlpzVnpzWNPSaUDGLBwEvqwaA5slOEN8Hg=s96-c','dark','google','2025-08-25 11:58:18',NULL,NULL),(507,'4b502ebba70edd84e920d669aa208b','joeygoff13@gmail.com',NULL,0,'Joseph','Goff','https://lh3.googleusercontent.com/a/ACg8ocKj9bTTTYqctXRWGJGdiCuGnpCfHdDolJrPnKEU4xp9FRNmXQ=s96-c','dark','google','2025-08-25 20:49:45',NULL,NULL),(509,'ffdf0a0d739fb087a4ffc188cac7f2','joeygoff99@gmail.com','$2a$10$PeA/DxBOkS3.krq5lUrJc.LXyX60y42Ua5n8lONO/fQ5TKAqUCLw2',0,'Jo','Go',NULL,'dark','local','2025-10-25 03:20:58',NULL,NULL),(510,'cc83de1ab8d5a8afa54b3404415051','infinityslide03@gmail.com',NULL,0,'Infinity','Slide','https://lh3.googleusercontent.com/a/ACg8ocKf49XhE8QxQ11AyzgIEaOI0Xo2FZdGovEGC4MtqOfY7Oa3nA=s96-c','light','google','2025-10-31 04:12:02',NULL,NULL),(512,'7920795e8f0b51b7e0580070b43ce5','opendreamai@gmail.com',NULL,0,'Joey','Goff','https://lh3.googleusercontent.com/a/ACg8ocIrOB6FrhB2b9jqf8CGpY56GhQoMqNcQBVVNI4o4kqMtmOl-Q=s96-c','dark','google','2025-10-31 19:56:30',NULL,NULL),(513,'38350829bbc92ba9fdb786f42fd043','johndenver@gmail.com','$2a$10$TT1j59Us1Z3oTDyhlkJGc.BOR6MqJQeKjWxH9Atenrj6vP81/HmzS',0,'John','Denv',NULL,'light','local','2025-10-31 20:04:38',NULL,NULL),(514,'0dc1a0202416936f0386e2b6972ef5','infinityslide01@gmail.com','$2a$10$PcZyiXk8s5z8nH2kJhf1Pu2wQB2OLlPYi87b9HyDIAxYw9G/8wEwa',0,'Infinity','Slide',NULL,'light','local','2025-10-31 20:59:39','586797','2025-11-05 22:29:22'),(515,'30b909a2823e7a6dac6839cdcfab9d','tannyspaacquisitions@gmail.com',NULL,0,'Tanny','Spa Acquisitions','https://lh3.googleusercontent.com/a/ACg8ocLapr65yPV_chL_g-CPEhSchwkcxi9Mi--Ie8No_Vh5AvfoFw=s96-c','dark','google','2025-11-03 22:30:07',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'cms'
--

--
-- Dumping routines for database 'cms'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-12 16:08:09
